﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */
    // import { Barometer } from '@zos/sensor'

    try {
     (() => {

      const {
       beforeModuleCreate = () => {}, afterModuleCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforeModuleCreate()

      const {
       beforePageCreate = () => {}, afterPageCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforePageCreate()
      const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__

       //dynamic modify start

       ! function (context) {
        with(context) {

         const hmUI = __$$R$$__('@zos/ui');
         const hmSensor = __$$R$$__('@zos/sensor');
         const hmScene = __$$R$$__('@zos/app');
         const hmRouter = __$$R$$__('@zos/router');
         const hmDevice = __$$R$$__('@zos/device');
         const hmBle = __$$R$$__('@zos/ble');
         const hmStorage = __$$R$$__('@zos/storage');
         const hmInteraction = __$$R$$__('@zos/interaction');
         const gettext = console.log;
         const barometer = new hmSensor.Barometer();
         const altitude = barometer.getAltitude();
         // let airPressure = barometer.getAirPressure() * 0.750064;
         const {
          width: DEVICE_WIDTH,
          height: DEVICE_HEIGHT
         } = hmDevice.getDeviceInfo();


         let normal_background_bg = ''
         let normal_date_img_date_week_img = ''
         let normal_image_img = ''
         let normal_pai_icon_img = ''
         let normal_step_TextCircle = new Array(5);
         let normal_step_TextCircle_ASCIIARRAY = new Array(10);
         let normal_step_TextCircle_img_width = 15;
         let normal_step_TextCircle_img_height = 27;
         let normal_fat_burning_icon_img = ''
         let normal_stress_icon_img = ''
         let normal_digital_clock_img_time = ''
         let normal_battery_icon_img = ''
         let normal_battery_circle_scale = ''
         let normal_battery_text_text_img = ''
         let normal_heart_rate_text_text_img = ''
         // let normal_city_name_text = ''
         // let normal_temperature_high_text_img = ''
         let normal_temperature_low_text_img = ''
         let normal_temperature_current_text_img = ''
         let normal_weather_image_progress_img_level = ''
         let normal_sun_icon_img = ''
         let normal_sunrise_TextCircle = new Array(5);
         let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
         let normal_sunrise_TextCircle_img_width = 11;
         let normal_sunrise_TextCircle_img_height = 21;
         let normal_sunrise_TextCircle_dot_width = 6;
         let normal_sunset_TextCircle = new Array(5);
         let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
         let normal_sunset_TextCircle_img_width = 11;
         let normal_sunset_TextCircle_img_height = 21;
         let normal_sunset_TextCircle_dot_width = 6;

         let normal_calorie_TextCircle = new Array(4);
         let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
         let normal_calorie_TextCircle_img_width = 12;
         let normal_calorie_TextCircle_img_height = 23;

         let idle_calorie_TextCircle = new Array(4);
         let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
         let idle_calorie_TextCircle_img_width = 12;
         let idle_calorie_TextCircle_img_height = 23;

         let normal_step_target_TextCircle = new Array(5);
         let normal_step_target_TextCircle_ASCIIARRAY = new Array(10);
         let normal_step_target_TextCircle_img_width = 15;
         let normal_step_target_TextCircle_img_height = 27;
         let normal_sun_image_progress_img_level = ''
         let normal_system_disconnect_img = ''
         let normal_system_clock_img = ''
         let normal_stand_icon_img = ''
         let normal_stand_current_text_img = ''
         let normal_stand_current_separator_img = ''
         let normal_date_img_date_month_img = ''
         let normal_date_img_date_day = ''
         let idle_background_bg = ''
         let idle_date_img_date_week_img = ''
         let idle_image_img = ''
         let idle_pai_icon_img = ''
         let idle_digital_clock_img_time = ''
         let idle_step_TextCircle = new Array(5);
         let idle_step_TextCircle_ASCIIARRAY = new Array(10);
         let idle_step_TextCircle_img_width = 15;
         let idle_step_TextCircle_img_height = 27;
         let idle_date_img_date_day = ''
         let idle_date_img_date_month_img = ''
         let idle_battery_circle_scale = ''
         let idle_battery_text_text_img = ''
         let idle_humidity_text_text_img = ''
         let idle_heart_rate_text_text_img = ''
         let idle_city_name_text = ''
         let idle_temperature_high_text_img = ''
         let idle_temperature_low_text_img = ''
         let idle_temperature_current_text_img = ''
         let idle_weather_image_progress_img_level = ''
         let idle_sunrise_TextCircle = new Array(5);
         let idle_sunrise_TextCircle_ASCIIARRAY = new Array(10);
         let idle_sunrise_TextCircle_img_width = 11;
         let idle_sunrise_TextCircle_img_height = 21;
         let idle_sunrise_TextCircle_dot_width = 6;
         let idle_sunset_TextCircle = new Array(5);
         let idle_sunset_TextCircle_ASCIIARRAY = new Array(10);
         let idle_sunset_TextCircle_img_width = 11;
         let idle_sunset_TextCircle_img_height = 21;
         let idle_sunset_TextCircle_dot_width = 6;
         let idle_system_disconnect_img = ''
         let idle_system_clock_img = ''
         let idle_stand_current_text_img = ''
         let idle_stand_current_separator_img = ''
         let idle_calorie_current_text_img = ''
		 
         let normal_sun_pointer_progress_img_pointer = ''
         let normal_sun_low_text_font = ''
         let normal_sun_high_text_font = ''
         let normal_moon_pointer_progress_img_pointer = ''
         let normal_moon_low_text_font = ''
         let normal_moon_high_text_font = ''
		 
         let normal_humidity_icon_img = ''
         let normal_humidity_pointer_progress_img_pointer = ''
         let normal_humidity_text_text_img = ''
         let normal_humidity_text_text_img_0 = ''
         let normal_humidity_text_separator_img = ''
         let normal_uvi_icon_img = ''
         let normal_uvi_pointer_progress_img_pointer = ''
         let normal_uvi_text_text_img = ''


         const curTime = new hmSensor.Time();
         const step = new hmSensor.Step();
         const heart = new hmSensor.HeartRate();
         const calorie = new hmSensor.Calorie();
         const battery = new hmSensor.Battery();
         const distance = new hmSensor.Distance();
         //let weatherData = weather.getForecast();

         const weather = new hmSensor.Weather();
         //          let weatherData = weather.getForecast();
         //          let forecastData = weatherData.forecastData; 


         function anim_sector_time() {

          anim_sec_1 = {
           anim_rate: 'leaseInQuint',
           anim_duration: 6000,
           anim_from: 0,
           anim_to: 360,
           anim_offset: 0,
           anim_key: "angle", // to rotate image
           //anim_prop: hmUI.prop.ANGLE,
          }
          anim_sec_img.setProperty(hmUI.prop.ANIM, {
           anim_auto_destroy: 0,
           anim_steps: [anim_sec_1],
           anim_repeat: -1,
           anim_fps: 15,
           anim_auto_start: 1,
          });
         }


         let btn_sport = ''
         let sport = 0

         function run_sport() {
          sport = (sport + 1) % 2;


          normal_image_img.setProperty(hmUI.prop.VISIBLE, sport == 0);
          sport_image_img.setProperty(hmUI.prop.VISIBLE, sport == 1);
          normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, sport == 0);
          bg_fix_sec_img.setProperty(hmUI.prop.VISIBLE, sport == 0);
          normal_digital_clock_img_time_0.setProperty(hmUI.prop.VISIBLE, sport == 0);
          bg_fix_btn_img.setProperty(hmUI.prop.VISIBLE, sport == 0);
          normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, sport == 0);
          normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, sport == 1);
          anim_sec_img.setProperty(hmUI.prop.VISIBLE, sport == 0);
          ic_step_txt_img.setProperty(hmUI.prop.VISIBLE, sport == 0);
          ic_finish_txt_img.setProperty(hmUI.prop.VISIBLE, sport == 1);

          groupSport.setProperty(hmUI.prop.VISIBLE, sport == 1);
          groupVremya.setProperty(hmUI.prop.VISIBLE, sport == 0);

          for (var i = 1; i < 5; i++) { // hide all symbols
           normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, sport == 0);
           normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, sport == 1);
          };


          hmStorage.localStorage.setItem('MND_D1_S_sport', sport);

         }

         function menu_tip_AOD() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          group_tip_AOD.setProperty(hmUI.prop.VISIBLE, true);
         }

         function tip_AOD_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          group_tip_AOD.setProperty(hmUI.prop.VISIBLE, false);
         }

         var curAODmode = 1;

         function select_tip_AOD() {
          AOD_tip_0.setProperty(hmUI.prop.MORE, {
           x: 117,
           y: 108 + 25 + 100 * 0,
           w: 233,
           h: 59,
           color: curAODmode == 0 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          AOD_tip_1.setProperty(hmUI.prop.MORE, {
           x: 117,
           y: 108 + 25 + 100 * 1,
           w: 233,
           h: 59,
           color: curAODmode == 1 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
         }


         let checkBT = false;
         let switch_checkBT;
         let checkBT_interval = ''
         let statusBT_last = ''

         function checkConnection(check = true) {
          if (check) {
           checkBT_interval = setInterval(() => {
            let statusBT = hmBle.connectStatus();
            if (statusBT != statusBT_last) {
             statusBT_last = statusBT;
             if (!statusBT) {
              hmUI.showToast({
               text: "Нет связи!!!"
              });
              vibroTimes(5); //9
             } else {
              hmUI.showToast({
               text: "Снова на связи!"
              });
              vibroTimes(3); //0
             }
            }
           }, 3000);
          } else {
           if (checkBT_interval) clearInterval(checkBT_interval);
          }
         }

         function toggleСheckConnection() {
          checkBT = !checkBT;

          hmStorage.localStorage.setItem('MND_D1_S_checkBT', checkBT);
          //vibro();
          checkConnection(checkBT);
          switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_B_on.png' : 'slider_B_off.png');
         }

         let everyHourVibro = false;

         function toggleEveryHourVibro() {
          everyHourVibro = !everyHourVibro;
          hmStorage.localStorage.setItem('MND_D1_S_hourlyVibro', everyHourVibro);
          vibro();
          switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_H_on.png' : 'slider_H_off.png');
         }

         function setEveryHourVibro() {
          curTime.onPerMinute(() => {
           if (everyHourVibro && !(curTime.getMinutes() % 60)) vibro(); //27
          })
         }

         let timesRemain = 0;
         let vibroTimes_interval = '';

         function vibroTimes(num = 1) {
          timesRemain = num;
          vibroTimes_interval = setInterval(() => {
           //vibrate.stop();
           //vibrate.start(25);
           vibro();
           timesRemain--;
           if (!timesRemain && vibroTimes_interval) {
            clearInterval(vibroTimes_interval);
            //vibrate.stop();
           }
          }, 150);
         }


         let zona = 0
         let zona2 = 0
         let btn_select_zona = ''
         let select_zona = 0

         //            function click_select_zona() {
         //               select_zona = (select_zona + 1) % 3;
         //				
         //ic_dot_icon_img_0.setProperty(hmUI.prop.VISIBLE, select_zona == 0);			 
         //ic_dot_icon_img_1.setProperty(hmUI.prop.VISIBLE, select_zona == 1);		 
         //ic_dot_icon_img_2.setProperty(hmUI.prop.VISIBLE, select_zona == 2);	
         //				
         //hmStorage.localStorage.setItem('MND_D1_S_select_zona', select_zona);	 
         //				
         //			}

         //         let apps_click = [
         //          ['ic_activ_0.png', '', hmUI.data_type.ALTITUDE, 'S_m.png', ''],//высота
         //          ['ic_activ_1.png', '', hmUI.data_type.FAT_BURNING, '', ''],//жир
         //          ['ic_activ_2.png', '', hmUI.data_type.STRESS, '', ''],//стресс
         //          ['ic_activ_3.png', '', hmUI.data_type.STAND, '', ''],//разминка
         //          ['ic_activ_4.png', '', hmUI.data_type.SPO2, '', ''],//кислород
         //          ['ic_activ_5.png', '', hmUI.data_type.UVI, '', ''],//ультрофиолет
         //          ['ic_activ_6.png', '', hmUI.data_type.PAI_DAILY, '', ''],// паи день
         //          ['ic_activ_7.png', 'S_dot.png', hmUI.data_type.DISTANCE, 'S_km.png', ''],// дистанция
         //          ['ic_activ_8.png', '', hmUI.data_type.COUNT_DOWN, '', ''],// таймер
         //          ['ic_activ_9.png', '', hmUI.data_type.FLOOR, '', ''],// этаж
         //          ['ic_activ_10.png', '', hmUI.data_type.WEATHER_HIGH, 'S_g.png', 'S_minus.png'],//темп макс
         //          ['ic_activ_11.png', '', hmUI.data_type.WEATHER_LOW, 'S_g.png', 'S_minus.png'],//темп мин
         //          ['ic_activ_12.png', '', hmUI.data_type.CAL, 'S_kcal.png', '']//калории
         //         ];	 
         //            
         //         let apps_click2 = [
         //          ['ic_activ_12.png', '', hmUI.data_type.CAL, 'S_kcal.png', ''],//калории
         //          ['ic_activ_0.png', '', hmUI.data_type.ALTITUDE, 'S_m.png', ''],//высота
         //          ['ic_activ_1.png', '', hmUI.data_type.FAT_BURNING, '', ''],//жир
         //          ['ic_activ_2.png', '', hmUI.data_type.STRESS, '', ''],//стресс
         //          ['ic_activ_3.png', '', hmUI.data_type.STAND, '', ''],//разминка
         //          ['ic_activ_4.png', '', hmUI.data_type.SPO2, '', ''],//кислород
         //          ['ic_activ_5.png', '', hmUI.data_type.UVI, '', ''],//ультрофиолет
         //          ['ic_activ_6.png', '', hmUI.data_type.PAI_DAILY, '', ''],// паи день
         //          ['ic_activ_7.png', 'S_dot.png', hmUI.data_type.DISTANCE, 'S_km.png', ''],// дистанция
         //          ['ic_activ_8.png', '', hmUI.data_type.COUNT_DOWN, '', ''],// таймер
         //          ['ic_activ_9.png', '', hmUI.data_type.FLOOR, '', ''],// этаж
         //          ['ic_activ_10.png', '', hmUI.data_type.WEATHER_HIGH, 'S_g.png', 'S_minus.png'],//темп макс
         //          ['ic_activ_11.png', '', hmUI.data_type.WEATHER_LOW, 'S_g.png', 'S_minus.png']//темп мин
         //         ];	 


         //    		let apps_text_icon_img = []
         //			let apps_text_img = []
         //			
         //            function click_zona() {
         //               // zona = (zona + 1) % apps_click.length;	
         //                
         //     for (let i = 0; i < apps_click.length; i++) {
         //            apps_text_icon_img[i].setProperty(hmUI.prop.MORE, {
         //              x: 268,
         //              y: 251,
         //              src: apps_click[i][0],
         //              show_level: hmUI.show_level.ONLY_NORMAL,
         //            });
         //         
         //            apps_text_img[i].setProperty(hmUI.prop.MORE, {
         //              x: 313,
         //              y: 258,
         //              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
         //              padding: false,
         //              h_space: 1,
         //              unit_sc: apps_click[i][3],
         //              unit_tc: apps_click[i][3],
         //              unit_en: apps_click[i][3],
         //              negative_image: apps_click[i][4],
         //			  dot_image: apps_click[i][1],
         //              invalid_image: 'S_v.png',  
         //              align_h: hmUI.align.LEFT,
         //              type: apps_click[i][2],
         //              show_level: hmUI.show_level.ONLY_NORMAL,
         //            }); 
         //         
         //           apps_text_icon_img[i].setProperty(hmUI.prop.VISIBLE, i == zona ? true : false);
         //           apps_text_img[i].setProperty(hmUI.prop.VISIBLE, i == zona ? true : false);
         //         
         //        }
         //                
         //			hmStorage.localStorage.setItem('sx300_zona', zona);							
         //                
         //			
         //            }

         //    		let apps_text_icon_img2 = []
         //			let apps_text_img2 = []
         //    		let idle_apps_text_icon_img = []
         //			let idle_apps_text_img = []
         //    		let idle_apps_text_icon_img2 = []
         //			let idle_apps_text_img2 = []
         //			
         //            function click_zona2() {
         //               // zona = (zona + 1) % apps_click.length;	
         //                
         //     for (let i = 0; i < apps_click.length; i++) {
         //            apps_text_icon_img2[i].setProperty(hmUI.prop.MORE, {
         //              x: 268,
         //              y: 251+36,
         //              src: apps_click2[i][0],
         //              show_level: hmUI.show_level.ONLY_NORMAL,
         //            });
         //         
         //            apps_text_img2[i].setProperty(hmUI.prop.MORE, {
         //              x: 313,
         //              y: 258+36,
         //              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
         //              padding: false,
         //              h_space: 1,
         //              unit_sc: apps_click2[i][3],
         //              unit_tc: apps_click2[i][3],
         //              unit_en: apps_click2[i][3],
         //              negative_image: apps_click2[i][4],
         //              dot_image: apps_click2[i][1],
         //              invalid_image: 'S_v.png',  
         //              align_h: hmUI.align.LEFT,
         //              type: apps_click2[i][2],
         //              show_level: hmUI.show_level.ONLY_NORMAL,
         //            }); 
         //         
         //           apps_text_icon_img2[i].setProperty(hmUI.prop.VISIBLE, i == zona2 ? true : false);
         //           apps_text_img2[i].setProperty(hmUI.prop.VISIBLE, i == zona2 ? true : false);
         //         
         //        }
         //                
         //			hmStorage.localStorage.setItem('sx300_zona2', zona2);							
         //                
         //			
         //            }

         let btn_color = ''
         let color = 0

         let color_bg = [0xFFB900, 0xffffff, 0xf8e36c, 0xffbb08, 0xa3fd1f, 0xfa4e1e, 0x8cffff, 0x06c6ff, 0xff00a2, 0xf6012a];

         let degreeSum = 0
         let crownSensitivity = 70 // уровень чувствительности колесика


         function onDigitalCrown() {
          hmInteraction.onDigitalCrown({
           callback: (key, degree) => {
            if (key === hmInteraction.KEY_HOME) {
             degreeSum += degree;
             if (Math.abs(degreeSum) > crownSensitivity) {

              // if (select_zona == 0) {
              let step = degreeSum < 0 ? -1 : 1;
              color += step;
              color = color < 0 ? color_bg.length + color : color % color_bg.length;
              degreeSum = 0;
              click_color();
              // }

              //		     if (select_zona == 1) {
              //		      let step = degreeSum < 0 ? -1 : 1;
              //		      zona += step;
              //		      zona = zona < 0 ? apps_click.length + zona : zona % apps_click.length;
              //		      degreeSum = 0;
              //		      click_zona();
              //		     }
              //
              //		     if (select_zona == 2) {
              //		      let step = degreeSum < 0 ? -1 : 1;
              //		      zona2 += step;
              //		      zona2 = zona2 < 0 ? apps_click2.length + zona2 : zona2 % apps_click2.length;
              //		      degreeSum = 0;
              //		      click_zona2();
              //		     }

              vibro();

              //hmUI.showToast({text: "АОД: " + select_zona});

              hmStorage.localStorage.setItem('MND_D1_S_color', color);
              //		     hmStorage.localStorage.setItem('MND_D1_S_zona', zona);
              //		     hmStorage.localStorage.setItem('MND_D1_S_zona2', zona2);
             }
            }
           }
          })
         }


         function loadSettings() {

          checkBT = hmStorage.localStorage.getItem('MND_D1_S_checkBT', false);
          everyHourVibro = hmStorage.localStorage.getItem('MND_D1_S_hourlyVibro', false);
          curAODmode = hmStorage.localStorage.getItem('MND_D1_S_aod', 1);
          // select_zona = hmStorage.localStorage.getItem('MND_D1_S_select_zona', 0);
          // zona = hmStorage.localStorage.getItem('MND_D1_S_zona', 0);
          // zona2 = hmStorage.localStorage.getItem('MND_D1_S_zona2', 0);
          color = hmStorage.localStorage.getItem('MND_D1_S_color', 0);
          isDayIcons = hmStorage.localStorage.getItem('MND_D1_S_isDayIcons', true);
          sport = hmStorage.localStorage.getItem('MND_D1_S_sport', 0);
         }

         function saveSettings() {

          hmStorage.localStorage.setItem('MND_D1_S_aod', 1);
          hmStorage.localStorage.setItem('MND_D1_S_checkBT', false);
          hmStorage.localStorage.setItem('MND_D1_S_hourlyVibro', false);
          // hmStorage.localStorage.setItem('MND_D1_S_select_zona', 0);
          // hmStorage.localStorage.setItem('MND_D1_S_zona', 0);
          // hmStorage.localStorage.setItem('MND_D1_S_zona2', 0);
          hmStorage.localStorage.setItem('MND_D1_S_color', 0);
          hmStorage.localStorage.setItem('MND_D1_S_isDayIcons', true);
          hmStorage.localStorage.setItem('MND_D1_S_init', true);
          hmStorage.localStorage.setItem('MND_D1_S_sport', 0);
         }


         function makeAOD() {
          statusBT_last = hmBle.connectStatus();


          hmUI.createWidget(hmUI.widget.FILL_RECT, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: '0xFF000000',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          if (curAODmode == 1) {

           idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            color: color_bg[color],
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 100,
            y: 299,
            week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
            week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
            week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            src: 'bg_0.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            src: 'cap.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_startX: 104,
            hour_startY: 184,
            hour_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
            hour_zero: 1,
            hour_space: 0,
            hour_angle: 0,
            hour_align: hmUI.align.CENTER_H,

            minute_startX: 249,
            minute_startY: 184,
            minute_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
            minute_zero: 1,
            minute_space: 0,
            minute_angle: 0,
            minute_follow: 0,
            minute_align: hmUI.align.CENTER_H,

            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_step_TextCircle_ASCIIARRAY[0] = 'dig_s_0.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[1] = 'dig_s_1.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[2] = 'dig_s_2.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[3] = 'dig_s_3.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[4] = 'dig_s_4.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[5] = 'dig_s_5.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[6] = 'dig_s_6.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[7] = 'dig_s_7.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[8] = 'dig_s_8.png'; // set of images with numbers
           idle_step_TextCircle_ASCIIARRAY[9] = 'dig_s_9.png'; // set of images with numbers

           //start of ignored block
           for (let i = 0; i < 5; i++) {
            idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
             x: 0,
             y: 0,
             w: 466,
             h: 466,
             center_x: 236,
             center_y: 233,
             pos_x: 236 - idle_step_TextCircle_img_width / 2,
             pos_y: 233 + 170,
             src: 'dig_s_0.png',
             show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           //end of ignored block

           let valueStep = step.getCurrent();
           let idle_step_circle_string = parseInt(valueStep).toString();

           for (var i = 1; i < 5; i++) { // hide all symbols
            idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_step = 360;
           if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length < 6) { // display data if it was possible to get it
            let idle_step_TextCircle_img_angle = 0;
            let idle_step_TextCircle_dot_img_angle = 0;
            idle_step_TextCircle_img_angle = (180 / Math.PI) * (Math.atan2(idle_step_TextCircle_img_width / 2, 183));
            // alignment = CENTER_H
            let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
            idle_step_TextCircle_angleOffset = idle_step_TextCircle_angleOffset + 1 * (idle_step_circle_string.length - 1) / 2;
            idle_step_TextCircle_angleOffset = -idle_step_TextCircle_angleOffset;
            char_Angle_step -= idle_step_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of idle_step_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_step -= idle_step_TextCircle_img_angle;
              firstSymbol = false;
              idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_step);
              idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 236 - idle_step_TextCircle_img_width / 2);
              idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
              idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
              char_Angle_step -= idle_step_TextCircle_img_angle + 1;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           let idle_progressBattery = battery.getCurrent() / 100;
           if (idle_progressBattery > 1) idle_progressBattery = 1;


           idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
            center_x: 233,
            center_y: 233,
            start_angle: 229,
            end_angle: 262,
            radius: 217,
            line_width: 16,
            corner_flag: 3,
            color: color_bg[color],
            show_level: hmUI.show_level.ONLY_AOD,
            level: Math.round(idle_progressBattery * 100),
           });

           idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 51,
            y: 295,
            font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
            padding: false,
            h_space: 1,
            angle: 62,
            align_h: hmUI.align.RIGHT,
            type: hmUI.data_type.BATTERY,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 37,
            y: 224,
            font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
            padding: false,
            h_space: 1,
            angle: -82,
            align_h: hmUI.align.RIGHT,
            type: hmUI.data_type.HUMIDITY,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 176,
            y: 343,
            src: 'bg_fix_data.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 313,
            y: 380,
            font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
            padding: false,
            h_space: 1,
            angle: -34,
            align_h: hmUI.align.CENTER_H,
            type: hmUI.data_type.HEART,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: 227,
            month_startY: 344,
            month_sc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
            month_tc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
            month_en_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
            month_is_character: true,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            day_startX: 184,
            day_startY: 350,
            day_sc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
            day_tc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
            day_en_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
            day_zero: 1,
            day_space: 1,
            day_align: hmUI.align.LEFT,
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 108,
            y: 127,
            w: 250,
            h: 42,
            text_size: 26,
            char_space: 0,
            line_space: 0,
            font: 'fonts/Bebas11.ttf',
            color: 0xFFAFAFAF,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.NONE,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           //          idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           //              x: 99,
           //              y: 82,
           //              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
           //              padding: false,
           //              h_space: 1,
           //              angle: -34,
           //              unit_sc: 'dig_a_p.png',
           //              unit_tc: 'dig_a_p.png',
           //              unit_en: 'dig_a_p.png',
           //              negative_image: 'dig_a_m.png',
           //              invalid_image: 'dig_a_p.png',
           //              align_h: hmUI.align.RIGHT,
           //              type: hmUI.data_type.WEATHER_LOW,
           //              show_level: hmUI.show_level.ONLY_AOD,
           //            });

           idle_WEATHER_HIGH_LOW_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
            x: 28,
            y: 28,
            w: (466 - 28 * 2),
            h: (466 - 28 * 2),
            text_size: 35,
            font: 'fonts/Bebas11.ttf',
            color: 0xFFFFFF,
            //text: "2022/05/29 12:23:59 SAT",
            // align_v: hmUI.align.TOP, //CENTER_V	
            align_h: hmUI.align.CENTER_H, //CENTER_H
            char_space: 0,
            start_angle: -80 - 5 - 5,
            end_angle: 30,
            unit_type: 0,
            type: hmUI.data_type.WEATHER_HIGH_LOW,
            show_level: hmUI.show_level.ONLY_AOD,
           })

           idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 55,
            y: 141,
            font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
            padding: false,
            h_space: 1,
            angle: -57,
            unit_sc: 'dig_a_p.png',
            unit_tc: 'dig_a_p.png',
            unit_en: 'dig_a_p.png',
            negative_image: 'dig_a_m.png',
            invalid_image: 'dig_a_p.png',
            align_h: hmUI.align.RIGHT,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           //            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           //              x: 147,
           //              y: 53,
           //              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
           //              padding: false,
           //              h_space: 1,
           //              angle: -21,
           //              unit_sc: 'dig_a_p.png',
           //              unit_tc: 'dig_a_p.png',
           //              unit_en: 'dig_a_p.png',
           //              negative_image: 'dig_a_m.png',
           //              invalid_image: 'dig_a_p.png',
           //              align_h: hmUI.align.LEFT,
           //              type: hmUI.data_type.WEATHER_HIGH,
           //              show_level: hmUI.show_level.ONLY_AOD,
           //            });	


           idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: 211,
            y: 27,
            image_array: ["w_0.png", "w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png"],
            image_length: 29,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_sunrise_TextCircle_ASCIIARRAY[0] = 'dig_b_0.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[1] = 'dig_b_1.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[2] = 'dig_b_2.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[3] = 'dig_b_3.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[4] = 'dig_b_4.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[5] = 'dig_b_5.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[6] = 'dig_b_6.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[7] = 'dig_b_7.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[8] = 'dig_b_8.png'; // set of images with numbers
           idle_sunrise_TextCircle_ASCIIARRAY[9] = 'dig_b_9.png'; // set of images with numbers

           //start of ignored block
           for (let i = 0; i < 5; i++) {
            idle_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
             x: 0,
             y: 0,
             w: 466,
             h: 466,
             center_x: 233,
             center_y: 233,
             pos_x: 233 - idle_sunrise_TextCircle_img_width / 2,
             pos_y: 233 + 175,
             src: 'dig_b_0.png',
             show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           //end of ignored block

           let weatherData = weather.getForecast();
           let forecastData = weatherData.forecastData;
           let sunData = weatherData.tideData;
           //
           let sunrise_hour = 0;
           let sunrise_minute = 0;
           if (sunData.count > 0) {
            sunrise_hour = sunData.data[0].sunrise.hour;
            sunrise_minute = sunData.data[0].sunrise.minute;
           }; // end sunData;

           let sunset_hour = 0;
           let sunset_minute = 0;
           if (sunData.count > 0) {
            sunset_hour = sunData.data[0].sunset.hour;
            sunset_minute = sunData.data[0].sunset.minute;
           }; // end sunData;			 


           let idle_sunrise_circle_string = undefined;
           if (sunrise_hour != 0 && sunrise_minute != 0) {
            sunriseTime = 0;
            idle_sunrise_circle_string = String(sunrise_hour) + '.' + String(sunrise_minute).padStart(2, '0');
           };

           for (var i = 1; i < 5; i++) { // hide all symbols
            idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_sunrise = 394;
           if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && idle_sunrise_circle_string.length > 0 && idle_sunrise_circle_string.length < 6) { // display data if it was possible to get it
            let idle_sunrise_TextCircle_img_angle = 0;
            let idle_sunrise_TextCircle_dot_img_angle = 0;
            idle_sunrise_TextCircle_img_angle = (180 / Math.PI) * (Math.atan2(idle_sunrise_TextCircle_img_width / 2, 185));
            idle_sunrise_TextCircle_dot_img_angle = (180 / Math.PI) * (Math.atan2(idle_sunrise_TextCircle_dot_width / 2, 185));
            // alignment = CENTER_H
            let idle_sunrise_TextCircle_angleOffset = idle_sunrise_TextCircle_img_angle * (idle_sunrise_circle_string.length - 1);
            idle_sunrise_TextCircle_angleOffset = -idle_sunrise_TextCircle_angleOffset;
            char_Angle_sunrise -= idle_sunrise_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of idle_sunrise_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_sunrise -= idle_sunrise_TextCircle_img_angle;
              firstSymbol = false;
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunrise_TextCircle_img_width / 2);
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunrise_TextCircle_ASCIIARRAY[charCode]);
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == false); //isDayIcons == false
              char_Angle_sunrise -= idle_sunrise_TextCircle_img_angle;
              index++;
             } // end if digit
             else {
              if (!firstSymbol) char_Angle_sunrise -= idle_sunrise_TextCircle_dot_img_angle;
              firstSymbol = false;
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunrise_TextCircle_dot_width / 2);
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_b_dot2.png');
              idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == false); //isDayIcons == false
              char_Angle_sunrise -= idle_sunrise_TextCircle_dot_img_angle;
              index++;
             }; // end if dot point 
            }; // end char of string
           } // end isFinite	


           idle_sunset_TextCircle_ASCIIARRAY[0] = 'dig_b_0.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[1] = 'dig_b_1.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[2] = 'dig_b_2.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[3] = 'dig_b_3.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[4] = 'dig_b_4.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[5] = 'dig_b_5.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[6] = 'dig_b_6.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[7] = 'dig_b_7.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[8] = 'dig_b_8.png'; // set of images with numbers
           idle_sunset_TextCircle_ASCIIARRAY[9] = 'dig_b_9.png'; // set of images with numbers

           //start of ignored block
           for (let i = 0; i < 5; i++) {
            idle_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
             x: 0,
             y: 0,
             w: 466,
             h: 466,
             center_x: 233,
             center_y: 233,
             pos_x: 233 - idle_sunset_TextCircle_img_width / 2,
             pos_y: 233 + 175,
             src: 'dig_b_0.png',
             show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           //end of ignored block


           let idle_sunset_circle_string = undefined;
           if (sunset_hour != 0 && sunset_minute != 0) {
            sunsetTime = 0;
            idle_sunset_circle_string = String(sunset_hour) + '.' + String(sunset_minute).padStart(2, '0');
           };

           for (var i = 1; i < 5; i++) { // hide all symbols
            idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_sunset = 394;
           if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && idle_sunset_circle_string.length > 0 && idle_sunset_circle_string.length < 6) { // display data if it was possible to get it
            let idle_sunset_TextCircle_img_angle = 0;
            let idle_sunset_TextCircle_dot_img_angle = 0;
            idle_sunset_TextCircle_img_angle = (180 / Math.PI) * (Math.atan2(idle_sunset_TextCircle_img_width / 2, 185));
            idle_sunset_TextCircle_dot_img_angle = (180 / Math.PI) * (Math.atan2(idle_sunset_TextCircle_dot_width / 2, 185));
            // alignment = CENTER_H
            let idle_sunset_TextCircle_angleOffset = idle_sunset_TextCircle_img_angle * (idle_sunset_circle_string.length - 1);
            idle_sunset_TextCircle_angleOffset = -idle_sunset_TextCircle_angleOffset;
            char_Angle_sunset -= idle_sunset_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of idle_sunset_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_sunset -= idle_sunset_TextCircle_img_angle;
              firstSymbol = false;
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunset_TextCircle_img_width / 2);
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunset_TextCircle_ASCIIARRAY[charCode]);
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == true); //isDayIcons == true
              char_Angle_sunset -= idle_sunset_TextCircle_img_angle;
              index++;
             } // end if digit
             else {
              if (!firstSymbol) char_Angle_sunset -= idle_sunset_TextCircle_dot_img_angle;
              firstSymbol = false;
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunset_TextCircle_dot_width / 2);
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_b_dot2.png');
              idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == true); //isDayIcons == true
              char_Angle_sunset -= idle_sunset_TextCircle_dot_img_angle;
              index++;
             }; // end if dot point 
            }; // end char of string
           } // end isFinite	

           idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 113,
            y: 160,
            src: 'status_B_off.png',
            type: hmUI.system_status.DISCONNECT,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 262,
            y: 157,
            src: 'status_H_on.png',
            type: hmUI.system_status.CLOCK,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 405,
            y: 278,
            src: 'bg_fix_btn.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });


           idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 201 + 5,
            y: 110,
            font_array: ["dig_c_0.png", "dig_c_1.png", "dig_c_2.png", "dig_c_3.png", "dig_c_4.png", "dig_c_5.png", "dig_c_6.png", "dig_c_7.png", "dig_c_8.png", "dig_c_9.png"],
            padding: false,
            h_space: 0,
            unit_sc: 'dig_c_M.png',
            unit_tc: 'dig_c_M.png',
            unit_en: 'dig_c_M.png',
            align_h: hmUI.align.CENTER_H,
            type: hmUI.data_type.ALTITUDE,
            show_level: hmUI.show_level.ONLY_AOD,
           });


           //            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           //              x: 0,
           //              y: 0,
           //              src: 'cap.png',
           //              show_level: hmUI.show_level.ONLY_AOD,
           //            });

           idle_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 212,
            y: 74,
            src: 'ic_visota.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });


           idle_calorie_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
           idle_calorie_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

           //start of ignored block
           for (let i = 0; i < 4; i++) {
            idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
             x: 0,
             y: 0,
             w: 466,
             h: 466,
             center_x: 233,
             center_y: 233,
             pos_x: 233 - idle_calorie_TextCircle_img_width / 2,
             pos_y: 233 - 194,
             src: 'dig_a_0.png',
             show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           //end of ignored block

           let valueCalories_idle = barometer.getAirPressure() * 0.750064;
           let idle_calorie_circle_string = parseInt(valueCalories_idle).toString();

           for (var i = 1; i < 4; i++) { // hide all symbols
            idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_idle_calorie = 33;
           if (valueCalories_idle != null && valueCalories_idle != undefined && isFinite(valueCalories_idle) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length < 6) { // display data if it was possible to get it
            let idle_calorie_TextCircle_img_angle = 0;
            let idle_calorie_TextCircle_dot_img_angle = 0;
            idle_calorie_TextCircle_img_angle = (180 / Math.PI) * (Math.atan2(idle_calorie_TextCircle_img_width / 2, 183));
            // alignment = CENTER_H
            let idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_img_angle * (idle_calorie_circle_string.length - 1);
            idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + 1 * (idle_calorie_circle_string.length - 1) / 2;
            char_Angle_idle_calorie -= idle_calorie_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of idle_calorie_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 4) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_idle_calorie += idle_calorie_TextCircle_img_angle;
              firstSymbol = false;
              idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_idle_calorie);
              idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_calorie_TextCircle_img_width / 2);
              idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
              idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
              char_Angle_idle_calorie += idle_calorie_TextCircle_img_angle + 1;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           //            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           //              center_x: 233,
           //              center_y: 233,
           //              start_angle: -162,
           //              end_angle: 162,
           //              radius: 154,
           //              line_width: 14,
           //              corner_flag: 3,
           //              color: 0xFFFF0000,
           //              show_level: hmUI.show_level.ONLY_AOD,
           //            });   

           //            idle_ic_step_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
           //              x: 208,
           //              y: 442,
           //              src: 'ic_step_txt.png',
           //              show_level: hmUI.show_level.ONLY_AOD,
           //            });	

           switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
            x: 102,
            y: 168,
            src: checkBT ? 'slider_B_on.png' : 'slider_B_off.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
            x: 359,
            y: 168,
            src: everyHourVibro ? 'slider_H_on.png' : 'slider_H_off.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle__ALARM_CLOCKt_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 293,
            y: 162,
            font_array: ["dig_al_0.png", "dig_al_1.png", "dig_al_2.png", "dig_al_3.png", "dig_al_4.png", "dig_al_5.png", "dig_al_6.png", "dig_al_7.png", "dig_al_8.png", "dig_al_9.png"],
            padding: true,
            h_space: 0,
            invalid_image: 'dig_al_p.png',
            dot_image: 'dig_al_10.png',
            align_h: hmUI.align.CENTER_H,
            type: hmUI.data_type.ALARM_CLOCK,
            show_level: hmUI.show_level.ONLY_AOD,
           });


          }


          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {
            stopVibro();
            let weatherData = weather.getForecast();
            idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

           }),
           pause_call: (function () {
            stopVibro();

           }),
          });

          checkConnection(checkBT);
          setEveryHourVibro();

          //     for (let i = 0; i < apps_click.length; i++) {
          //           idle_apps_text_icon_img[i].setProperty(hmUI.prop.VISIBLE, i == zona ? true : false);
          //           idle_apps_text_img[i].setProperty(hmUI.prop.VISIBLE, i == zona ? true : false);
          //           idle_apps_text_icon_img2[i].setProperty(hmUI.prop.VISIBLE, i == zona2 ? true : false);
          //           idle_apps_text_img2[i].setProperty(hmUI.prop.VISIBLE, i == zona2 ? true : false);
          //	 						}	


         }


         function click_color() {

          // color = (color + 1) % 2;


          normal_background_bg.setProperty(hmUI.prop.MORE, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: color_bg[color],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //            normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {
          //              center_x: 233,
          //              center_y: 233,
          //              start_angle: 0,
          //              end_angle: 360,
          //              radius: 186,
          //              line_width: 45,
          //              corner_flag: 3,
          //              color: color_bg[color],
          //              level: 100,
          //              show_level: hmUI.show_level.ONLY_NORMAL,
          //            }); 


          //hmStorage.localStorage.setItem('MND_D1_S_color', color);

         }


         function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }


         let vibrate = new hmSensor.Vibrator();
         let stopVibro_Timer = null;


         function vibro(mode = 25) {
          let stopDelay = 25;
          vibrate.stop();
          //vibrate.setMode(mode);
          vibrate.start(mode);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
          stopVibro_Timer = setTimeout(() => {
           stopVibro();
          }, stopDelay);
         }

         function stopVibro() {
          vibrate.stop();
          //timer.stopTimer(stopVibro_Timer);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
         }


         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }


         //	---------------------------------------------------------		

         //переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
         let weatherTxtImgArray = []
         let weatherTxtImgArrayN = []
         let pointred = new Array(6);
         let pointblue = new Array(5);
         let linered = new Array(6);
         let lineblue = new Array(5);
         let yArrH = new Array(6);
         let yArrL = new Array(5);
         let y_pogodaH = new Array(6);
         let y_pogodaL = new Array(5);
         let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
         let week_weater_img = []
         let day_weater_img = []
         const ROOTPATH = "images/"

         let normal_city_name_text = ''

         let Grafik_zona_right = 0;
         let Grafik_zona_right_0 = 0;

         //-------------------------------- 

         //массив иконок для графика       
         for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
         }

         function click_Grafik_zona_right_0() {
          Grafik_zona_right_0 = (Grafik_zona_right_0 + 1) % 2;

        	normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 0);
          	normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 0);
          	normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 0);
        normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 1);
          normal_moon_low_text_font.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 1);
          normal_moon_high_text_font.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 1);


         }


         function click_Grafik_zona_right() {
          Grafik_zona_right = (Grafik_zona_right + 1) % 3;

          normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 0);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 0);
          normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 0);
          normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 2);
          normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 2);
          normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 2);

         }


         //обновление для   графика           
         function updateGrafik() {


          //          const weather = new hmSensor.Weather();
          let weatherData = weather.getForecast();
          let forecastData = weatherData.forecastData;


          sunData = weatherData.tideData;
          if (sunData.count > 0) {
           today = sunData.data[0];
           sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
           sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          } else {
           sunriseMins = sunriseMins_def;
           sunsetMins = sunsetMins_def;
          }
          curMins = curTime.getHours() * 60 + curTime.getMinutes();
          let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

          if (isDayNow) {
           if (!isDayIcons) {
            isDayIcons = true;
           }
          } else {
           if (isDayIcons) {
            isDayIcons = false;
           }
          }

          // if (num_zona_top == 1) {
          // SUN_RISE_txt.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
          normal_vos_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false); //true
          // SUN_SET_txt.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
          normal_zak_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true); //false
          // }			 


          hmStorage.localStorage.setItem('MND_D1_S_isDayIcons', isDayIcons);


          normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);


          if (forecastData.count == 0) {
           for (let i = 0; i < 6; i++) {
            var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
           }
          } else {
           let weekDay = curTime.getDay() - 1;
           for (let i = 0; i < 6; i++) {
            yArrH[i] = forecastData.data[i].high;
            let element = forecastData.data[i];
            let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
            // let date = new Date(curTime.utc + 86400000 * i);
            let date = new Date(curTime.getTime() + 86400000 * i);
            let data = date.getDate();
            let week = week_weater[weekDay];
            week_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: week,
            });
            day_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: data,
            });
            weekDay = (weekDay + 1) % 7;
           }
          }


          for (let i = 0; i < 5; i++) {
           yArrL[i] = forecastData.data[i].low;
          }
          let maxH = Math.max(...yArrH)
          let maxL = Math.min(...yArrL)
          var shag = 46;
          var x0 = 119;
          for (let i = 0; i < 6; i++) {
           pointred[i].setProperty(hmUI.prop.MORE, {
            x: 119 + shag * [i] - 5,
            y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5 + 20,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFFFF0000,
            line_width: 10,
           });
          };

          for (let i = 0; i < 5; i++) {
           yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            linered[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: +20,
             w: 164 + shag * i,
             h: 466,
             pos_x: -31 + shag * i,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_red.png',
            });
          };
          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5 + 20,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 4; i++) {
           yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            lineblue[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 20,
             w: 164 + shag * i + 23,
             h: 466,
             pos_x: -31 + shag * i + 23,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i + 23,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_blue.png',
            });
          };

          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5 + 20,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 6; i++) {
           y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
           weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + i * 45 * 1.02,
            y: y_pogodaH[i] - 38 + 20, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrH[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }

          for (let i = 0; i < 5; i++) {
           y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
           weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + 23 + i * 45 * 1.02,
            y: y_pogodaL[i] - 1 + 20, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrL[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }
         }


         //dynamic modify end

         function init_view() {
          //dynamic modify start
          if (hmStorage.localStorage.getItem('MND_D1_S_init') != true) {
           saveSettings();
          }
          loadSettings();

          let normal_city_name_text_cache = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 464,
           y: 464,
           w: 31,
           h: 31,
           text_size: 26,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFAFAFAF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.NONE,
           text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          let idle_city_name_text_cache = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 464,
           y: 464,
           w: 38,
           h: 38,
           text_size: 32,
           char_space: 1,
           line_space: 0,
           font: 'fonts/steelfish_eb.ttf',
           color: 0xFFB5C4B3,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.NONE,
           text: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          hmUI.createWidget(hmUI.widget.TEXT, {
           x: 464,
           y: 464,
           w: 306,
           h: 51,
           text_size: 35,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.TOP,
           text_style: hmUI.text_style.ELLIPSIS,
           text: "0123456789 _-.,:;`'%°",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: color_bg[color],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
           x: 100,
           y: 299,
           week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'bg_0.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 108,
           y: 127,
           w: 250,
           h: 42,
           text_size: 26,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFAFAFAF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.NONE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 113,
           y: 160,
           src: 'status_B_off.png',
           type: hmUI.system_status.DISCONNECT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 262,
           y: 157,
           src: 'status_H_on.png',
           type: hmUI.system_status.CLOCK,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 201 + 5,
           y: 110,
           font_array: ["dig_c_0.png", "dig_c_1.png", "dig_c_2.png", "dig_c_3.png", "dig_c_4.png", "dig_c_5.png", "dig_c_6.png", "dig_c_7.png", "dig_c_8.png", "dig_c_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_c_M.png',
           unit_tc: 'dig_c_M.png',
           unit_en: 'dig_c_M.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.ALTITUDE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          sport_image_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'bg_1.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'cap.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 212,
           y: 74,
           src: 'ic_visota.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
          // circle_center_X: 236,
          // circle_center_Y: 233,
          // font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
          // radius: 183,
          // angle: 180,
          // char_space_angle: 1,
          // zero: false,
          // reverse_direction: true,
          // unit_in_alignment: true,
          // vertical_alignment: CENTER_V,
          // horizontal_alignment: CENTER_H,
          // type: hmUI.data_type.STEP,
          // show_level: hmUI.show_level.ONLY_NORMAL,
          // });

          normal_step_TextCircle_ASCIIARRAY[0] = 'dig_s_0.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[1] = 'dig_s_1.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[2] = 'dig_s_2.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[3] = 'dig_s_3.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[4] = 'dig_s_4.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[5] = 'dig_s_5.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[6] = 'dig_s_6.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[7] = 'dig_s_7.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[8] = 'dig_s_8.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[9] = 'dig_s_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 236,
            center_y: 233,
            pos_x: 236 - normal_step_TextCircle_img_width / 2,
            pos_y: 233 + 170,
            src: 'dig_s_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block


          normal_step_target_TextCircle_ASCIIARRAY[0] = 'dig_s_0.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[1] = 'dig_s_1.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[2] = 'dig_s_2.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[3] = 'dig_s_3.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[4] = 'dig_s_4.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[5] = 'dig_s_5.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[6] = 'dig_s_6.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[7] = 'dig_s_7.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[8] = 'dig_s_8.png'; // set of images with numbers
          normal_step_target_TextCircle_ASCIIARRAY[9] = 'dig_s_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_step_target_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_step_target_TextCircle_img_width / 2,
            pos_y: 233 + 170,
            src: 'dig_s_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block


          normal_calorie_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 4; i++) {
           normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
            pos_y: 233 - 194,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block


          //            const step = hmSensor.createSensor(hmSensor.id.STEP);
          //            step.addEventListener(hmSensor.event.CHANGE, function() {
          //              text_update();
          //            });

          function toDegree(radian) {
           return radian * (180 / Math.PI);
          };

          bg_fix_btn_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 405,
           y: 278,
           src: 'bg_fix_btn.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'ic_txt_Circle.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          bg_fix_sec_img = hmUI.createWidget(hmUI.widget.FILL_RECT, {
           x: 380,
           y: 204,
           w: 21,
           h: 90,
           color: "0x00000000",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_digital_clock_img_time_0 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
           hour_startX: 104,
           hour_startY: 184,
           hour_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
           hour_zero: 1,
           hour_space: 0,
           hour_angle: 0,
           hour_align: hmUI.align.CENTER_H,

           minute_startX: 249,
           minute_startY: 184,
           minute_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
           minute_zero: 1,
           minute_space: 0,
           minute_angle: 0,
           minute_follow: 0,
           minute_align: hmUI.align.CENTER_H,

           second_startX: 379,
           second_startY: 250,
           second_array: ["S_0.png", "S_1.png", "S_2.png", "S_3.png", "S_4.png", "S_5.png", "S_6.png", "S_7.png", "S_8.png", "S_9.png"],
           second_zero: 1,
           second_space: 0,
           second_angle: 0,
           second_follow: 0,
           second_align: hmUI.align.CENTER_H,

           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
          // center_x: 233,
          // center_y: 233,
          // start_angle: 229,
          // end_angle: 262,
          // radius: 225,
          // line_width: 16,
          // line_cap: Flat,
          // color: 0xFFFF0000,
          // mirror: False,
          // inversion: False,
          // type: hmUI.data_type.BATTERY,
          // show_level: hmUI.show_level.ONLY_NORMAL,
          // });

          //let screenType = hmSetting.getScreenType();
          normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 233,
           center_y: 233,
           start_angle: 229,
           end_angle: 262,
           radius: 217,
           line_width: 16,
           corner_flag: 3,
           color: 0xFFFF0000,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          //            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
          //            battery.addEventListener(hmSensor.event.CHANGE, function() {
          //              scale_call();
          //            });

          normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 51,
           y: 295,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 1,
           angle: 62,
           align_h: hmUI.align.RIGHT,
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_humidity_text_text_img_0 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 37,
           y: 224,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 1,
           angle: -82,
           align_h: hmUI.align.RIGHT,
           type: hmUI.data_type.HUMIDITY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 313,
           y: 380,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 1,
           angle: -34,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          //              x: 147,
          //              y: 53,
          //              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
          //              padding: false,
          //              h_space: 1,
          //              angle: -21,
          //              unit_sc: 'dig_a_p.png',
          //              unit_tc: 'dig_a_p.png',
          //              unit_en: 'dig_a_p.png',
          //              negative_image: 'dig_a_m.png',
          //              invalid_image: 'dig_a_p.png',
          //              align_h: hmUI.align.LEFT,
          //              type: hmUI.data_type.WEATHER_HIGH,
          //              show_level: hmUI.show_level.ONLY_NORMAL,
          //            });

          //            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          //              x: 99,
          //              y: 82,
          //              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
          //              padding: false,
          //              h_space: 1,
          //              angle: -34,
          //              unit_sc: 'dig_a_p.png',
          //              unit_tc: 'dig_a_p.png',
          //              unit_en: 'dig_a_p.png',
          //              negative_image: 'dig_a_m.png',
          //              invalid_image: 'dig_a_p.png',
          //              align_h: hmUI.align.RIGHT,
          //              type: hmUI.data_type.WEATHER_LOW,
          //              show_level: hmUI.show_level.ONLY_NORMAL,
          //            });

          WEATHER_HIGH_LOW_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
           x: 28,
           y: 28,
           w: (466 - 28 * 2),
           h: (466 - 28 * 2),
           text_size: 35,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFF,
           //text: "2022/05/29 12:23:59 SAT",
           // align_v: hmUI.align.TOP, //CENTER_V	
           align_h: hmUI.align.CENTER_H, //CENTER_H
           char_space: 0,
           start_angle: -80 - 5 - 5,
           end_angle: 30,
           unit_type: 0,
           type: hmUI.data_type.WEATHER_HIGH_LOW,
           show_level: hmUI.show_level.ONLY_NORMAL,
          })

          normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 55,
           y: 141,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 1,
           angle: -57,
           unit_sc: 'dig_a_p.png',
           unit_tc: 'dig_a_p.png',
           unit_en: 'dig_a_p.png',
           negative_image: 'dig_a_m.png',
           invalid_image: 'dig_a_p.png',
           align_h: hmUI.align.RIGHT,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 293,
           y: 18,
           image_array: ["wt_0.png", "wt_1.png", "wt_2.png", "wt_3.png", "wt_4.png", "wt_5.png", "wt_6.png", "wt_7.png", "wt_8.png", "wt_9.png", "wt_10.png", "wt_11.png", "wt_12.png", "wt_13.png", "wt_14.png", "wt_15.png", "wt_16.png", "wt_17.png", "wt_18.png", "wt_19.png", "wt_20.png", "wt_21.png", "wt_22.png", "wt_23.png", "wt_24.png", "wt_25.png", "wt_26.png", "wt_27.png", "wt_28.png"],
           image_length: 29,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_weather_image_progress_img_level_1 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 211,
           y: 27,
           image_array: ["w_0.png", "w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png"],
           image_length: 29,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_zak_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 385,
           src: 'ic_zak.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_vos_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 385,
           src: 'ic_vos.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_sunrise_TextCircle_ASCIIARRAY[0] = 'dig_b_0.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[1] = 'dig_b_1.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[2] = 'dig_b_2.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[3] = 'dig_b_3.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[4] = 'dig_b_4.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[5] = 'dig_b_5.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[6] = 'dig_b_6.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[7] = 'dig_b_7.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[8] = 'dig_b_8.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[9] = 'dig_b_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_sunrise_TextCircle_img_width / 2,
            pos_y: 233 + 175,
            src: 'dig_b_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block


          normal_sunset_TextCircle_ASCIIARRAY[0] = 'dig_b_0.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[1] = 'dig_b_1.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[2] = 'dig_b_2.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[3] = 'dig_b_3.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[4] = 'dig_b_4.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[5] = 'dig_b_5.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[6] = 'dig_b_6.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[7] = 'dig_b_7.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[8] = 'dig_b_8.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[9] = 'dig_b_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_sunset_TextCircle_img_width / 2,
            pos_y: 233 + 175,
            src: 'dig_b_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };

          normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 233,
           center_y: 233,
           start_angle: -162,
           end_angle: 162,
           radius: 154,
           line_width: 14,
           corner_flag: 3,
           color: 0xFFFF0000,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 176,
           y: 343,
           src: 'bg_fix_data.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          ic_step_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 208,
           y: 442,
           src: 'ic_step_txt.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          ic_finish_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 208,
           y: 442,
           src: 'ic_finish_txt.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          ic_finish_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 208,
           y: 442,
           src: 'ic_finish_txt.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
           month_startX: 227,
           month_startY: 344,
           month_sc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_tc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_en_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_is_character: true,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
           day_startX: 184,
           day_startY: 350,
           day_sc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_tc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_en_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_zero: 1,
           day_space: 1,
           day_align: hmUI.align.LEFT,
           day_is_character: false,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
           x: 102,
           y: 168,
           src: checkBT ? 'slider_B_on.png' : 'slider_B_off.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
           x: 359,
           y: 168,
           src: everyHourVibro ? 'slider_H_on.png' : 'slider_H_off.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_ALARM_CLOCKt_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 293,
           y: 162,
           font_array: ["dig_al_0.png", "dig_al_1.png", "dig_al_2.png", "dig_al_3.png", "dig_al_4.png", "dig_al_5.png", "dig_al_6.png", "dig_al_7.png", "dig_al_8.png", "dig_al_9.png"],
           padding: true,
           h_space: 0,
           invalid_image: 'dig_al_p.png',
           dot_image: 'dig_al_10.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.ALARM_CLOCK,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          function scale_call() {

           let valueBattery = battery.getCurrent();
           let targetBattery = 100;
           let progressBattery = valueBattery / targetBattery;
           if (progressBattery > 1) progressBattery = 1;
           let progress_cs_normal_battery = progressBattery;


           // normal_battery_circle_scale_circle_scale
           let level = Math.round(progress_cs_normal_battery * 100);
           if (normal_battery_circle_scale) {
            normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
             center_x: 233,
             center_y: 233,
             start_angle: 229,
             end_angle: 262,
             radius: 217,
             line_width: 16,
             corner_flag: 3,
             color: color_bg[color],
             show_level: hmUI.show_level.ONLY_NORMAL,
             level: level,
            });
           };

           let valueStep = step.getCurrent();
           let targetStep = step.getTarget();
           let progressStep = valueStep / targetStep;
           if (progressStep > 1) progressStep = 1;
           let progress_cs_normal_step = progressStep;


           // normal_step_circle_scale_circle_scale
           let level_Step = Math.round(progress_cs_normal_step * 100);
           if (normal_step_circle_scale) {
            normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
             center_x: 233,
             center_y: 233,
             start_angle: -162,
             end_angle: 162,
             radius: 154,
             line_width: 14,
             corner_flag: 3,
             color: color_bg[color],
             show_level: hmUI.show_level.ONLY_NORMAL,
             level: level_Step,
            });
           };
          };


          function text_update() {

           console.log('update text circle step_STEP');
           let valueStep = step.getCurrent();
           let normal_step_circle_string = parseInt(valueStep).toString();

           // if (screenType != hmSetting.screen_type.AOD) {
           for (var i = 1; i < 5; i++) { // hide all symbols
            normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_step = 360;
           if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) { // display data if it was possible to get it
            let normal_step_TextCircle_img_angle = 0;
            let normal_step_TextCircle_dot_img_angle = 0;
            normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width / 2, 183));
            // alignment = CENTER_H
            let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
            normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
            normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
            char_Angle_step -= normal_step_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_step_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_step -= normal_step_TextCircle_img_angle;
              firstSymbol = false;
              normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_step);
              normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 236 - normal_step_TextCircle_img_width / 2);
              normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
              normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, sport == 0);
              char_Angle_step -= normal_step_TextCircle_img_angle + 1;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           let targetStep = step.getTarget();
           let normal_step_target_circle_string = parseInt(targetStep).toString();

           for (var i = 1; i < 5; i++) { // hide all symbols
            normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_step_target = 360;
           if (targetStep != null && targetStep != undefined && isFinite(targetStep) && normal_step_target_circle_string.length > 0 && normal_step_target_circle_string.length < 6) { // display data if it was possible to get it
            let normal_step_target_TextCircle_img_angle = 0;
            let normal_step_target_TextCircle_dot_img_angle = 0;
            normal_step_target_TextCircle_img_angle = toDegree(Math.atan2(normal_step_target_TextCircle_img_width / 2, 183));
            // alignment = CENTER_H
            let normal_step_target_TextCircle_angleOffset = normal_step_target_TextCircle_img_angle * (normal_step_target_circle_string.length - 1);
            normal_step_target_TextCircle_angleOffset = normal_step_target_TextCircle_angleOffset + 1 * (normal_step_target_circle_string.length - 1) / 2;
            normal_step_target_TextCircle_angleOffset = -normal_step_target_TextCircle_angleOffset;
            char_Angle_step_target -= normal_step_target_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_step_target_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_step_target -= normal_step_target_TextCircle_img_angle;
              firstSymbol = false;
              normal_step_target_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_step_target);
              normal_step_target_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_target_TextCircle_img_width / 2);
              normal_step_target_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_target_TextCircle_ASCIIARRAY[charCode]);
              normal_step_target_TextCircle[index].setProperty(hmUI.prop.VISIBLE, sport == 1);
              char_Angle_step_target -= normal_step_target_TextCircle_img_angle + 1;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           let sunrise_hour = 0;
           let sunrise_minute = 0;
           if (sunData.count > 0) {
            sunrise_hour = sunData.data[0].sunrise.hour;
            sunrise_minute = sunData.data[0].sunrise.minute;
           }; // end sunData;

           console.log('update text circle sunData');
           let sunriseTime = undefined;
           let normal_sunrise_circle_string = undefined;
           if (sunrise_hour != 0 && sunrise_minute != 0) {
            sunriseTime = 0;
            normal_sunrise_circle_string = String(sunrise_hour) + '.' + String(sunrise_minute).padStart(2, '0');
           };

           //if (screenType != hmSetting.screen_type.AOD) {
           for (var i = 1; i < 5; i++) { // hide all symbols
            normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_sunrise = 394;
           if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length < 6) { // display data if it was possible to get it
            let normal_sunrise_TextCircle_img_angle = 0;
            let normal_sunrise_TextCircle_dot_img_angle = 0;
            normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width / 2, 185));
            normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width / 2, 185));
            // alignment = CENTER_H
            let normal_sunrise_TextCircle_angleOffset = normal_sunrise_TextCircle_img_angle * (normal_sunrise_circle_string.length - 1);
            normal_sunrise_TextCircle_angleOffset = -normal_sunrise_TextCircle_angleOffset;
            char_Angle_sunrise -= normal_sunrise_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_sunrise_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_sunrise -= normal_sunrise_TextCircle_img_angle;
              firstSymbol = false;
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_img_width / 2);
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
              char_Angle_sunrise -= normal_sunrise_TextCircle_img_angle;
              index++;
             } // end if digit
             else {
              if (!firstSymbol) char_Angle_sunrise -= normal_sunrise_TextCircle_dot_img_angle;
              firstSymbol = false;
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_dot_width / 2);
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_b_dot2.png');
              normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
              char_Angle_sunrise -= normal_sunrise_TextCircle_dot_img_angle;
              index++;
             }; // end if dot point 
            }; // end char of string
           } // end isFinite

           //  };

           let sunset_hour = 0;
           let sunset_minute = 0;
           if (sunData.count > 0) {
            sunset_hour = sunData.data[0].sunset.hour;
            sunset_minute = sunData.data[0].sunset.minute;
           }; // end sunData;

           console.log('update text circle sunData');
           let sunsetTime = undefined;
           let normal_sunset_circle_string = undefined;
           if (sunset_hour != 0 && sunset_minute != 0) {
            sunsetTime = 0;
            normal_sunset_circle_string = String(sunset_hour) + '.' + String(sunset_minute).padStart(2, '0');
           };

           //if (screenType != hmSetting.screen_type.AOD) {
           for (var i = 1; i < 5; i++) { // hide all symbols
            normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_sunset = 394;
           if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length < 6) { // display data if it was possible to get it
            let normal_sunset_TextCircle_img_angle = 0;
            let normal_sunset_TextCircle_dot_img_angle = 0;
            normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width / 2, 185));
            normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width / 2, 185));
            // alignment = CENTER_H
            let normal_sunset_TextCircle_angleOffset = normal_sunset_TextCircle_img_angle * (normal_sunset_circle_string.length - 1);
            normal_sunset_TextCircle_angleOffset = -normal_sunset_TextCircle_angleOffset;
            char_Angle_sunset -= normal_sunset_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_sunset_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_sunset -= normal_sunset_TextCircle_img_angle;
              firstSymbol = false;
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_img_width / 2);
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
              char_Angle_sunset -= normal_sunset_TextCircle_img_angle;
              index++;
             } // end if digit
             else {
              if (!firstSymbol) char_Angle_sunset -= normal_sunset_TextCircle_dot_img_angle;
              firstSymbol = false;
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_dot_width / 2);
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_b_dot2.png');
              normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
              char_Angle_sunset -= normal_sunset_TextCircle_dot_img_angle;
              index++;
             }; // end if dot point 
            }; // end char of string
           } // end isFinite


           let valueCalories = barometer.getAirPressure() * 0.750064;
           let normal_calorie_circle_string = parseInt(valueCalories).toString();

           for (var i = 1; i < 4; i++) { // hide all symbols
            normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_calorie = 33;
           if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) { // display data if it was possible to get it
            let normal_calorie_TextCircle_img_angle = 0;
            let normal_calorie_TextCircle_dot_img_angle = 0;
            normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width / 2, 183));
            // alignment = CENTER_H
            let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
            normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 1 * (normal_calorie_circle_string.length - 1) / 2;
            char_Angle_calorie -= normal_calorie_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_calorie_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 4) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_calorie += normal_calorie_TextCircle_img_angle;
              firstSymbol = false;
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_calorie);
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
              char_Angle_calorie += normal_calorie_TextCircle_img_angle + 1;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


          };


          anim_sec_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 467,
           h: 467,
           pos_x: 385 - 2,
           pos_y: 211,
           center_x: 400 - 2,
           center_y: 226,
           angle: 0,
           src: 'ic_sec.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          anim_sector_time()

          bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'tap/bg_edit.png',
           show_level: hmUI.show_level.ONLY_EDIT,
          });

          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {
            stopVibro();
            statusBT_last = hmBle.connectStatus();
            // updateWeather();			   
            updateGrafik();

            onDigitalCrown();


            let animRepeat = 1000;
            update_sec = setInterval(() => {


             let airPressure = barometer.getAirPressure() * 0.750064;
             let baroAngle = Math.round((airPressure - 760) * 2); //угол от -144 до 144     144 / (800 - 760) = 3,6 градуса - 1 мм рт.ст
             normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.ANGLE, baroAngle);


             scale_call();
             text_update()


            }, animRepeat); // end timer


           }),

           pause_call: (function () {
            anim_sector_time = false
            hmInteraction.offDigitalCrown();
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);
            group_tip_AOD.setProperty(hmUI.prop.VISIBLE, false);
            clearInterval(update_sec)
            stopVibro();
           }),
          });


          group_tip_AOD = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          groupSport = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          normal_digital_clock_img_time_1 = groupSport.createWidget(hmUI.widget.IMG_TIME, {
           hour_startX: 165,
           hour_startY: 284,
           hour_array: ["H1_0.png", "H1_1.png", "H1_2.png", "H1_3.png", "H1_4.png", "H1_5.png", "H1_6.png", "H1_7.png", "H1_8.png", "H1_9.png"],
           hour_zero: 1,
           hour_space: 0,
           hour_angle: 0,
           hour_unit_sc: 'H1_10.png',
           hour_unit_tc: 'H1_10.png',
           hour_unit_en: 'H1_10.png',
           hour_align: hmUI.align.CENTER_H,

           minute_startX: 249,
           minute_startY: 184,
           minute_array: ["H1_0.png", "H1_1.png", "H1_2.png", "H1_3.png", "H1_4.png", "H1_5.png", "H1_6.png", "H1_7.png", "H1_8.png", "H1_9.png"],
           minute_zero: 1,
           minute_space: 0,
           minute_angle: 0,
           minute_follow: 1,
           minute_align: hmUI.align.CENTER_H,

           second_startX: 284,
           second_startY: 295,
           second_array: ["S1_0.png", "S1_1.png", "S1_2.png", "S1_3.png", "S1_4.png", "S1_5.png", "S1_6.png", "S1_7.png", "S1_8.png", "S1_9.png"],
           second_zero: 1,
           second_space: 0,
           second_angle: 0,
           second_follow: 0,
           second_align: hmUI.align.CENTER_H,

           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_step_current_text_img = groupSport.createWidget(hmUI.widget.TEXT_IMG, {
           x: 160,
           y: 142,
           font_array: ["dig_d_0.png", "dig_d_1.png", "dig_d_2.png", "dig_d_3.png", "dig_d_4.png", "dig_d_5.png", "dig_d_6.png", "dig_d_7.png", "dig_d_8.png", "dig_d_9.png"],
           padding: false,
           h_space: 2,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_distance_text_text_img = groupSport.createWidget(hmUI.widget.TEXT_IMG, {
           x: 173,
           y: 203,
           font_array: ["dig_e_0.png", "dig_e_1.png", "dig_e_2.png", "dig_e_3.png", "dig_e_4.png", "dig_e_5.png", "dig_e_6.png", "dig_e_7.png", "dig_e_8.png", "dig_e_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_e_km.png',
           unit_tc: 'dig_e_km.png',
           unit_en: 'dig_e_km.png',
           dot_image: 'dig_e_dot.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.DISTANCE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_calorie_current_text_img = groupSport.createWidget(hmUI.widget.TEXT_IMG, {
           x: 153,
           y: 242,
           font_array: ["dig_k_0.png", "dig_k_1.png", "dig_k_2.png", "dig_k_3.png", "dig_k_4.png", "dig_k_5.png", "dig_k_6.png", "dig_k_7.png", "dig_k_8.png", "dig_k_9.png"],
           padding: false,
           h_space: 1,
           unit_sc: 'dig_k_kalor.png',
           unit_tc: 'dig_k_kalor.png',
           unit_en: 'dig_k_kalor.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          }); // 


          btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            click_Pogoda_on();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_on();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_checkBT = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 91,
           y: 132,
           text: '',
           w: 100,
           h: 51,
           normal_src: 'blank.png',
           press_src: 'press.png',
           click_func: () => {
            vibro();
            toggleСheckConnection();
           },
           longpress_func: () => {
            vibro();
            menu_tip_AOD();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_HourVibro = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 276,
           y: 132,
           text: '',
           w: 100,
           h: 51,
           normal_src: 'blank.png',
           press_src: 'press.png',
           click_func: () => {
            vibro();
            toggleEveryHourVibro();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 0,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_run();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_sport = hmUI.createWidget(hmUI.widget.BUTTON, {
           x: 357,
           y: 277,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            run_sport();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          //          btn_select_zona = groupVremya.createWidget(hmUI.widget.BUTTON, {
          //           x: 183,
          //           y: 77,
          //           text: '',
          //           w: 100,
          //           h: 42,
          //           normal_src: '0_Empty.png',
          //           press_src: '0_Empty.png',
          //           click_func: () => {
          //            vibro();
          //            click_select_zona();
          //           },
          //           show_level: hmUI.show_level.ONLY_NORMAL,
          //          });


          groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          groupTap.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'tap/i_tap_bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           src: apps[tap_2_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           src: apps[tap_3_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           src: apps[tap_4_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           src: apps[tap_5_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           src: apps[tap_6_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_1_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_2_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_3_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_4_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_5_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_6_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_zona_exit();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          tip_AOD_bg = group_tip_AOD.createWidget(hmUI.widget.FILL_RECT, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: 0x000000,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          titl_text = group_tip_AOD.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 35 - 5,
           w: 466,
           h: 50,
           text: 'Тип AOD',
           //font: 'Zepp OS Number.ttf',
           color: 0xffffff,
           text_size: 45,
           char_space: -0,
           text_style: hmUI.text_style.NONE,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V, //hmUI.align.RIGHT
           //type: hmUI.data_type.DATA,
           show_level: hmUI.show_level.ONLY_NORMAL
          });

          AOD_tip_0 = group_tip_AOD.createWidget(hmUI.widget.STROKE_RECT, {
           x: 117,
           y: 108 + 25 + 100 * 0,
           w: 233,
           h: 59,
           color: curAODmode == 0 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          AOD_tip_1 = group_tip_AOD.createWidget(hmUI.widget.STROKE_RECT, {
           x: 117,
           y: 108 + 25 + 100 * 1,
           w: 233,
           h: 59,
           color: curAODmode == 1 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          group_tip_AOD.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 140 - 5 + 100 * 0,
           w: 466,
           h: 50,
           text: 'Пустой AOD',
           color: 0xffffff,
           text_size: 30,
           char_space: 0,
           text_style: hmUI.text_style.NONE,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V, //hmUI.align.RIGHT
           //type: hmUI.data_type.DATA,
           show_level: hmUI.show_level.ONLY_NORMAL
          });

          group_tip_AOD.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 140 - 5 + 100 * 1,
           w: 466,
           h: 50,
           text: 'Графика AOD',
           color: 0xffffff,
           text_size: 30,
           char_space: 0,
           text_style: hmUI.text_style.NONE,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V, //hmUI.align.RIGHT
           //type: hmUI.data_type.DATA,
           show_level: hmUI.show_level.ONLY_NORMAL
          });

          btn_tip_AOD_0 = group_tip_AOD.createWidget(hmUI.widget.BUTTON, {
           x: 117,
           y: 108 + 25 + 100 * 0,
           w: 233,
           h: 59,
           text: '',
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            curAODmode = 0;
            hmStorage.localStorage.setItem('MND_D1_S_aod', curAODmode);
            select_tip_AOD();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_tip_AOD_1 = group_tip_AOD.createWidget(hmUI.widget.BUTTON, {
           x: 117,
           y: 108 + 25 + 100 * 1,
           w: 233,
           h: 59,
           text: '',
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            curAODmode = 1;
            hmStorage.localStorage.setItem('MND_D1_S_aod', curAODmode);
            select_tip_AOD();

           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          group_tip_AOD.createWidget(hmUI.widget.IMG, {
           x: 183,
           y: 354,
           src: 'undo.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_tip_AOD_exit = group_tip_AOD.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 354,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tip_AOD_exit();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //---------------------------    погода
          groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          normal_background_bg_Grafik = groupPogoda.createWidget(hmUI.widget.FILL_RECT, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: '0xFF222425',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_altimeter_pointer_progress_img_pointer = groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: ROOTPATH + 'Grafik/str_mrs.png',
           center_x: 233,
           center_y: 233,
           pos_x: 0,
           pos_y: 0,
           //              start_angle: -80,
           //              end_angle: 80,
           angle: 0,
           //invalid_visible: false,
           // type: hmUI.data_type.ALTIMETER,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_sun_icon_img = groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 68,
           y: 0,
           src: ROOTPATH + 'Grafik/sun_bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

         normal_sun_pointer_progress_img_pointer = groupPogoda.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_sun.png',
           center_x: 233,
           center_y: 233,
           x: 233,
           y: 233,
           start_angle: -45,
           end_angle: 45,
           invalid_visible: false,
           type: hmUI.data_type.SUN_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
			 
			 
       	normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 0);
			 
			 
            normal_moon_pointer_progress_img_pointer = groupPogoda.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_moon.png',
           center_x: 233,
           center_y: 233,
           x: 233,
           y: 233,
           start_angle: -45,
           end_angle: 45,
           invalid_visible: false,
           type: hmUI.data_type.MOON_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });	
			 

          // фон
          groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: ROOTPATH + 'Grafik/Grafik_bg.png',
           //alpha: 153,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_sun_low_text_font = groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
           x: 168,
           y: 56,
           w: 233,
           h: 50,
           text_size: 35,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.TOP,
           text_style: hmUI.text_style.NONE,
           type: hmUI.data_type.SUN_SET,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_sun_high_text_font = groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
           x: 73,
           y: 56,
           w: 233,
           h: 50,
           text_size: 35,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.TOP,
           text_style: hmUI.text_style.NONE,
           type: hmUI.data_type.SUN_RISE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

                     normal_moon_low_text_font = groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
                      x: 168 - 5,
                      y: 56,
                      w: 233,
                      h: 50,
                      text_size: 35,
                      char_space: 0,
                      line_space: 0,
                      font: 'fonts/Bebas11.ttf',
                      color: 0xFF009CFF,
                      align_h: hmUI.align.CENTER_H,
                      align_v: hmUI.align.TOP,
                      text_style: hmUI.text_style.NONE,
                      type: hmUI.data_type.MOON_SET,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                     });
          
          
          
                      normal_moon_high_text_font = groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 73,
                        y: 56,
                        w: 233,
                        h: 50,
                        text_size: 35,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/Bebas11.ttf',
                        color: 0xFF009CFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.TOP,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.MOON_RISE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                      });			 


          normal_wind_icon_img = groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 387,
           y: 76,
           src: ROOTPATH + 'Grafik/cap_wind.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_wind_direction_image_progress_img_level = groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 387,
           y: 165,
           image_array: [ROOTPATH + "Grafik/wind_0.png", ROOTPATH + "Grafik/wind_1.png", ROOTPATH + "Grafik/wind_2.png", ROOTPATH + "Grafik/wind_3.png", ROOTPATH + "Grafik/wind_4.png", ROOTPATH + "Grafik/wind_5.png", ROOTPATH + "Grafik/wind_6.png", ROOTPATH + "Grafik/wind_7.png"],
           image_length: 8,
           type: hmUI.data_type.WIND_DIRECTION,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_wind_pointer_progress_img_pointer = groupPogoda.createWidget(hmUI.widget.IMG_POINTER, {
           src: ROOTPATH + 'Grafik/str_wind.png',
           center_x: 233,
           center_y: 233,
           x: 15,
           y: 220,
           start_angle: 132,
           end_angle: 49,
           invalid_visible: false,
           type: hmUI.data_type.WIND,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_WEATHER_CURRENT_pointer_progress_img_pointer = groupPogoda.createWidget(hmUI.widget.IMG_POINTER, {
           src: ROOTPATH + 'Grafik/str_wind.png',
           center_x: 233,
           center_y: 233,
           x: 15,
           y: 220,
           start_angle: -121,
           end_angle: -59,
           invalid_visible: false,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_high_text_img = groupPogoda.createWidget(hmUI.widget.TEXT_IMG, {
           x: 38,
           y: 100,
           font_array: [ROOTPATH + "Grafik/dig_graf_0.png", ROOTPATH + "Grafik/dig_graf_1.png", ROOTPATH + "Grafik/dig_graf_2.png", ROOTPATH + "Grafik/dig_graf_3.png", ROOTPATH + "Grafik/dig_graf_4.png", ROOTPATH + "Grafik/dig_graf_5.png", ROOTPATH + "Grafik/dig_graf_6.png", ROOTPATH + "Grafik/dig_graf_7.png", ROOTPATH + "Grafik/dig_graf_8.png", ROOTPATH + "Grafik/dig_graf_9.png"],
           padding: false,
           h_space: 0,
           angle: -51,
           unit_sc: ROOTPATH + 'Grafik/dig_graf_p.png',
           unit_tc: ROOTPATH + 'Grafik/dig_graf_p.png',
           unit_en: ROOTPATH + 'Grafik/dig_graf_p.png',
           negative_image: ROOTPATH + 'Grafik/dig_graf_m.png',
           invalid_image: ROOTPATH + 'Grafik/dig_graf_v.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WEATHER_HIGH,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_low_text_img = groupPogoda.createWidget(hmUI.widget.TEXT_IMG, {
           x: 39,
           y: 341,
           font_array: [ROOTPATH + "Grafik/dig_graf_0.png", ROOTPATH + "Grafik/dig_graf_1.png", ROOTPATH + "Grafik/dig_graf_2.png", ROOTPATH + "Grafik/dig_graf_3.png", ROOTPATH + "Grafik/dig_graf_4.png", ROOTPATH + "Grafik/dig_graf_5.png", ROOTPATH + "Grafik/dig_graf_6.png", ROOTPATH + "Grafik/dig_graf_7.png", ROOTPATH + "Grafik/dig_graf_8.png", ROOTPATH + "Grafik/dig_graf_9.png"],
           padding: false,
           h_space: 0,
           angle: 51,
           unit_sc: ROOTPATH + 'Grafik/dig_graf_p.png',
           unit_tc: ROOTPATH + 'Grafik/dig_graf_p.png',
           unit_en: ROOTPATH + 'Grafik/dig_graf_p.png',
           negative_image: ROOTPATH + 'Grafik/dig_graf_m.png',
           invalid_image: ROOTPATH + 'Grafik/dig_graf_v.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WEATHER_LOW,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_current_text_img = groupPogoda.createWidget(hmUI.widget.TEXT_IMG, {
           x: 49,
           y: 246,
           font_array: [ROOTPATH + "Grafik/dig_graf_0.png", ROOTPATH + "Grafik/dig_graf_1.png", ROOTPATH + "Grafik/dig_graf_2.png", ROOTPATH + "Grafik/dig_graf_3.png", ROOTPATH + "Grafik/dig_graf_4.png", ROOTPATH + "Grafik/dig_graf_5.png", ROOTPATH + "Grafik/dig_graf_6.png", ROOTPATH + "Grafik/dig_graf_7.png", ROOTPATH + "Grafik/dig_graf_8.png", ROOTPATH + "Grafik/dig_graf_9.png"],
           padding: false,
           h_space: 0,
           angle: -90,
           unit_sc: ROOTPATH + 'Grafik/dig_graf_g.png',
           unit_tc: ROOTPATH + 'Grafik/dig_graf_g.png',
           unit_en: ROOTPATH + 'Grafik/dig_graf_g.png',
           negative_image: ROOTPATH + 'Grafik/dig_graf_m.png',
           invalid_image: ROOTPATH + 'Grafik/dig_graf_v.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_humidity_icon_img = groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 385,
           y: 73,
           src: ROOTPATH + 'Grafik/cap_vlag.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_humidity_pointer_progress_img_pointer = groupPogoda.createWidget(hmUI.widget.IMG_POINTER, {
           src: ROOTPATH + 'Grafik/str_wind.png',
           center_x: 233,
           center_y: 233,
           x: 15,
           y: 220,
           start_angle: 132,
           end_angle: 49,
           invalid_visible: false,
           type: hmUI.data_type.HUMIDITY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_humidity_text_text_img = groupPogoda.createWidget(hmUI.widget.TEXT_IMG, {
           x: 391,
           y: 190,
           font_array: [ROOTPATH + "Grafik/dig_graf_0.png", ROOTPATH + "Grafik/dig_graf_1.png", ROOTPATH + "Grafik/dig_graf_2.png", ROOTPATH + "Grafik/dig_graf_3.png", ROOTPATH + "Grafik/dig_graf_4.png", ROOTPATH + "Grafik/dig_graf_5.png", ROOTPATH + "Grafik/dig_graf_6.png", ROOTPATH + "Grafik/dig_graf_7.png", ROOTPATH + "Grafik/dig_graf_8.png", ROOTPATH + "Grafik/dig_graf_9.png"],
           padding: false,
           h_space: 0,
           angle: 90,
           align_h: hmUI.align.RIGHT,
           type: hmUI.data_type.HUMIDITY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_humidity_text_separator_img = groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 392,
           y: 236,
           src: ROOTPATH + 'Grafik/dig_graf_pr_fix.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_uvi_icon_img = groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 387,
           y: 75,
           src: ROOTPATH + 'Grafik/cap_uf.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_uvi_pointer_progress_img_pointer = groupPogoda.createWidget(hmUI.widget.IMG_POINTER, {
           src: ROOTPATH + 'Grafik/str_wind.png',
           center_x: 233,
           center_y: 233,
           x: 15,
           y: 220,
           start_angle: 132,
           end_angle: 49,
           invalid_visible: false,
           type: hmUI.data_type.UVI,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_uvi_text_text_img = groupPogoda.createWidget(hmUI.widget.TEXT_IMG, {
           x: 391,
           y: 219,
           font_array: [ROOTPATH + "Grafik/dig_graf_0.png", ROOTPATH + "Grafik/dig_graf_1.png", ROOTPATH + "Grafik/dig_graf_2.png", ROOTPATH + "Grafik/dig_graf_3.png", ROOTPATH + "Grafik/dig_graf_4.png", ROOTPATH + "Grafik/dig_graf_5.png", ROOTPATH + "Grafik/dig_graf_6.png", ROOTPATH + "Grafik/dig_graf_7.png", ROOTPATH + "Grafik/dig_graf_8.png", ROOTPATH + "Grafik/dig_graf_9.png"],
           padding: false,
           h_space: 0,
           angle: 90,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.UVI,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          for (var i = 0; i < 6; i++) {
           week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: week_weater[i],
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           hmUI.deleteWidget(day_weater_img[i]);

           day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: 31,
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
            x: 98 + i * 45 * 1.02,
            y: 78 + 20,
            w: 40,
            h: 40,
            // src: weatherArray[i],
            shortcut: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

          }


          for (var i = 0; i < 6; i++) {
           hmUI.deleteWidget(linered[i]);
           linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointred[i]);
           pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArray[i]);
           weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
          for (var i = 0; i < 5; i++) {
           hmUI.deleteWidget(lineblue[i]);
           lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointblue[i]);
           pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArrayN[i]);
           weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }

          btn_Grafik_zona_right_0 = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 0, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Grafik_zona_right_0();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Grafik_zona_right = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 366, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Grafik_zona_right();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Pogoda_off();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_off();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          for (var i = 1; i < 5; i++) { // hide all symbols
           normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, sport == 0);
           normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, sport == 1);
          };

          normal_vos_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_zak_icon_img.setProperty(hmUI.prop.VISIBLE, false);

          ic_finish_img.setProperty(hmUI.prop.VISIBLE, false);
          sport_image_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
          ic_finish_txt_img.setProperty(hmUI.prop.VISIBLE, false);


          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          group_tip_AOD.setProperty(hmUI.prop.VISIBLE, false);
          groupSport.setProperty(hmUI.prop.VISIBLE, false);


          normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 1);
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 2);
          normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 2);
          normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right == 2);
			 
         normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 1);

          	normal_moon_low_text_font.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 1);
          	normal_moon_high_text_font.setProperty(hmUI.prop.VISIBLE, Grafik_zona_right_0 == 1);


          checkConnection(checkBT);
          setEveryHourVibro();


          //dynamic modify end
         }


         __$$module$$__.module = WatchFace({
          onInit() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) loadSettings();
          },
          build() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) {
            makeAOD();
           } else {
            init_view();
           }
          },
          onPause() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: Ставлюсь на паузу!"});
           //else hmUI.showToast({text: "Ставлюсь на паузу!"});
          },
          onResume() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: И снова здравствуйте!!!"});
           //else hmUI.showToast({text: "И снова здравствуйте!!!"});
          },
          onDestroy() {
           vibrate && vibrate.stop();
           offDigitalCrown();
          }
         });

        }
       }.bind(__$$G$$__)(__$$G$$__);


      afterPageCreate()
      afterModuleCreate()

     })()
    } catch (e) {

     console.log('Mini Program Error', e)
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i))

     /* todo */
    }

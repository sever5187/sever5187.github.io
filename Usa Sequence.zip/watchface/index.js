﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
    width: D_W,
    height: D_H
   } = hmSetting.getDeviceInfo();

    const packageInfo = hmApp.packageInfo(); 
    WF_ID = packageInfo.appId;	
		
   const baro = hmSensor.createSensor(hmSensor.id.BARO);
    const pressureValue = baro.pressure;
    const altitudeValue = baro.altitude;
    
      const windDirectionStr = [
       ['Северный', 'N', 'С'], // 0
       ['Сев-Вос', 'NE', 'СВ'], // 1
       ['Восточный', 'E', 'В'], // 2
       ['Юго-Вос', 'SE', 'ЮВ'], // 3
       ['Южный', 'S', 'Ю'], // 4
       ['Юго-Зап', 'SW', 'ЮЗ'], // 5
       ['Западный', 'W', 'З'], // 6
       ['Сев-Зап', 'NW', 'СЗ'], // 7
      ];



function getWindDescription(angle, lang) {
    const normalizedAngle = parseFloat(angle) % 360;
    const index = Math.floor((normalizedAngle + 22.5) / 45) % 8;
    return windDirectionStr[index][lang];
} 
    

 let screenTypeJS = hmSetting.getScreenType();

/********  класс Провайдер погоды  ********/
/******				v1.4			*******/
/******		2025 © leXxiR [4pda]	*******/

	class WeatherProvider {
	  constructor(props = {}) {
		this.props = {
			night_icons: [],											// индексы иконок для замены день-ночь
			index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
			show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
			temp_widget: null,											// виджет TEXT для отображения температуры
			temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
			temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
			temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
chance_Of_Rain: null,									// виджет TEXT для отображения осадков            
			description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
			cityName_widget: null,										// виджет TEXT для отображения названия города
			windDirection_widget: null,										// виджет TEXT для отображения направления ветра
			windSpeed_widget: null,										// виджет TEXT для отображения скорости ветра
			icon_widget: null,											// виджет IMG для отображения значка погоды
			time_sensor: null,											// сенсор времени, если не задан, то создается новый
			weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
			file_name: 'weather.json',									// имя файла с погодными данными
			auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.providers = [
						{name: ['Zepp', 'Zepp'], appId: null},							// 0
						{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
						{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
					]

		this.description = [
				['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
				['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
			]

		this.last = {
			weatherIcon: 25,
			weatherDescription:  'Нет данных',
			temperature: '--',
			temperatureFeels: '--',
			chanceOfRain: '--',
			temperatureMax: '--',
			temperatureMin: '--',
			cityName: '--',
            windDirection: 0,
        windSpeed: '--',
            modTime: null,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
		if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления погоды
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// служебные функции
		arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
			  result += String.fromCharCode(byte1);
			} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result
		}

	// чтение погодных данных из файла
		readFile(app_id) {
		  if (!app_id) return null				
		  let str_result = "";
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			if (err == 0) {
			  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
				appid: app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = this.arrayBufferToCyrillic(array_buffer);

			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return null;
		}

	// получить время последнего изменеия файла
		getFileModTime(app_id) {
		  if (!app_id) return null
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			
			if (err == 0) {
			  return fs_stat.mtime
			} else {
			  console.log("ModTime err:", err);
			}
		  } catch (error) {
			console.log("ModTime error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
			return null
		}

	// проверка времени суток: возвращает true, если сейчас день
		isDayNow() {
			const sunData = this.props.weather_sensor.getForecastWeather().tideData;
			let sunriseMins = 8 * 60;			// время восхода
			let sunsetMins = 20 * 60;			// и заката по умолчанию

			if (sunData.count > 0){
				const today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			}

			const curMins = curTime.hour * 60 + curTime.minute;
			const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

			return nowIsDay
		}


	// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
		getZeppIconIndex(index, app_id = null) {
			
			if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

			let newIndex = 25;
			
			if (app_id == 1065824) {					// WeatherService
				switch(index) {
				   case 1:
						newIndex = 3;
					break;
				   case 2:
						newIndex = 0;
					break;
				   case 3:
				   case 4:
						newIndex = 4;
					break;
				   case 5:
						newIndex = 1;
					break;
				   case 6:
						newIndex = 5;
					break;
				   case 7:
						newIndex = 10;
					break;
				   case 8:
						newIndex = 15;
					break;
				   case 9:
						newIndex = 6;
					break;
				   case 10:
						newIndex = 8;
					break;
				   case 11:
						newIndex = 9;
					break;
				   case 12:
						newIndex = 12;
					break;
				   case 13:
						newIndex = 13;
					break;
				   case 14:
						newIndex = 17;
					break;
				   default:
						newIndex = 25;
					break;
				}
			} else if (app_id == 1066654) {					// RuWeather
				newIndex = index - 1;
			}

			return newIndex
		}

	// температура со знаком
		tempWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}
        
		tempWithSign0(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '' + val;
			val += '';
			
			return val
		}
        
        
		
		rainWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
//			val = Math.round(val);
//			if (val > 0) val = '+' + val;
			val += '';
			
			return val
		}
		

	//получение погодных данных из Zepp
		getZeppWeatherData() {
			const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
			const data = {
				weatherIcon: iconIndex,
				weatherDescription:  this.description[this.props.lang][iconIndex],
				temperature: this.props.weather_sensor.current ?? '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: this.props.weather_sensor.high ?? '--',
				temperatureMin: this.props.weather_sensor.low ?? '--',
				cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
			}

			return data
		}

	//получение погодных данных из файла приложения
		getAppWeatherData(app_id) {
			const data = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
			}

			// читаем данные из файла данных приложения
			let weather_str = this.readFile(app_id);
			let weatherJson = JSON.parse(weather_str);
	  
			if (weatherJson) {
				if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
				  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
				}

				if (weatherJson?.weatherDescriptionExtended?.length) {
				  data.weatherDescription = weatherJson.weatherDescriptionExtended;
				  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());

				} else data.weatherDescription = this.description[data.weatherIcon];

				if (isFinite(weatherJson.temperature)) {
				  data.temperature = parseFloat(weatherJson.temperature);
				  data.temperature = Math.round(data.temperature);
				}
				
				if (isFinite(weatherJson.temperatureFeels)){
					data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
					data.temperatureFeels = Math.round(data.temperatureFeels);
				}
					
				if (isFinite(weatherJson.chanceOfRain)){
					data.chanceOfRain = parseFloat(weatherJson.chanceOfRain);
					data.chanceOfRain = Math.round(data.chanceOfRain);
				}
					
				  
				if (isFinite(weatherJson.temperatureMax)){
					data.temperatureMax = parseFloat(weatherJson.temperatureMax);
					data.temperatureMax = Math.round(data.temperatureMax);
				}
				  
				if (isFinite(weatherJson.temperatureMin)){
					data.temperatureMin = parseFloat(weatherJson.temperatureMin);
					data.temperatureMin = Math.round(data.temperatureMin);
				}
                
				if (isFinite(weatherJson.windDirection)){
					data.windDirection = parseFloat(weatherJson.windDirection);
					//data.windDirection = Math.round(data.windDirection);
				}
                
        if (isFinite(weatherJson.windSpeed)) {
         data.windSpeed = parseFloat(weatherJson.windSpeed);
         data.windSpeed > 10 ? data.windSpeed = Math.round(data.windSpeed) : data.windSpeed = data.windSpeed.toFixed(1);
        }
                
                
				
				if (weatherJson.city) {
				  data.cityName = weatherJson.city;
				}
			}
			
			return data
		}

	//получение погодных данных из файла приложения или Zepp
		getWeatherData(app_id = null) {
			if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
			else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
		}

	// обновить виджеты, используя данные текущего провайдера
		update() {
			let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

			const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
			
			if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
				const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
				this.last.modTime = modTime;

				let val = this.tempWithSign0(newData.temperature);
				if (val != this.last.temperature){
					this.last.temperature = val;
					if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMax);
				if (val != this.last.temperatureMax){
					this.last.temperatureMax = val;
					if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMin);
				if (val != this.last.temperatureMin){
					this.last.temperatureMin = val;
					if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureFeels);
				if (val != this.last.temperatureFeels){
					this.last.temperatureFeels = val;
					if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
				}
					
					val = this.rainWithSign(newData.chanceOfRain);
					if (val != this.last.chanceOfRain){
						this.last.chanceOfRain = val;
						if (this.props.chance_Of_Rain) this.props.chance_Of_Rain.setProperty(hmUI.prop.TEXT, val);
					}	
                    
				val = newData.windDirection;
				if (val != this.last.windDirection){
					this.last.windDirection = val;
					if (this.props.windDirection_widget) this.props.windDirection_widget.setProperty(hmUI.prop.TEXT, val);
				}
                
                
				val = newData.windSpeed;
				if (val != this.last.windSpeed){
					this.last.windSpeed = val;
					if (this.props.windSpeed_widget) this.props.windSpeed_widget.setProperty(hmUI.prop.TEXT, val);
				}
                

				val = newData.cityName;
				if (val != this.last.cityName){
					this.last.cityName = val;
					if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.weatherDescription;
				if (val != this.last.weatherDescription){
					this.last.weatherDescription = val;
					if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
				}

				
				curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
			}

			if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
				curIcon += 'n';
			}

			if (curIcon != this.last.weatherIcon){
				this.last.weatherIcon = curIcon;
				if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, 'w_${curIcon}.png');
			}
		}

	// переключить на следующего провайдера
		next(show_toast = this.props.show_toast) {
			const v = (this.props.index + 1) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить на предыдующего провайдера
		prev(show_toast = this.props.show_toast) {
			const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить назад или вперед
		toggle(dir, show_toast = this.props.show_toast) {
			if (dir > 0) this.next(show_toast)
			else this.prev(show_toast);
		}
		
	// установить провайдера по индексу
		set provider(v) {
			this.props.index = v;
			hmFS.SysProSetInt('WeatherProviderIndex', v);
			this.update();
		}

	// получить индекс текущего провайдера
		get index() {
			return this.props.index
		}

	// получить название текущего провайдера
		get name() {
			return this.providers[this.props.index].name[this.props.lang]
		}
        
	// получить название города
		get cityName() {
			return this.last.cityName
		}

	// получить напрвление ветра
		get windDirection() {
			return this.last.windDirection
		}
        
	// получить скорость ветра
		get windSpeed() {
			return this.last.windSpeed
		}

	// получить текущую температуру
		get temperature() {
			return this.last.temperature
		}

	// получить максимальную температуру
		get temperatureMax() {
			return this.last.temperatureMax
		}

	// получить минимальную температуру
		get temperatureMin() {
			return this.last.temperatureMin
		}

	// получить ощущаемую температуру
		get temperatureFeels() {
			return this.last.temperatureFeels
		}
			
		get chanceOfRain() {
			return this.last.chanceOfRain
		}
			

	// получить описание погоды
		get weatherDescription() {
			return this.last.weatherDescription
		}

	// удалить
	  delete() {
		this.providers = null;
		this.props = null;
		this.last = null;
		this.description = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}			

      
		
      
      let groupVremya = ''
      let groupPogoda = ''
      //let groupTap = ''
      let groupActiv = ''
      //let canvas0 = ''
      //let canvas = ''

      let groupSleep = ''
      let alpha_grey = 76
	  
	  
	  
      let normal_unit_ic_up = ''	  
      let normal_unit_ic_dw = ''	
	  
      let normal_progress_bg_0 = ''	
      let normal_progress_bg_1 = ''	
      let normal_progress_bg_2 = ''	
      let normal_progress_bg_3 = ''	



      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const step = hmSensor.createSensor(hmSensor.id.STEP);
      const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
      const stand = hmSensor.createSensor(hmSensor.id.STAND)
      const pai = hmSensor.createSensor(hmSensor.id.PAI);
      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
      const stress = hmSensor.createSensor(hmSensor.id.STRESS);

let normal_background_bg = ''

let normal_weater_ic = ''


let sleep_time_txt = ''
let sleep_start_time_txt = ''
let sleep_end_time_txt = ''
let sleep_score_txt = ''
let wake_time_txt

const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
let sleepInfo = sleep.getBasicInfo();

let sleepTotalTime = sleep.getTotalTime();
let sleepStartTime = sleepInfo.startTime;
let sleepEndTime = sleepInfo.endTime + 1;
let sleepScore = sleepInfo.score;

//-----------  время пробуждений ------------------		
let sleepStageArray = sleep.getSleepStageData();
const modelData = sleep.getSleepStageModel();
//-------------------------------------------------		

//sleep_time_txt.setProperty(hmUI.prop.TEXT, 'Время сна: ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));


function click_sleep() {
 // groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupSleep.setProperty(hmUI.prop.VISIBLE, true);
}


function click_exit_sleep() {
 // groupVremya.setProperty(hmUI.prop.VISIBLE, true);
 groupSleep.setProperty(hmUI.prop.VISIBLE, false);
}


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}

function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//#endregion

let text_pressere; // отображаем давление
let text_pressere_changes; // отображаем изменение давления 


function makeAOD() {
 //loadSettings()

 const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: (function () {

   stopVibro();
  }),

  pause_call: (function () {

   //    hmApp.unregisterSpinEvent();
   stopVibro();
  }),
 });


}


let Activ_color_alpha = ''
let menu = 0
let color_ic = 0
let Activ_color = 0

function click_Activ_color() {
    Activ_color = (Activ_color + 1) % 2;
    ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
    hmFS.SysProSetInt('PT31', Activ_color);

    if (Activ_color == 1) {
        // Показываем панели выбора цвета и кнопки коронки
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, true);
        // Скрываем исходные кнопки, чтобы они не мешали
        btn_Activ_color.setProperty(hmUI.prop.VISIBLE, false);
        btn_Activ_off.setProperty(hmUI.prop.VISIBLE, false);
        // Обновляем отображение цвета
        updateColorUI(color_ic, color_bg[3]);
        updateProgressArc(color_bg[3].length, color_ic);
    } else {
        // Скрываем панели и возвращаем исходные кнопки
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
        btn_Activ_color.setProperty(hmUI.prop.VISIBLE, true);
        btn_Activ_off.setProperty(hmUI.prop.VISIBLE, true);
    }
}

let Btn_set_ = []
let Shag_Y = 66

let color_bg = [
[0xFF0000, 0xFF4500, 0xDC143C, 0xFF69B4, 0xFF1493, 0xFF8C00, 0xFFA500, 0xFFD700, 0xFFFF00, 0x228B22, 0x32CD32, 0x00FF00, 0x98FF98, 0x50C878, 0x00FFFF, 0x00CED1, 0x40E0D0, 0x7FFFD4, 0x0000FF, 0x1E90FF, 0x007FFF, 0x00008B, 0x4B0082, 0x800080, 0x9932CC, 0x8A2BE2, 0xDA70D6, 0xA52A2A, 0xD2691E, 0x8B4513, 0x926226, 0xFFFFFF, 0xD3D3D3, 0x808080, 0x505050, 0x000000],
[0x0068a4, 0x842721, 0xceb372, 0x59775b, 0x6b3278, 0x5a595b, 0xf29851, 0xbdbebe, 0x444645, 0x765d58],
[0xdfdfdf, 0x7d7c7d, 0xd1cb8d, 0x638672, 0x025591, 0x7e438c, 0xac4b45, 0xf4a462, 0x8f7e7b],
	
[0xff0000, 0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a],
	
	
	
];

let colorNames = ["Красный", "Алый", "Малиновый", "Тёмно-красный", "Бордовый", "Розовый", "Оранжевый", "Горчичный", "Золотой", "Жёлтый", "Лимонный", "Мятный", "Изумрудный", "Лесной зелёный", "Оливковый", "Зелёный", "Бирюзовый", "Голубой", "Лазурный", "Синий", "Тёмно-синий", "Индиго", "Пурпурный", "Пурпурный (маджента)", "Белый", "Медовый", "Бежевый", "Светло-серый", "Серый", "Тёмно-серый", "Коричневый", "Чёрный"];

let app_TF = []
let app_ic = []
let app_ACR_text = []

let app_text_arr = [
 ['КАЛОРИИ', hmUI.data_type.CAL, false, 0, 'ic_app_0.png'],
 ['КМ', hmUI.data_type.DISTANCE, false, 0, 'ic_app_1.png'],
 ['ММ.РТ.СТ', hmUI.data_type.ALTIMETER, false, 0, 'ic_app_2.png'],
 ['ВЫСОТА', hmUI.data_type.ALTITUDE, false, 0, 'ic_app_3.png'],
 ['ВЛАЖНОСТЬ', hmUI.data_type.HUMIDITY, false, 1, 'ic_app_4.png'],
 ['НОЧЬ/ДЕНЬ', hmUI.data_type.WEATHER_HIGH_LOW, false, 0, 'ic_app_5.png'],
 ['ВОСХОД', hmUI.data_type.SUN_RISE, false, 0, 'ic_app_7.png'],
 ['СТРЕСС', hmUI.data_type.STRESS, false, 0, 'ic_app_8.png'],
 ['КИСЛОРОД', hmUI.data_type.SPO2, false, 0, 'ic_app_9.png'],
 ['PAI', hmUI.data_type.PAI_DAILY, false, 0, 'ic_app_10.png'],
 ['ЖИР', hmUI.data_type.FAT_BURNING, false, 0, 'ic_app_11.png'],
 ['УФ', hmUI.data_type.UVI, false, 0, 'ic_app_12.png'],
 ['РАЗМИНКА', hmUI.data_type.STAND, false, 0, 'ic_app_13.png'],
 /* ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true, 0, 'ic_app_14.png'],*/
 ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true, 0, 'ic_app_15.png'],
 ['ЭТАЖ', hmUI.data_type.FLOOR, false, 0, 'ic_app_16.png'],
 ['ВЕТЕР', hmUI.data_type.WIND, false, 0, 'ic_app_17.png'],
 ['ПУЛЬС', hmUI.data_type.HEART, false, 0, 'ic_app_18.png'],
];

let Line_arr = [
 ['C', '--', 'SENS', 'КАЛОРИИ', 0xff791f, '', '--'], //0 калории
 ['L', '--', 0, 'ЭТАЖ', 0x00ff0c, hmUI.data_type.FLOOR, false], //1 ЭТАЖ
 ['^', '--', 'SENS', 'ДАВЛЕНИЕ', 0x12c200, '', '--'], //2 давление
 ['t', '--', 0, 'ГОТОВНОСТЬ', 0xccff66, hmUI.data_type.READINESS, false], //3  ГОТОВНОСТЬ
 ['I', '--', 'SENS', 'PAI', 0xff51d4, '', '--'], //4 pai
 ['O', '--', 'SENS', 'КИСЛОРОД', 0xe400ff, '', '--'], //5 o2
 ['R', '--', 'SENS', 'РАЗМИНКА', 0x01a8ff, '', '--'], //6 разминка
 ['G', '--', 'SENS', 'ЖИР', 0xd7c637, '', '--'], //7 жир
 ['V', '--', 1, 'ВАЛЖНОСТЬ', 0x00ff90, hmUI.data_type.HUMIDITY, false], //8 ВАЛЖНОСТЬ
 ['!', '--', 'SENS', 'СТРЕСС', 0xfcff00, '', '--'], //9 стресс
 ['a', '--', 'SENS', 'СОН', 0x25ced4, '', '--'], //10 сон
 [']', '--', 'SENS', 'ОСАДКИ', 0xFF0000, '', '--'], //11 садки
 ['=', '--', 'SENS', 'ОЩУЩАЕМАЯ', 0xff7e3f, '', '--'], // 12 ощущаемая
 ['W', '--', 'SENS', 'ВЕТЕР', 0x01f6ff, '', '--'], //13 ВЕТЕР
 ['f', '--', 'SENS', 'МИРОВОЕ', 0x21a5d1, '', '--'], //14 МИРОВОЕ
 ['S', '--', 'SENS', 'ШАГИ %', 0x01f6ff, '', '--'], //15 ШАГИ %
 ['U', '--', 0, 'УФ', 0x01f6ff, hmUI.data_type.UVI, false], //16 УФ
 ['E', '--', 'SENS', 'ВЫСОТА', 0x00ff06, '', '--'], //17 ВЫСОТА
 ['T', '--', 0, 'ТАЙМЕР', 0x00ff06, hmUI.data_type.COUNT_DOWN, true], //18 ТАЙМЕР
 ['r', '--', 0, 'AQI', 0xccff33, hmUI.data_type.AQI, false], //19 AQI
 ['K', '--', 'SENS', 'ВОС/ЗАК', 0x01f6ff, '', '--'], //20 ВОС/ЗАК
 ['', '', '', 'ПУСТО'], //21 пусто
];

let CONF_MAIN = [{ // 0. Вертикальный градиент (3 цвета)
 name: 'ЦВЕТ', // кнопка
 id: 0, // при старте
 len: color_bg[0].length, // длина
 type: 'color', // цвет или данные
 colorArrayIndex: 0 // ← явно указываем индекс массива
}, { // 1. Горизонтальный градиент (2 цвета)
 name: 'БЕЗЕЛЬ', // кнопка
 id: 0,
 len: color_bg[2].length, // длина
 type: 'color',
 colorArrayIndex: 2 // ← явно указываем индекс массива
}, { // 2. Одноцветный прямоугольник
 name: '3 КРУГА ТИП', // кнопка
 id: 0,
 len: color_bg[2].length, // длина
 type: 'color',
 colorArrayIndex: 2 // ← явно указываем индекс массива
}, { // 3. Одноцветный прямоугольник
 name: 'АНАЛОГ ВИД', // кнопка
 id: 0,
 len: 4, // длина
 type: 'png',
}, { // 4. Одноцветный прямоугольник
 name: 'АНАЛОГ ЦВЕТ', // кнопка
 id: 0,
 len: color_bg[0].length, // длина
 type: 'color',
 colorArrayIndex: 0 // ← явно указываем индекс массива
}, { // 5. Одноцветный прямоугольник
 name: 'ПРОГРЕСС ВИД', // кнопка
 id: 0,
 len: 2, // длина
 type: 'png',
}, { // 6. Одноцветный прямоугольник
 name: 'ПРОГРЕСС ЦВЕТ', // кнопка
 id: 0,
 len: color_bg[0].length, // длина
 type: 'color', // цвет или данные
 colorArrayIndex: 0 // ← явно указываем индекс массива
},{ // 7. Одноцветный прямоугольник
 name: 'AOD тип', // кнопка
 id: 0,
 len: 3, // длина
 type: 'png_crown_off', // Новый тип - коронка отключается после выхода
}, /*{ // 8. Кнопка конфигурации
  name: 'конфигурация',
  id: 0,
  len: 3, // 3 позиции: 0,1,2
  type: 'save_conf',
 },*/{ // 8. Одноцветный прямоугольник
 name: ['КОРОНКА ОТКЛЮЧЕНА', 'КОРОНКА ВКЛЮЧЕНА'],
 id: 0,
 len: 2,
 type: 'toggle', // тип: переключатель ВКЛ/ВЫКЛ
 //toggleBgColors: [0x800000, 0x008000], // Темно-красный для ОТКЛЮЧЕНА, Зеленый для ВКЛЮЧЕНА
}]

function loadSettings() {
    color_ic = hmFS.SysProGetInt(`${WF_ID}_color_ic`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_color_ic`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_color_ic`);
    tip_grafik = hmFS.SysProGetInt(`${WF_ID}_tip_grafik`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tip_grafik`);

    if (hmFS.SysProGetInt(`${WF_ID}_crown`) === undefined) {
        crown = 0;
        hmFS.SysProSetInt(`${WF_ID}_crown`, crown);
    } else {
        crown = hmFS.SysProGetInt(`${WF_ID}_crown`);
    }

    fix_gsm = hmFS.SysProGetInt(`${WF_ID}_fix_gsm`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_fix_gsm`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_fix_gsm`);
	
    // ЗАГРУЖАЕМ ВСЕ КНОПКИ (включая 7-ю) - УБЕРИТЕ -1
    for (let i = 0; i < CONF_MAIN.length; i++) {
        const defaultValue = CONF_MAIN[i].id;
        CONF_MAIN[i].id = hmFS.SysProGetInt(`${WF_ID}_color_` + i) === undefined
            ? (hmFS.SysProSetInt(`${WF_ID}_color_` + i, defaultValue), defaultValue)
            : hmFS.SysProGetInt(`${WF_ID}_color_` + i);
    }
	
}

let str = 0;
function str_off() {
str = (str + 1)%2
// hmFS.SysProSetInt(`${WF_ID}_str`, str);
//normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, str == 0);	
//normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, str == 0);	
//normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, str == 0);
	
 vibro();
}



      const hour_pointer = [
       [70, 211], // 0
       [60, 148], // 1
       [40, 129], // 2
       [63, 129], // 3
      ];

      const minute_pointer = [
       [61, 207], // 0
       [59, 205], // 1
       [36, 192], // 2
       [61, 207], // 3
      ];

function start_WG() {

 // Для коронки 0 (основной фон)
 const colorInfo0 = getColorInfo(0);
/*   normal_widget_text_3.setProperty(hmUI.prop.COLOR, colorInfo0.colorValue);
normal_widget_text_1.setProperty(hmUI.prop.COLOR, colorInfo0.colorValue);
normal_widget_text_4.setProperty(hmUI.prop.COLOR, colorInfo0.colorValue);
normal_widget_text_5.setProperty(hmUI.prop.COLOR, colorInfo0.colorValue);
normal_widget_text_6.setProperty(hmUI.prop.COLOR, colorInfo0.colorValue);
normal_widget_text_7.setProperty(hmUI.prop.COLOR, colorInfo0.colorValue);
	
            normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 279,
              end_angle: 351,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: colorInfo0.colorValue,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
            normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 171,
              end_angle: 99,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo0.colorValue,
              type: hmUI.data_type.STEP,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
            normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 261,
              end_angle: 189,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo0.colorValue,
              type: hmUI.data_type.BATTERY,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });	


            normal_progress_bg_0.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 279,
              end_angle: 351,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo0.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_1.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 81,
              end_angle: 9,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo0.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_2.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 261,
              end_angle: 189,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo0.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_3.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 171,
              end_angle: 99,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo0.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

 };

let ARC_set = [
 [383, 107, 18],
 [398, 129, 22],
 [412, 159, 26],
 [423, 192, 30],
 [427, 233, 34],
 [423, 274, 30],
 [412, 307, 26],
 [398, 337, 22],
 [383, 359, 18],
]

let menu_ARC_color = [];
let normal_left_data = [];
let normal_right_data = [];
let normal_up_data = [];

function app_update() {
 let distanceCurrent = distance.current;
}
		
		

// Состояния экрана
const SCREEN_STATE = {
    MAIN: 'MAIN',
    SETTINGS: 'SETTINGS', 
    CROWN_MODE: 'CROWN_MODE'
};
		
// Текущее состояние экрана
let currentScreenState = SCREEN_STATE.MAIN;		
		
// ====================== ПОИСК ЭЛЕМЕНТОВ ПО ТИПУ ======================

// Функция для поиска индекса элемента по типу
function findConfigIndex(type) {
    for (let i = 0; i < CONF_MAIN.length; i++) {
        if (CONF_MAIN[i].type === type) {
            return i;
        }
    }
    return -1;
}		
		
let crownSensitivity = 70; // уровень чувствительности колесика
let color = 0;
let color_str = 0;
let bridg = 127;
let crown = 0
let text_start = 70		
		
let set = 0;
let degreeSum = 0;
let MenuCirkl_Timer = null;

let debugCounter = 0;

function showDebug(message) {
    hmUI.showToast({text: message});
}

// ====================== ОБРАБОТКА ЦИФРОВОЙ КОРОНКИ ======================

function onDigitalCrown() {
    hmApp.registerSpinEvent((key, degree) => {
        if (key !== hmApp.key.HOME) return;
        degreeSum += degree;
        if (Math.abs(degreeSum) <= crownSensitivity) return;
        
        const step = Math.sign(degreeSum);
        
        // Находим toggle элемент
        const toggleIndex = findConfigIndex('toggle');
        
        // 1. В состоянии SETTINGS коронка НЕ РАБОТАЕТ
        if (currentScreenState === SCREEN_STATE.SETTINGS) {
            degreeSum = 0;
            return;
        }
        
        // 2. Режим выбора цвета (старый режим)
        if (Activ_color === 1 && menu === 1) {
            handleColorChange(step);
            degreeSum = 0;
            return;
        }
        
        // 3. На главном экране
        if (currentScreenState === SCREEN_STATE.MAIN) {
            // Проверяем, включена ли коронка на главном экране
            if (toggleIndex !== -1 && CONF_MAIN[toggleIndex].id === 0) {
                degreeSum = 0;
                return;
            }
            
            // Для png_crown_off НЕ обрабатываем на главном экране
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'png_crown_off') {
                degreeSum = 0;
                return;
            }
            
            // Меняем параметры
            crown_color(crown, step, false);
            
            // ПОКАЗЫВАЕМ ПРОГРЕСС И ЗАПУСКАЕМ ТАЙМЕР
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'color') {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                updateCrownColorElements();
            }
            updateProgressArc();
            
            // ЗАПУСК ТАЙМЕРА
            if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
            MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
                bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
                Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
                timer.stopTimer(MenuCirkl_Timer);
            });
            
            degreeSum = 0;
            return;
        }
        
        // 4. В режиме коронки
        if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
            // Для toggle типа не обрабатываем
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'toggle') {
                degreeSum = 0;
                return;
            }
            
            // Меняем параметры
            crown_color(crown, step, false);
            
            // Обновляем панель коронки
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            
            // Для цветовых элементов показываем цветовой прогресс
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'color') {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                updateCrownColorElements();
            } else {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
            }
            
            // Обновляем дугу прогресса
            updateProgressArc();
            
            degreeSum = 0;
            return;
        }
        
        degreeSum = 0;
    });
}


// ====================== УПРАВЛЕНИЕ СОСТОЯНИЯМИ ======================
function changeState(newState) {
    const oldState = currentScreenState;
    currentScreenState = newState;
    
    // Всегда скрываем элементы при смене состояния
    g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
    bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
    Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
    
    
    switch (newState) {
        case SCREEN_STATE.MAIN:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, false);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
            
            // Восстанавливаем состояние через start_WG() для основного режима
            start_WG();
            
            break;
            
        case SCREEN_STATE.SETTINGS:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, true);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
            updateButtons();
            
            // Восстанавливаем состояние через start_WG()
            start_WG();
            
            MenuCirkl_Timer_on();
            break;
            
        case SCREEN_STATE.CROWN_MODE:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, false);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, true);
            
            // Восстанавливаем состояние через start_WG()
            start_WG();
            
            // Показываем панель коронки
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            
            // Обновляем элементы в зависимости от типа
            if (crown < CONF_MAIN.length) {
                if (CONF_MAIN[crown].type === 'color') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                    updateCrownColorElements();
                } else if (CONF_MAIN[crown].type === 'text') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                    updateText();
                } else if (CONF_MAIN[crown].type === 'png' || CONF_MAIN[crown].type === 'png_crown_off') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                }
            }
            
            break;
    }
}		




// ====================== КНОПКИ ЛЕВО/ПРАВО ======================


function click_btn_crown_left() {
    if (menu === 1 && Activ_color === 1) {
        handleColorChange(-1);
        return;
    }
	
	
    if (currentScreenState !== SCREEN_STATE.CROWN_MODE) return;
    
    if (CONF_MAIN[crown].type !== 'toggle') {
        crown_color(crown, -1, false);
        
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        if (CONF_MAIN[crown].type === 'color') {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
            updateCrownColorElements();
        } else {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        }
        updateProgressArc();
    }
}

function click_btn_crown_right() {
    if (menu === 1 && Activ_color === 1) {
        handleColorChange(1);
        return;
    }

	
	
    if (currentScreenState !== SCREEN_STATE.CROWN_MODE) return;
    
    if (CONF_MAIN[crown].type !== 'toggle') {
        crown_color(crown, 1, false);
        
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        if (CONF_MAIN[crown].type === 'color') {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
            updateCrownColorElements();
        } else {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        }
        updateProgressArc();
    }
}





// ====================== НАСТРОЙКИ ======================
/*function click_Set_on() {
    changeState(SCREEN_STATE.SETTINGS);
}*/


function click_Set_on() {
    changeState(SCREEN_STATE.SETTINGS);
}


function click_crown(index) {
    const toggleIndex = CONF_MAIN.length - 1;
    const isToggle = index === toggleIndex;
    
    // Если коронка отключена и это не toggle-кнопка - блокируем нажатие
    if (CONF_MAIN[toggleIndex].id === 0 && !isToggle) {
        return;
    }
    
    // Обработка toggle-кнопки
    if (isToggle && CONF_MAIN[index].type === 'toggle') {
        CONF_MAIN[index].id = (CONF_MAIN[index].id + 1) % 2;
        hmFS.SysProSetInt(`${WF_ID}_color_` + index, CONF_MAIN[index].id);
        
        crown = index;
        updateButtons();
        vibro();
        return;
    }
    
    // Вся остальная логика без изменений
    if (currentScreenState === SCREEN_STATE.CROWN_MODE && CONF_MAIN[index].type === 'save_conf') {
        return;
    }
    
    if (currentScreenState === SCREEN_STATE.SETTINGS && CONF_MAIN[index].type === 'save_conf') {
        CONF_MAIN[index].id = (CONF_MAIN[index].id + 1) % CONF_MAIN[index].len;
        hmFS.SysProSetInt(`${WF_ID}_color_` + index, CONF_MAIN[index].id);
        
        crown = index;
        updateButtons();
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        updateProgressArc();
        vibro();
        return;
    }
    
    if (currentScreenState === SCREEN_STATE.SETTINGS) {
        crown = index;
        updateButtons();
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        updateProgressArc();
        updateCrownColorElements();
        updateText();
        vibro();
    }
}



function click_Set_off() {
    const toggleIndex = CONF_MAIN.length - 1;
    
    // ЕСЛИ ВЫБРАНА TOGGLE-КНОПКА
    if (crown === toggleIndex) {
        hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
        changeState(SCREEN_STATE.MAIN);
    } else {
        // Для всех остальных кнопок - старая логика
        if (CONF_MAIN[toggleIndex].id === 0) {
            hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
            changeState(SCREEN_STATE.MAIN);
        } else {
            hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
            changeState(SCREEN_STATE.CROWN_MODE);
        }
    }
}

// Функция для выхода из CROWN_MODE должна быть отдельной
function click_btn_crown_exit() {
    if (menu === 1 && Activ_color === 1) {
        // Выходим из режима выбора цвета
        Activ_color = 0;
        ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, true);
        hmFS.SysProSetInt('PT31', 0);
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
        btn_Activ_color.setProperty(hmUI.prop.VISIBLE, true);
        btn_Activ_off.setProperty(hmUI.prop.VISIBLE, true);
        return;
    }
    changeState(SCREEN_STATE.MAIN);
}

function updateCrownColorElements() {
    // Показываем прогресс только для COLOR типа
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[crown].type === 'color');
    
    if (CONF_MAIN[crown].type === 'color') {
        updateProgressArc(); // ✓ Без параметров - использует значения по умолчанию из CONF_MAIN[crown]
        
        // Обновляем цветные элементы
        const colorInfo = getColorInfo();
        updateArcElements(CONF_MAIN[crown].id, colorInfo.colorArray);
    }
}


function updateColorUI(index, colorArray) {
 // Обновление основного цветового круга
 Activ_color_alpha.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 233,
  radius: 233,
  color: colorArray[index],
  alpha: index === 0 ? 0 : 255,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 // Обновление цветовых арок
 for (let i = 0; i < ARC_set.length; i++) {
  const colorIndex = index - 4 + i;
  const colorValue = colorArray[colorIndex];
  const hasColor = colorValue !== undefined && colorValue !== null;

  menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
   center_x: ARC_set[i][0],
   center_y: ARC_set[i][1],
   radius: ARC_set[i][2] / 2,
   color: hasColor ? colorValue : 0,
   alpha: hasColor ? 255 : 0,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
 }
}

// ====================== УНИВЕРСАЛЬНЫЕ ФУНКЦИИ ======================
function updateColorElements(targetIndex, colorArray, isMainColor = false) {
 // Обновление основного цветового круга
 Activ_color_alpha.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 233,
  radius: 233,
  color: colorArray[targetIndex],
  alpha: targetIndex === 0 ? 0 : 255,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 // Обновление цветовых арок
 for (let i = 0; i < ARC_set.length; i++) {
  const colorIndex = targetIndex - 4 + i;
  const colorValue = colorArray[colorIndex];
  const hasColor = colorValue !== undefined && colorValue !== null;

  menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
   center_x: ARC_set[i][0],
   center_y: ARC_set[i][1],
   radius: ARC_set[i][2] / 2,
   color: hasColor ? colorValue : 0,
   alpha: hasColor ? 255 : 0,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
 }

 // Для основного цвета обновляем прогресс
 if (isMainColor) {
  updateProgressArc(colorArray.length, targetIndex);
 }
}

function updateArcElements(startIndex, colorArray) {
    for (let i = 0; i < ARC_set.length; i++) {
        const colorIndex = startIndex - 4 + i;
        const colorValue = colorArray[colorIndex];
        const hasColor = colorValue !== undefined && colorValue !== null;

        menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
            center_x: ARC_set[i][0],
            center_y: ARC_set[i][1],
            radius: ARC_set[i][2] / 2,
            color: hasColor ? colorValue : 0,
            alpha: hasColor ? 255 : 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
    }
}

// ====================== ОСНОВНЫЕ ФУНКЦИИ (БЕЗ ИЗМЕНЕНИЙ) ======================
function handleColorChange(step) {
    color_ic = Math.max(0, Math.min(color_bg[1].length - 1, color_ic + step));
    degreeSum = 0;
    hmFS.SysProSetInt(`${WF_ID}_color_ic`, color_ic);

    updateColorUI(color_ic, color_bg[1]);
    updateProgressArc(color_bg[1].length, color_ic); // ✓ Правильно: передаем длину массива цветов и индекс
    g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
    vibro();
}

const KEY_SENSITIVITY = 3; // Чувствительность кнопок (2-быстро, 5-медленно)

function onKeyEvent() {
  let pressCounter = 0;

  hmApp.registerKeyEvent((key, action) => {
    if (action !== hmApp.action.CLICK) return;

    const direction = (key === hmApp.key.UP) ? 1 : -1;
    pressCounter++;

    if (pressCounter < KEY_SENSITIVITY) return;
    pressCounter = 0;

    // 1. Режим выбора цвета (старый режим)
    if (Activ_color === 1 && menu === 1) {
      color_ic = Math.max(0, Math.min(color_bg[1].length - 1, color_ic + direction));
      hmFS.SysProSetInt(`${WF_ID}_color_ic`, color_ic);
      updateColorUI(color_ic, color_bg[1]);
      updateProgressArc(color_bg[1].length, color_ic);
      g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
      g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
      vibro();
      return;
    }

    // 2. В состоянии SETTINGS - НЕ обрабатываем (кнопки вверх/вниз не работают в настройках)
    if (currentScreenState === SCREEN_STATE.SETTINGS) {
      return;
    }

    // 3. На главном экране (MAIN)
    if (currentScreenState === SCREEN_STATE.MAIN) {
      // Для png_crown_off НЕ обрабатываем на главном экране
      const aodIndex = findConfigIndex('png_crown_off');
      if (aodIndex !== -1 && crown === aodIndex && CONF_MAIN[aodIndex].type === 'png_crown_off') {
        return;
      }

      // Меняем параметры
      crown_color(crown, direction, false);

      // ПОКАЗЫВАЕМ ПРОГРЕСС И ЗАПУСКАЕМ ТАЙМЕР
      g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
      if (CONF_MAIN[crown].type === 'color') {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        updateCrownColorElements();
      }
      updateProgressArc();

      // ЗАПУСК ТАЙМЕРА
      if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
      MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
        Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
        timer.stopTimer(MenuCirkl_Timer);
      });

      vibro();
      return;
    }

    // 4. В режиме коронки (CROWN_MODE)
    if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
      // Для toggle типа не обрабатываем
      if (CONF_MAIN[crown].type === 'toggle') {
        return;
      }

      // Меняем параметры
      crown_color(crown, direction, false);

      // Обновляем панель коронки
      g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

      // Для цветовых элементов показываем цветовой прогресс
      if (CONF_MAIN[crown].type === 'color') {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        updateCrownColorElements();
      } else {
        // Для всех остальных типов (включая png_crown_off) скрываем цветовой прогресс
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
      }

      // Обновляем дугу прогресса
      updateProgressArc();

      vibro();
      return;
    }
  });
}
		
		
// ====================== ФУНКЦИИ С МИНИМАЛЬНЫМИ ИЗМЕНЕНИЯМИ ======================
function MenuCirkl_Timer_off() {
 if (btn_on == 0) {
  if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
  MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
   g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
   g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
   bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
   Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
   timer.stopTimer(MenuCirkl_Timer);
  });
 }
}

function MenuCirkl_Timer_on() {
 if (btn_on == 0) {
  if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
  MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
   g_Set.setProperty(hmUI.prop.VISIBLE, true);
   timer.stopTimer(MenuCirkl_Timer);
  });
 }
}


// ====================== ФУНКЦИИ БЕЗ ИЗМЕНЕНИЙ ======================
function handleCrownNavigation() {
 crown_color(crown, 0, true);
}
		
function processCrownAction(step) {
    if (Activ_color === 1 && menu === 1) {
        handleColorChange(step);
        return true;
    }

    if (Activ_color === 0 && menu === 0) {
        // Используем currentScreenState напрямую
        if (currentScreenState === SCREEN_STATE.SETTINGS) {
            // В настройках меняем выбранную кнопку
            handleCrownNavigation();
            
            // Показываем прогресс в настройках и запускаем таймер
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            updateProgressArc();
            MenuCirkl_Timer_off();
            
            return true;
        } else if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
            // В режиме коронки меняем параметры
            crown_color(crown, step, false);
            return true;
        } else if (currentScreenState === SCREEN_STATE.MAIN) {
            // На главном экране, если коронка включена
            if (CONF_MAIN[CONF_MAIN.length - 1].id === 1) {
                // Проверяем тип элемента - для 'png_crown_off' не обрабатываем
                if (CONF_MAIN[crown].type === 'png_crown_off') {
                    return false;
                }
                
                crown_color(crown, step, false);
                return true;
            }
        }
    }

    return false;
}		


// Вспомогательная функция для обновления текстовых элементов
function updateText() {
    // Показываем/скрываем текстовые элементы в зависимости от типа
    const isTextType = CONF_MAIN[crown].type === 'text';
    bg_app_text.setProperty(hmUI.prop.VISIBLE, isTextType);
    
    Line_arr.forEach((_, i) => {
        app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, isTextType);
        // Подсвечиваем выбранный элемент
        if (isTextType) {
            app_ACR_text[i].setProperty(hmUI.prop.COLOR, 
                CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
        }
    });
    
    // Для не-текстовых типов скрываем текстовые элементы
    if (!isTextType) {
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
        Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
    }
}		

function offKeyEvent() {
 try {
  hmApp.unregisterKeyEvent();
 } catch (e) {
  console.log("Unregister key event error:", e);
 }
}

function updateProgressArc(len = CONF_MAIN[crown].len, id = CONF_MAIN[crown].id) {
 menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
  center_x: D_W / 2,
  center_y: D_W / 2,
  start_angle: 45 + 81 / len * id,
  end_angle: 45 + 9 + 81 / len * (id + 1),
  radius: 219 + 8,
  line_width: 8,
  corner_flag: 0,
  color: 0xFF0000,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL
 });
 menu_ARC_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
}

function updateButtons() {
    const toggleIndex = CONF_MAIN.length - 1;
    const isCrownEnabled = CONF_MAIN[toggleIndex].id === 1;
    
    for (let i = 0; i < CONF_MAIN.length; i++) {
        const yPos = CONF_MAIN.length <= 5 
            ? 70 + i * Shag_Y 
            : i < Math.ceil(CONF_MAIN.length / 2) 
                ? 70 + i * Shag_Y 
                : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2);
        
        const xPos = CONF_MAIN.length <= 5 
            ? 153 
            : i < Math.ceil(CONF_MAIN.length / 2) 
                ? 70 
                : 233;
        
        // Определяем, активна ли кнопка
        const isToggleButton = (i === toggleIndex && CONF_MAIN[i].type === 'toggle');
        const isActive = isCrownEnabled || isToggleButton;
        
        let buttonText = '';
        if (CONF_MAIN[i].type === 'save_conf') {
            buttonText = 'конфигурация ' + (CONF_MAIN[i].id + 1);
        } else if (CONF_MAIN[i].type === 'toggle') {
            buttonText = Array.isArray(CONF_MAIN[i].name) 
                ? CONF_MAIN[i].name[CONF_MAIN[i].id] 
                : CONF_MAIN[i].name + ' ' + (CONF_MAIN[i].id + 1);
        } else {
            buttonText = CONF_MAIN[i].name + ' ' + (CONF_MAIN[i].id + 1);
        }
        
        // Определяем цвет кнопки
        let normalColor;
        if (CONF_MAIN[i].type === 'toggle') {
            normalColor = CONF_MAIN[i].id === 0 ? 0x800000 : 0x008000; // Темно-красный/Темно-зеленый
        } else {
            if (!isActive) {
                normalColor = 0x333333; // Серый для неактивных кнопок
            } else {
                normalColor = (i === crown) ? 0x800000 : 0x000000; // Красный/Черный
            }
        }
        
        // Текст кнопки
        let textColor = isActive ? 0xFFFFFFFF : 0x888888; // Белый для активных, серый для неактивных
        
        Btn_set_[i].setProperty(hmUI.prop.MORE, {
            x: xPos,
            y: yPos,
            w: 160,
            h: 60,
            text: buttonText,
            char_space: 0,
            line_space: -35,
            color: textColor,
            text_size: 24,
            radius: 12,
            press_color: isActive ? 0xFFFF0000 : 0x333333,
            normal_color: normalColor,
            text_style: hmUI.text_style.WRAP
        });
    }
}
		
// Функция для обработки текста приложения
function click_app_text_on_off() {
 // Позиционирование текста
 Line_arr.forEach((_, i) => {
  app_ACR_text[i].setProperty(hmUI.prop.X, i < Line_arr.length / 2 ? 68 : 233);
  app_ACR_text[i].setProperty(hmUI.prop.Y, i < Line_arr.length / 2 ? text_start + i * 21 : text_start + (i - Line_arr.length / 2) * 21);
 });

 // Отображение элементов
 bg_app_text.setProperty(hmUI.prop.VISIBLE, true);
 Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, true));
 g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

 // Скрываем цветовые элементы
 g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);

 // Установка цветов текста
 Line_arr.forEach((_, i) => {
  app_ACR_text[i].setProperty(hmUI.prop.COLOR,
   CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
 });
}



		
// Обновляем crown_color
function crown_color(crown_index, step, only_nav = false) {
    if (only_nav) {
        crown = crown_index;
        return;
    }
    
    const currentItem = CONF_MAIN[crown_index];
    const oldId = currentItem.id;
    let newId;
    
    if (currentItem.type === 'toggle' || currentItem.type === 'save_conf') {
        // Для save_conf циклическое переключение 0→1→2→0
        newId = (oldId + step + currentItem.len) % currentItem.len;
    } else {
        newId = oldId + step;
        
        // Одинаковая логика для всех типов
        if (newId < 0) {
            newId = 0;
        } else if (newId >= currentItem.len) {
            newId = currentItem.len - 1;
        }
    }
    
    if (oldId !== newId) {
        CONF_MAIN[crown_index].id = newId;
        hmFS.SysProSetInt(`${WF_ID}_color_` + crown_index, newId);
        switch_crown(crown_index);
        vibro();
    } else {
        // ВИБРАЦИЯ ПРИ ПОПЫТКЕ ВЫЙТИ ЗА ГРАНИЦЫ
        // Если значение не изменилось, но мы пытались изменить (шаг не 0)
        // и находимся на границе (0 или max)
        if (step !== 0) {
            const isMinBorder = (oldId === 0 && step < 0);
            const isMaxBorder = (oldId === currentItem.len - 1 && step > 0);
            
            if (isMinBorder || isMaxBorder) {
                vibro(); // Вибрация при попытке выйти за границы
            }
        }
    }
}

function getColorInfo(crownIndex = crown) {
    const colorArrayIndex = CONF_MAIN[crownIndex].colorArrayIndex || 0;
    const colorArray = color_bg[colorArrayIndex];
    const colorIndex = Math.min(CONF_MAIN[crownIndex].id, colorArray.length - 1);
    const colorValue = colorArray[colorIndex];
    
    return {
        colorArrayIndex,
        colorArray,
        colorIndex,
        colorValue
    };
}


function switch_crown_0() {
/* const colorInfo = getColorInfo(); // Использует текущий crown по умолчанию
 normal_background.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
// normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 'cap_str_' + colorInfo.colorIndex + '.png');
   normal_widget_text_3.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_1.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_4.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_5.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_6.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_7.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
	
            normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 279,
              end_angle: 351,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: colorInfo.colorValue,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
            normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 171,
              end_angle: 99,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              type: hmUI.data_type.STEP,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
            normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 261,
              end_angle: 189,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              type: hmUI.data_type.BATTERY,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
	
            normal_progress_bg_0.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 279,
              end_angle: 351,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_1.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 81,
              end_angle: 9,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_2.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 261,
              end_angle: 189,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_3.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 171,
              end_angle: 99,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

 vibro();
}

function switch_crown_1() {
   const colorInfo = getColorInfo();
//    normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bezel_' + colorInfo.colorIndex + '.png');
  //  vibro();
}

function switch_crown_2() {
   const colorInfo = getColorInfo();
   /*  normal_vo2max_icon_img.setProperty(hmUI.prop.SRC, 'cap_circl_' + colorInfo.colorIndex + '.png');
*/   // vibro();
}

function switch_crown_3() {
 const colorInfo = getColorInfo();
 const colorInfo4 = getColorInfo(4);

/* normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
  pos_x: 233 - hour_pointer[colorInfo.colorIndex][0],
  pos_y: 233 - hour_pointer[colorInfo.colorIndex][1],
  center_x: 233,
  center_y: 233,
  src: 'str_H_' + colorInfo4.colorIndex + '_' + colorInfo.colorIndex + '.png',
  // angle: 0,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.MORE, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
  pos_x: 233 - minute_pointer[colorInfo.colorIndex][0],
  pos_y: 233 - minute_pointer[colorInfo.colorIndex][1],
  center_x: 233,
  center_y: 233,
  src: colorInfo.colorIndex == 0 ? 'str_M_' + colorInfo4.colorIndex + '_0.png' : colorInfo.colorIndex == 3 ? 'str_M_' + colorInfo4.colorIndex + '_0.png' : 'str_M_' + colorInfo4.colorIndex + '_' + colorInfo.colorIndex + '.png',
  //angle: 0,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 //vibro();
}

function switch_crown_4() {
 const colorInfo = getColorInfo();
 const colorInfo3 = getColorInfo(3);
	
 normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 'str_H_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');
	
 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, colorInfo3.colorIndex == 0 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : colorInfo3.colorIndex == 3 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : 'str_M_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');	

 //vibro();
}

function switch_crown_5() {
 const colorInfo = getColorInfo();
	const colorInfo6 = getColorInfo(6);

 normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo.colorIndex == 0 ? 9 : 10,
  y: colorInfo.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 //vibro();
}

function switch_crown_6() {
 const colorInfo = getColorInfo();
 const colorInfo5 = getColorInfo(5);

 normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo5.colorIndex == 0 ? 9 : 10,
  y: colorInfo5.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_dw_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_cal_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.CAL,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_sun_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  //type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_unit_ic_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_ic_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_weater_ic.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_timeDifference_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_cityName_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
*/
 //vibro();
}

function switch_crown_4() {
 const colorInfo = getColorInfo();
 const colorInfo3 = getColorInfo(3);
/*	
 normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 'str_H_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');
	
 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, colorInfo3.colorIndex == 0 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : colorInfo3.colorIndex == 3 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : 'str_M_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');	
*/
 //vibro();
}

function switch_crown_5() {
 const colorInfo = getColorInfo();
	const colorInfo6 = getColorInfo(6);

/* normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo.colorIndex == 0 ? 9 : 10,
  y: colorInfo.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });*/

 //vibro();
}

function switch_crown_6() {
 const colorInfo = getColorInfo();
 const colorInfo5 = getColorInfo(5);

/* normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo5.colorIndex == 0 ? 9 : 10,
  y: colorInfo5.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_dw_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_cal_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.CAL,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_sun_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  //type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_unit_ic_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_ic_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_weater_ic.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_timeDifference_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_cityName_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);*/

 //vibro();
}





function switch_crown_7() {

//CONF_MAIN[crown].name = CONF_MAIN[crown].id == 0 ? 'ккккк': 'ггггг'
//    vibro();
}

		
function switch_crown_8() {
// Обновляем текст кнопки при изменении состояния toggle
    updateButtons();	

   vibro();
}
		
function switch_crown_9() {
	
//CONF_MAIN[crown].name = CONF_MAIN[crown].id == 0 ? 'ккккк': 'ггггг'
//    vibro();
}


// Создаём массив, где каждый элемент — соответствующая функция
const crownFunctions = [
 switch_crown_0, // crown === 0
 switch_crown_1, // crown === 1
 switch_crown_0, // crown === 0
 switch_crown_1, // crown === 1
 switch_crown_2, // crown === 2
 switch_crown_3, // crown === 3
 switch_crown_4, // crown === 4
 switch_crown_5, // crown === 5
 switch_crown_6, // crown === 6
 switch_crown_7, // crown === 7
 switch_crown_8, // crown === 8
 switch_crown_9, // crown === 8
];

// Функция переключения коронок с проверкой на отключение
function switch_crown(crown) {
    if (crown >= 0 && crown < crownFunctions.length) {
        crownFunctions[crown]();
    }
}


const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;

/*      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }*/

function vibro(scene = 25) {
 //let stopDelay = 50;
 vibrate.stop();
 vibrate.scene = scene;
 vibrate.start();

 // stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
}


function stopVibro() {
 vibrate.stop();
 timer.stopTimer(stopVibro_Timer);
}

function click_Pogoda_on() {
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 // updateGrafik()       
 menu = 2
 groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupPogoda.setProperty(hmUI.prop.VISIBLE, true);


 updateGrafik()

}

function click_Pogoda_off() {
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
 menu = 0
 groupVremya.setProperty(hmUI.prop.VISIBLE, true);
 groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

}

function click_Activ_on() {
    menu = 1;
    autoToggleWeatherIcons();
    groupVremya.setProperty(hmUI.prop.VISIBLE, false);
    groupActiv.setProperty(hmUI.prop.VISIBLE, true);

    if (Activ_color == 1) {
        // Если режим цвета уже был включён
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, true);
        btn_Activ_color.setProperty(hmUI.prop.VISIBLE, false);
        btn_Activ_off.setProperty(hmUI.prop.VISIBLE, false);
        updateColorUI(color_ic, color_bg[3]);
        updateProgressArc(color_bg[3].length, color_ic);
    } else {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
        btn_Activ_color.setProperty(hmUI.prop.VISIBLE, true);
        btn_Activ_off.setProperty(hmUI.prop.VISIBLE, true);
    }
}


function click_Activ_off() {
    menu = 0;
    Activ_color = 0; // при желании можно убрать, чтобы сохранять состояние между входами
    ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, true);
    groupVremya.setProperty(hmUI.prop.VISIBLE, true);
    groupActiv.setProperty(hmUI.prop.VISIBLE, false);

    // Скрываем панели и возвращаем исходные кнопки
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
    g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
    g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
    btn_Activ_color.setProperty(hmUI.prop.VISIBLE, true);
    btn_Activ_off.setProperty(hmUI.prop.VISIBLE, true);
}


let apps = [
 ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
 ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
 ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
 ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
 ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
 ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
 ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
 ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
 ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
 ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
 ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
 ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
 ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
 ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
 ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
 ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
 ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
 ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
 ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
 ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
 ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
 ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
 ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
 ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
 ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
 ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
 ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
 ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
 ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
 ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
 ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
 ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
 ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
 ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
 ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
 ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
];


let btn_tap = ''
let btn_click_tap_exit = ''


function tap_zona_exit() {
 //    canvas.setProperty(hmUI.prop.MORE, {
 //        x: 0,
 //        y: 0,
 //        w: 466,
 //        h: 466,
 //        show_level: hmUI.show_level.ONLY_NORMAL
 //    });

 // setTimeout(() => {
 // drawGradients();
 //  }, 300);

 groupVremya.setProperty(hmUI.prop.VISIBLE, true);
 groupTap.setProperty(hmUI.prop.VISIBLE, false);

}


function tap_run() {
 //    canvas.setProperty(hmUI.prop.MORE, {
 //        x: 466,
 //        y: 466,
 //        w: 466,
 //        h: 466,
 //        show_level: hmUI.show_level.ONLY_NORMAL
 //    });

 groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupTap.setProperty(hmUI.prop.VISIBLE, true);
}


//-------------------------------- 
//переменные для ргафика
let weather_ic_array = []
let weather_ic = []
let DigDay = []
let DigNight = []
let yArrH = [];
let arr_xH = [];
let arr_yH = [];
let arr_x = [];
let arr_y = [];
let arr_xL = [];
let arr_yL = [];
let yArrAll = [];
let yArrL = [];
let y_pogodaH = [];
let y_pogodaL = [];
let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
let week_text = []
let data_text = []
const ROOTPATH = "images/"
var shag = 46;
var x0 = 119 - 23 - 23;
let dney = 8;
let isDayIcons = false

let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];


let tip_grafik = 0

function click_tip_grafik() {
 tip_grafik = (tip_grafik + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, tip_grafik);
 ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
 click_Pogoda_off();
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 setTimeout(() => {
  click_Pogoda_on()
  tip()
 }, 150);
}
let fix_gsm = 1;

function click_fix_gms() {
 fix_gsm = (fix_gsm + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_fix_gsm`, fix_gsm);
 fix_gsm_text_font.setProperty(hmUI.prop.TEXT, fix_gsm == 0 ? '+0' : '+1');
 click_Pogoda_off();
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 setTimeout(() => {
  click_Pogoda_on()
  updateGrafik()
  app_update();
 }, 150);
}


 let normal_city_name_text_0 = ''

 //-------------------------------- 

 //массив иконок для графика       
 for (var i = 0; i <= 28; i++) {
  weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
 }



function getSunTimes(weatherData, fix_gsm) {
  let tideData = weatherData.tideData;

  // Получение времени заката
  let sunset_hour = -1;
  let sunset_minute = -1;
  if (tideData.count > 0) {
   sunset_hour = tideData.data[0].sunset.hour + fix_gsm;
   sunset_minute = tideData.data[0].sunset.minute;
  }

  let normal_sunset = undefined;
  if (sunset_hour >= 0 && sunset_minute >= 0) {
   normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
  }

  // Получение времени восхода
  let sunrise_hour = -1;
  let sunrise_minute = -1;
  if (tideData.count > 0) {
   sunrise_hour = tideData.data[0].sunrise.hour + fix_gsm;
   sunrise_minute = tideData.data[0].sunrise.minute;
  }

  let normal_sunrise = undefined;
  if (sunrise_hour >= 0 && sunrise_minute >= 0) {
   normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
  }

  return {
   normal_sunset_circle_string: normal_sunset,
   normal_sunrise_circle_string: normal_sunrise
  };
 }



 function autoToggleWeatherIcons() {

  let weatherData = weatherSensor.getForecastWeather();
  let tideData = weatherData.tideData;

  sunData = weatherData.tideData;
  if (sunData.count > 0) {
   today = sunData.data[0];
   sunriseMins = (today.sunrise.hour + fix_gsm) * 60 + today.sunrise.minute;
   sunsetMins = (today.sunset.hour + fix_gsm) * 60 + today.sunset.minute;
  } else {
   sunriseMins = sunriseMins_def;
   sunsetMins = sunsetMins_def;
  }
  curMins = timeSensor.hour * 60 + timeSensor.minute;
  let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

  if (isDayNow) {
   if (!isDayIcons) {
    isDayIcons = true;
   }
  } else {
   if (isDayIcons) {
    isDayIcons = false;
   }
  }


  const {
   normal_sunset_circle_string,
   normal_sunrise_circle_string
  } = getSunTimes(weatherData, fix_gsm);

  // СОХРАНЯЕМ ДАННЫЕ ДЛЯ AOD
  let displaySunrise = normal_sunrise_circle_string || "06:00";
  let displaySunset = normal_sunset_circle_string || "18:00";
  let displayWeatherIcon = "--";
  
  normal_vos_zak_text_font.setProperty(hmUI.prop.TEXT, isDayIcons == false ? normal_sunrise_circle_string : normal_sunset_circle_string);
  normal_vos_zak_icon_img.setProperty(hmUI.prop.SRC, isDayIcons == false ? 'images/Grafik/ic_activ/ic_vos.png' : 'images/Grafik/ic_activ/ic_zak.png');

 

  //      Line_arr[20][1] = isDayIcons == false ? normal_sunrise_circle_string : normal_sunset_circle_string;  
  //      
  //
  //  normal_sun_img[3].setProperty(hmUI.prop.SRC, isDayIcons == false ? 'images/APP/ic_vos_n.png' : 'images/APP/ic_zak_n.png');
  //  normal_sun_img[4].setProperty(hmUI.prop.SRC, isDayIcons == false ? 'images/APP/ic_vos_n.png' : 'images/APP/ic_zak_n.png');
  //  normal_sun_img[5].setProperty(hmUI.prop.SRC, isDayIcons == false ? 'images/APP/ic_vos_n.png' : 'images/APP/ic_zak_n.png');

  // normal_sun_high_text_font.setProperty(hmUI.prop.TEXT, isDayIcons == false ? normal_sunrise_circle_string : normal_sunset_circle_string);


  let T_N = curMins;
  //       let T_V = sunrise_hour * 60 + sunrise_minute;
  //       let T_Z = sunset_hour * 60 + sunset_minute;

  // Получаем часы и минуты из строки формата "HH:MM"
  const [sunriseHours, sunriseMinutes] = normal_sunrise_circle_string.split(':').map(Number);
  const [sunsetHours, sunsetMinutes] = normal_sunset_circle_string.split(':').map(Number);

  let T_V = sunriseHours * 60 + sunriseMinutes;
  let T_Z = sunsetHours * 60 + sunsetMinutes;


  let T_24 = T_Z - T_N;
  let level_SUN_CURRENT_day = (T_N - T_V) / (T_Z - T_V) * 100;
  let level_SUN_CURRENT_night = T_24 < 0 ? (T_N - T_Z) / ((24 * 60 - T_Z) + T_V) * 100 : (24 * 60 - T_Z + T_N) / ((24 * 60 - T_Z) + T_V) * 100;

  SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.MORE, {
   center_x: 175 + 116 + 7,
   center_y: 166 + 116,
   start_angle: -135,
   end_angle: 135,
   radius: 39,
   line_width: 10,
   corner_flag: 3,
   color: isDayIcons ? 0xffef42 : 0x42ffeb,
   level: isDayIcons ? level_SUN_CURRENT_day : level_SUN_CURRENT_night,
   // type: hmUI.data_type.SUN_CURRENT,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

	 
	 
	 

  shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

  array_ic_weater = isDayIcons == false ? ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];

  //  let current = weatherSensor.current;
 // let curAirIconIndex = weatherSensor.curAirIconIndex;
  //  normal_city_name_text.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);

  //normal_weater_ic.setProperty(hmUI.prop.TEXT, array_ic_weater[curAirIconIndex]);
  

  if (screenTypeJS == hmSetting.screen_type.AOD) {
    // ПРОСТО ОБНОВЛЯЕМ AOD ВИДЖЕТЫ БЕЗ ВЫЗОВА ДОПОЛНИТЕЛЬНЫХ ФУНКЦИЙ
//    idle_sun_current_text_font.setProperty(hmUI.prop.TEXT, displaySunrise + ' - ' + displaySunset);
//    idle_unit_ic_up.setProperty(hmUI.prop.TEXT, up == 2 ? "C" : isDayIcons == false ? 'K' : 'J');
//    idle_unit_text_circ_up.setProperty(hmUI.prop.TEXT, up == 2 ? "ККАЛ" : isDayIcons == false ? 'ВОС' : 'ЗАК');
//    idle_weater_ic.setProperty(hmUI.prop.TEXT, array_ic_weater[curAirIconIndex]);
  }

 }




//обновление для   графика           
 function updateGrafik() {

  autoToggleWeatherIcons()

  if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
  let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let year = timeSensor.year;
  if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
   day_num[2] = 29
  } else {
   day_num[2] = 28
  }

  let current = weatherSensor.current;
  let curAirIconIndex = weatherSensor.curAirIconIndex;

  let temperature_current_temp = -100;
  if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
   temperature_current_temp = weatherSensor.current;
  }; // end currentWeather; 

  let weatherData = weatherSensor.getForecastWeather();
  let forecastData = weatherData.forecastData;

  const {
   normal_sunset_circle_string,
   normal_sunrise_circle_string
  } = getSunTimes(weatherData, fix_gsm);


  normal_temp_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С");
  normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
  normal_city_name_text_0.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + "   " + weatherData.cityName.toUpperCase() + "   " + normal_sunset_circle_string);


  //        normal_left_text.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + " " + forecastData.data[0].low + "°");
  //        normal_right_text.setProperty(hmUI.prop.TEXT, forecastData.data[0].high + "° " + normal_sunset_circle_string);


  //        normal_weater_name_text.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);
  //       normal_temperature_max_min_text.setProperty(hmUI.prop.TEXT, forecastData.data[0].high + "/" + forecastData.data[0].low);
  //        normal_temperature_current_text.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°");


  if (forecastData.count == 0) {
   for (let i = 0; i < dney; i++) {
    var invalidPath = "--";
    weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
   }
  } else {
   let weekDay = timeSensor.week - 1;
   let data_gr = timeSensor.day;
   let month_gr = timeSensor.month;

   for (let i = 0; i < dney; i++) {

    // let arr_y  = [252, 238, 252, 266, 238, 224, 308, 322];    

    yArrH[i] = forecastData.data[i].high;

    let element = forecastData.data[i];
    let iconIndex = element.index;
    weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
    let week2 = week_array[weekDay];
    week_text[i].setProperty(hmUI.prop.MORE, {
     color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
     text: week2,
    });
    data_text[i].setProperty(hmUI.prop.MORE, {
     color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
     text: data_gr,
    });
    weekDay = (weekDay + 1) % 7;
    data_gr = (data_gr + 1)
    if (data_gr > day_num[month_gr]) data_gr = 1
    if (i < dney - 1) yArrL[i] = forecastData.data[i].low;

   }
  }


  //  array_ic_weater = isDayIcons == false ?  ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];  

  // if (menu == 2) tip();
  tip();

 }

 function tip() {

  canvas.clear({
   x: 0,
   y: 0,
   w: D_W,
   h: D_W,
  })

  canvas.setPaint({
   color: 0x00ff00,
   line_width: 4
  })

  for (let i = 0; i < dney - 1; i++) {
   canvas.drawRect({
    x1: 94 + shag * [i],
    y1: 93,
    x2: 94 + shag * [i] + 1,
    y2: 351,
    color: 0xc0c0c0
   })
  }


  let maxH = Math.max(...yArrH)
  let maxL = Math.min(...yArrL)
  let delta = 120 / (maxL - maxH)

  let RedArray = [];
  let BlueArray = [];

  if (tip_grafik == 0) {
   for (let i = 0; i < dney; i++) {
    arr_x[i] = x0 + shag * [i];
    arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
   }
   // let n = arr_x.length;
   splain(dney)

   for (let i = 0; i < dney - 1; i++) {
    arr_x[i] = x0 + 23 + shag * [i];
    arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
   }
   // n = dney - 1;
   splain(dney - 1)
  }
  if (tip_grafik == 1) {
   let k = 0
   for (let i = 0; i < dney; i++) {

    yArrAll[k] = yArrH[i]
    k = k + 1
    yArrAll[k] = yArrL[i]
    k = k + 1

   }


   for (let i = 0; i < yArrAll.length; i++) {
    arr_x[i] = x0 + shag / 2 * [i];
    arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
   }
   //n = yArrAll.length - 1;
   splain(yArrAll.length - 1)
  }


  for (let i = 0; i < dney; i++) {
   if (tip_grafik == 0) {
    canvas.drawCircle({
     center_x: x0 + shag * [i],
     center_y: yArrH[i] * delta + 162 - maxH * delta,
     radius: 5,
     color: 0xFF0000
    })
   }
   y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
   DigDay[i].setProperty(hmUI.prop.more, {
    x: x0 - 23 - 5 + i * 45 * 1.02,
    y: y_pogodaH[i] - 18, //120-7//120-7/- 38
    w: 50,
    h: 40,
    color: "0xFFffffff",
    text_size: 27,
    text: yArrH[i],
    text_style: hmUI.text_style.NONE,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    show_level: hmUI.show_level.ONLY_NORMAL
   });

   if (i < dney - 1) {
    if (tip_grafik == 0) {
     canvas.drawCircle({
      center_x: x0 + 23 + shag * [i],
      center_y: yArrL[i] * delta + 162 - maxH * delta,
      radius: 5,
      color: 0x00eaff
     })
    }
    y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
    DigNight[i].setProperty(hmUI.prop.more, {
     x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
     y: y_pogodaL[i] + 19, //120-7 / - 1  
     w: 50,
     h: 40,
     color: "0xFFffffff",
     text_size: 27,
     text: yArrL[i],
     text_style: hmUI.text_style.NONE,
     align_h: hmUI.align.CENTER_H,
     align_v: hmUI.align.CENTER_V,
     show_level: hmUI.show_level.ONLY_NORMAL
    });
   } //dney - 1
  }; //dney   
 }


 function splain(n) {
  let arr_a = new Array(n).fill().map(() => new Array(1));
  let arr_b = new Array(n - 1).fill().map(() => new Array(1));
  let arr_c = new Array(n).fill().map(() => new Array(1));
  let arr_d = new Array(n - 1).fill().map(() => new Array(1));

  let arr_h = new Array(n - 1).fill().map(() => new Array(1));
  let arr_alpha = new Array(n).fill().map(() => new Array(1));
  let arr_l = new Array(n).fill().map(() => new Array(1));
  let arr_mu = new Array(n).fill().map(() => new Array(1));
  let arr_z = new Array(n).fill().map(() => new Array(1));

  for (var i = 0; i < n - 1; i++) {
   arr_h[i] = arr_x[i + 1] - arr_x[i];
  }

  for (var i = 1; i < n - 1; i++) {
   arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
  }

  arr_l[0] = 1;
  arr_mu[0] = 0;
  arr_z[0] = 0;

  for (var i = 1; i < n - 1; i++) {
   arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
   arr_mu[i] = arr_h[i] / arr_l[i];
   arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
  }

  arr_l[n - 1] = 1;
  arr_z[n - 1] = 0;
  arr_c[n - 1] = 0;

  for (var j = n - 2; j >= 0; j--) {
   arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
   arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
   arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
   arr_a[j] = arr_y[j];
  }

  for (var i = 0; i < n - 1; i++) {
   for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
    yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

    if (tip_grafik == 0) {
     canvas.drawImage({
      x: xi,
      y: yi,
      w: 5,
      h: 310 - yi,
      alpha: 127,
      image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
     })
    }

    canvas.drawLine({
     x1: xi,
     y1: yi,
     x2: xi + 5,
     y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
     // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
     color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
    })


   }
  }

 }

 function updateSleep() {
  //-----------  сон------------------
  sleepTotalTime = sleep.getTotalTime();
  sleepInfo = sleep.getBasicInfo();
  sleepStartTime = sleepInfo.startTime;
  if (sleepStartTime >= 24 * 60) {
   sleepStartTime -= 24 * 60
  }

  sleepEndTime = sleepInfo.endTime + 1;
  if (sleepEndTime >= 24 * 60) {
   sleepEndTime -= 24 * 60
  }

  //-----------  время пробуждений ------------------
  let wakeTime = 0;
  sleepStageArray = sleep.getSleepStageData();

  for (let i = 0; i < sleepStageArray.length; i++) {
   let data = sleepStageArray[i];
   if (data.model == modelData.WAKE_STAGE) {
    wakeTime += data.stop + 1 - data.start;
   }

  }

  sleepTotalTime -= wakeTime;
  //-------------------------------------------------

  sleep_time_txt.setProperty(hmUI.prop.TEXT, 'СПАЛИ ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
  sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
  sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
  wake_time_txt.setProperty(hmUI.prop.TEXT, 'ПРОСЫПАЛИСЬ ' + String(wakeTime) + ' мин.');
  sleep_score_txt.setProperty(hmUI.prop.TEXT, 'КАЧЕСТВО ' + String(sleepScore) + ' %');
  //-------------------------------------------------
  Line_arr[10][1] = Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0");
 }


 function updatePressere() {
  let pressure_array = read_pressure();
  let value = getPressureValue(pressure_array);
  value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.


  let pressere_changes_str = "=";
  //let color_pressere = 0x00ff00;
  let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

  let pressere_changes = changesPressure(pressure_array);
  if (pressere_changes < 0) {
   pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
  }
  if (pressere_changes > 0) {
   pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
  }
  //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

  let value_str = value == 0 ? "--" : value + pressere_changes_str;
  text_pressere.setProperty(hmUI.prop.TEXT, value_str);
  text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);

 // Line_arr[2][1] = value_str;
 }


 // Параметры системы
 const SQUARE_SIZE = 112;
 const INNER_DIAMETER = 302; // Диаметр для центров квадратов
 const OUTER_DIAMETER = D_W; // Диаметр главной окружности
 const OFFSET = -6; // Намеренный сдвиг 

 // Генерация 5 конфигураций (без последнего элемента)
 const tapConfigs = Array.from({
  length: 6
 }, (_, i) => {
  // Угол: -90° + шаг 60° (первый квадрат сверху)
  const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);

  // Центр квадрата (на окружности INNER_DIAMETER)
  const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
  const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

  // Левый верхний угол квадрата с поправкой (-6, -6)
  const x = Math.round(centerX - SQUARE_SIZE / 2) + OFFSET;
  const y = Math.round(centerY - SQUARE_SIZE / 2) + OFFSET;

  // Определение defaultType и смещения подсказок
  let defaultType, tipsY;
  switch (i) {
   case 0:
    defaultType = 19;
    tipsY = 130;
    break; // Верхний
   case 1:
    defaultType = 20;
    tipsY = 130;
    break; // Верхний правый
   case 2:
    defaultType = 24;
    tipsY = -62;
    break; // Нижний правый
   case 3:
    defaultType = 11;
    tipsY = -64;
    break; // Нижний (особый сдвиг -64)
   case 4:
    defaultType = 35;
    tipsY = -62;
    break; // Нижний левый
   case 5:
    defaultType = 0;
    tipsY = 130;
    break; // Нижний левый

  }

  return {
   id: 101 + i,
   x: x,
   y: y,
   defaultType: defaultType,
   tipsX: -35, // Общее смещение по X для всех
   tipsY: tipsY // Индивидуальное по Y
  };
 });
 // Результат (можно раскомментировать последний элемент, если нужно все 6)


 // Генерация 6 квадратов
 const tapPositions = Array.from({
  length: 6
 }, (_, i) => {
  // Угол: -90° + шаг 60° (первый квадрат сверху)
  const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);

  // Центр квадрата (на окружности INNER_DIAMETER)
  const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
  const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

  // Левый верхний угол квадрата
  return {
   x: Math.round(centerX - SQUARE_SIZE / 2),
   y: Math.round(centerY - SQUARE_SIZE / 2),
   index: i
  };
 });


 // 1. Создаём массив для хранения результатов
 const tapSelections = [];

 // 2. Проходим по всем конфигам последовательно
 for (let i = 0; i < tapConfigs.length; i++) {
  const config = tapConfigs[i];

  // 3. Создаём виджет
  const edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
   edit_id: config.id,
   x: config.x,
   y: config.y,
   w: 124,
   h: 124,
   select_image: 'tap/edit_red_1.png',
   un_select_image: 'tap/edit_griin_1.png',
   default_type: config.defaultType,
   optional_types: apps.map((app, index) => ({
    type: index,
    preview: app[2],
    title_en: app[0]
   })),
   count: apps.length,
   tips_x: config.tipsX,
   tips_y: config.tipsY,
   tips_width: 195,
   tips_margin: 10,
   tips_BG: 'tap/tips_bg.png'
  });

  // 4. Даём время на инициализацию (если нужно)
  let counter = 0;
  while (counter < 1000) counter++; // Микро-задержка

  // 5. Получаем текущий тип и сохраняем
  tapSelections[i] = edit.getProperty(hmUI.prop.CURRENT_TYPE);

 }

 // Создаем группу для Tap интерфейса (только 5 элементов: 0,1,2,3,5)


 function createTapInterface() {

  groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
   x: 0,
   y: 0,
   w: D_W,
   h: D_H,
   show_level: hmUI.show_level.ONLY_NORMAL
  });


  i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
   x: 0,
   y: 0,
   w: D_W,
   h: D_H,
   src: 'tap/i_tap_bg.png',
   show_level: hmUI.show_level.ONLY_NORMAL,
  });


  for (let i = 0; i < 6; i++) {
   // if (i === 4) continue; // Пропускаем 5-й элемент

   const pos = tapPositions[i];
   const appIndex = tapSelections[i];

   // Иконка приложения
   groupTap.createWidget(hmUI.widget.IMG, {
    x: pos.x,
    y: pos.y,
    src: apps[appIndex][2],
    show_level: hmUI.show_level.ONLY_NORMAL,
   });

   // Кнопка (невидимая, но кликабельная)
   groupTap.createWidget(hmUI.widget.BUTTON, {
    x: pos.x,
    y: pos.y,
    w: 113,
    h: 113,
    normal_src: '0_Empty.png',
    press_src: '0_Empty.png',
    click_func: () => {
     vibro();
     const app = apps[appIndex];
     hmApp.startApp({
      appid: app[3] === 0 ? '' : app[1],
      url: app[3] === 0 ? app[1] : app[4],
      native: app[3] === 0,
      params: app[3] === 0 ? null : {
       from_wf: true
      },
     });
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
   });
  }

  return groupTap;
 }
	 

 const TIME_ZONES = [
  "UTC", "CET", "КЛГ", "МСК", "САМ", "ЕКБ", "ОМСК", "КРАС",
  "ИРК", "ЯКУ", "ВЛД", "МАГ", "КАМ", "SST", "HST", "AKST",
  "PST", "MST", "CST", "EST", "AST", "BRT", "GST", "CVT"
 ];



let normal_unit_font = [];
function createUnitText(x, y, visible) {
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x, y,
    w: 150,
    h: 80,
    text_size: 19,
    text: '',
    font: 'fonts/Oswald-Medium.ttf',
    color: 0x90ffff,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  widget.setProperty(hmUI.prop.VISIBLE, visible);
  return widget;
} 
 
let normal_ic = [];
function createIconWidget(x, y, index) {
  const id = CONF_MAIN[index].id;
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x, y,
    w: 80,
    h: 80,
    text_size: 34,
    text: Line_arr[id][0],
    char_space: 0,
    line_space: 0,
    font: 'fonts/ic_Sever1.ttf',
    color: Line_arr[id][4],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  widget.setProperty(hmUI.prop.VISIBLE, id != 16 && id != 20 && id != 14);
  return widget;
}


let normal_uvi_img = [];
function createUviImg(x, y, visible) {
    const widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x, y,
    image_array: ["images/APP/uv_0.png", "images/APP/uv_1.png", "images/Grafik/ic_activ/uv_2.png", "images/APP/uv_3.png", "images/APP/uv_4.png"],
    image_length: 5,
    type: hmUI.data_type.UVI,
    show_level: hmUI.show_level.ONLY_NORMAL,
    });
    widget.setProperty(hmUI.prop.VISIBLE, visible);
    return widget;
} 

let normal_sun_img = [];
function createSunImg(x, y, visible) {
    const widget = hmUI.createWidget(hmUI.widget.IMG, {
    x, y,
    src: 'images/APP/ic_vos_n.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    });
    widget.setProperty(hmUI.prop.VISIBLE, visible);
    return widget;
} 

  //let normal_data = Array(3*2).fill().map(() => []);

// Объявляем массив для виджетов данных
const normal_data = [[], [], [], [], [], []]; // Индексы 0-5, будем использовать 3,4,5
// Функция для создания виджета данных для конкретной позиции
function createDataWidget(i, position) {
  // Определяем параметры для каждой позиции
  const positionConfig = {
    3: { x: 12, y: 299 },   // Левая позиция
    4: { x: 309, y: 299 },  // Правая позиция
    5: { x: 158, y: 29 }      // Верхняя позиция
  };
  const config = positionConfig[position];
  // Создаем виджет
  const widget = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
    x: config.x,
    y: config.y,
    w: 150,
    h: 60,
    text_size: 33,
    char_space: 0,
    line_space: 0,
    font: 'fonts/Oswald-Regular.ttf',
    color: color_bg[0][CONF_MAIN[1].id],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    unit_type: Line_arr[i][2],
    padding: Line_arr[i][6],
    type: Line_arr[i][5],
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  // Устанавливаем видимость ВНУТРИ функции
  widget.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[position].id == i);
  return widget;
}


// Объявляем массив для текстовых виджетов значений
const normal_sensor_value = []; // Индексы 3,4,5 для left, right, up
// Функция для создания текстовых виджетов значений
function createValueWidget(position) {
  // Конфигурация позиций (только координаты, ширина всегда 150)
  const positionConfig = {
    3: { x: 12, y: 299 },   // Левая позиция
    4: { x: 309, y: 299 },  // Правая позиция
    5: { x: 158, y: 29 }    // Верхняя позиция
  };
  const id = CONF_MAIN[position].id;
  const config = positionConfig[position];
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x: config.x,
    y: config.y,
    w: 150,  // Фиксированная ширина для всех виджетов
    h: 60,
    text_size: 33,
    text: Line_arr[id][1],
    char_space: 0,
    line_space: 0,
    font: 'fonts/Oswald-Regular.ttf',
    color: color_bg[0][CONF_MAIN[1].id],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  // Устанавливаем видимость сразу
  widget.setProperty(hmUI.prop.VISIBLE, Line_arr[id][5] == '');
  return widget;
}
		
            function resetSecondsCarousel() {
                let now = new Date();
                let sec = now.getSeconds();
                for (let i = 0; i < NUM_WIDGETS; i++) {
                    baseY[i] = START_Y + i * STEP; // 127,210,293,376,459
                    // Значения: чтобы на позиции Y=210 (индекс 1) была текущая секунда, нужно:
                    // i=0: S-2, i=1: S-1, i=2: S, i=3: S+1, i=4: S+2
                    secValues[i] = (sec - 2 + i + 60) % 60; // при i=2 даёт sec
                    secWidgets[i].setProperty(hmUI.prop.TEXT, secValues[i].toString().padStart(2, '0'));
                    secWidgets[i].setProperty(hmUI.prop.Y, baseY[i]);
                }
                lastSecond = sec;
            }	
		
function resetMinutesCarousel() {
    let now = new Date();
    let realMin = now.getMinutes();
    for (let i = 0; i < NUM_WIDGETS; i++) {
        baseY_minute[i] = START_Y + i * STEP;
        minuteValues[i] = (realMin - 2 + i + 60) % 60; // реальное время на i=2
        minuteWidgets[i].setProperty(hmUI.prop.TEXT, minuteValues[i].toString().padStart(2, '0'));
        minuteWidgets[i].setProperty(hmUI.prop.Y, baseY_minute[i]);
    }
    lastMinute = realMin;
}

function resetHoursCarousel() {
    let now = new Date();
    let realHour = now.getHours();
    for (let i = 0; i < NUM_WIDGETS; i++) {
        baseY_hour[i] = START_Y + i * STEP;
        hourValues[i] = (realHour - 2 + i + 24) % 24; // реальное время на i=2
        hourWidgets[i].setProperty(hmUI.prop.TEXT, hourValues[i].toString().padStart(2, '0'));
        hourWidgets[i].setProperty(hmUI.prop.Y, baseY_hour[i]);
    }
    lastHour = realHour;
}
		
		
		
    // --- НОВЫЕ ПЕРЕМЕННЫЕ ДЛЯ СЕКУНДНОЙ КАРУСЕЛИ (5 ВИДЖЕТОВ) ---
    let secWidgets = [];                 // массив из 5 виджетов секунд
    let secValues = [];                  // текущие значения (0-59) для каждого виджета
    let baseY = [];                      // базовые координаты Y (будут вычислены)
    const STEP = 83;                      // шаг между виджетами (и сдвиг за секунду)
    const NUM_WIDGETS = 5;                // количество виджетов
    const TOTAL_STEP = NUM_WIDGETS * STEP; // полный цикл для переноса
    const START_Y = 109+7;                   // начальная Y первого виджета
    const UPPER_BOUND = START_Y - STEP;    // верхняя граница: виджет считается ушедшим, если Y < START_Y - STEP (44)
    let lastSecond = -1;                   // для отслеживания смены секунды
    let normal_animationTimer = undefined;  // таймер анимации
    // ------------------------------------------------------------			
 
// --- НОВЫЕ ПЕРЕМЕННЫЕ ДЛЯ МИНУТНОЙ КАРУСЕЛИ ---
let minuteWidgets = [];                 // массив из 5 виджетов минут
let minuteValues = [];                  // текущие значения (0-59) для каждого виджета
let baseY_minute = [];                  // базовые координаты Y для минут
let lastMinute = -1;                     // для отслеживания смены минуты
// --- НОВЫЕ ПЕРЕМЕННЫЕ ДЛЯ ЧАСОВОЙ КАРУСЕЛИ ---
let hourWidgets = [];                    // массив из 5 виджетов часов
let hourValues = [];                     // текущие значения (0-23) для каждого виджета
let baseY_hour = [];                     // базовые координаты Y для часов
let lastHour = -1;                        // для отслеживания смены часа
let lastMinuteChangeTime = 0;
let lastHourChangeTime = 0;		
// -------------------------------------------------		
		
 
        // end user_functions.js

        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_spo2_icon_img = ''
        let normal_readiness_icon_img = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_widget_text_10 = ''
        let normal_widget_text_11 = ''
        let normal_pai_icon_img = ''
        let normal_training_load_icon_img = ''
        let normal_image_img = ''
        let normal_floor_icon_img = ''
        let normal_uvi_icon_img = ''
        let normal_wind_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_step_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_stand_icon_img = ''
        let idle_stress_icon_img = ''
        let idle_spo2_icon_img = ''
        let idle_readiness_icon_img = ''
        let idle_widget_text_1 = ''
        let idle_widget_text_2 = ''
        let idle_widget_text_3 = ''
        let idle_widget_text_4 = ''
        let idle_widget_text_5 = ''
        let idle_widget_text_6 = ''
        let idle_widget_text_10 = ''
        let idle_widget_text_11 = ''
        let idle_sun_icon_img = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_pai_icon_img = ''
        let idle_training_load_icon_img = ''
        let idle_image_img = ''
        let idle_floor_icon_img = ''
        let idle_uvi_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let idle_step_current_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_max_min_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_distance_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Conthrax Bold.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 897,
              h: 84,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: bor.ttf; FontSize: 15
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 301,
              h: 31,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFADADAD,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Conthrax Bold.ttf; FontSize: 19; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 22,
              h: 22,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: bor.ttf; FontSize: 18
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,

              y: 464,
              w: 387,
              h: 39,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: bor.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 514,
              h: 50,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFFF5601,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

loadSettings()

hmUI.createWidget(hmUI.widget.TEXT, {
 x: 464,
 y: 464,
 w: 42,
 h: 42,
 text_size: 27,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: 464,
 y: 464,
 w: 42,
 h: 42,
 text_size: 33,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: 464,
 y: 464,
 w: 328,
 h: 48,
 text_size: 35,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFFFF,
 align_h: hmUI.align.CENTER_H,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});


if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
 normal_background = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  x: 0,
  y: 0,
  w: 466,
  h: 466,
  color: color_bg[0][CONF_MAIN[0].id],
  //color: 0xFFFF0000,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });
}








            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 95,
              src: 'bg_S_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 95,
              src: 'bg_H_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 95,
              src: 'bg_H_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 



            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 16,
              src: 'sec_ani_B.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 16,
              src: 'sec_ani_W.png',
              // alpha: 64,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_icon_img.setAlpha(64);
				
				
            for (let i = 0; i < NUM_WIDGETS; i++) {
                secWidgets[i] = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 361,
                    y: 0, // временно, установим позже
                    w: 130,
                    h: 70,
                    text_size: 50,
                    char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFF000000,
                    line_space: 0,
                    align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
                    text: '00',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
            }	
				
// Создание виджетов для минут (x = 206)
for (let i = 0; i < NUM_WIDGETS; i++) {
    minuteWidgets[i] = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 206,
        y: 0, // временно
        w: 130,
        h: 70,
        text_size: 50,
        char_space: 0,
        font: 'fonts/Conthrax Bold.ttf',
        color: 0xFFFFFFFF,
        line_space: 0,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.ELLIPSIS,
        align_h: hmUI.align.LEFT,
        text: '00',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

// Создание виджетов для часов (x = 49)
for (let i = 0; i < NUM_WIDGETS; i++) {
    hourWidgets[i] = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 49,
        y: 0, // временно
        w: 130,
        h: 70,
        text_size: 50,
        char_space: 0,
        font: 'fonts/Conthrax Bold.ttf',
        color: 0xFFFFFFFF,
        line_space: 0,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.ELLIPSIS,
        align_h: hmUI.align.LEFT,
        text: '00',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}				
				
				
				
/*            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 361,
              y: 192,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFF5601,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/				
				
				
				

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_widget_text_10 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 73,
              y: 371,
              w: 130,
              h: 50,
              text_size: 15,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFADADAD,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ШАГИ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_11 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 265,
              y: 371,
              w: 130,
              h: 50,
              text_size: 15,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFADADAD,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ПУТЬ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				
				

            normal_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 18,
              y: 16,
              src: 'sec_ani_W.png',
              // alpha: 64,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_icon_img.setAlpha(64);

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 229,
              src: 'line_sd.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 18,
              y: 230,
              src: 'line_color.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 169,
              // start_y: 425,
              // color: 0xFFFF5601,
              // lenght: 130,
              // line_width: 5,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 423,
              src: 'cap_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 248,
              y: 79,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 79,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 70,
              y: 79,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 61,
              y: 356,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 27,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 386,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 350,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFFF5601,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 253,
              y: 356,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/*            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 192+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFF5601,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

/*            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 192+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFF5601,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/


				
/*           normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 109+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '09',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 192+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '10',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 275+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '11',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 109+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '07',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 192+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '08',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 275+7,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '09',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

/*            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 361,
              y: 109,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '31',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 361,
              y: 192,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '32',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
				
				

/*            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 361,
              y: 275,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '33',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	*/			
				
				

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 129,
              y: 42,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 311,
              y: 44,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 95,
              src: 'bg_S_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 95,
              src: 'bg_H_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 95,
              src: 'bg_H_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 109,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '09',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 192,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '10',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 275,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '11',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 109,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '07',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 192,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '08',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 275,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '09',
              show_level: hmUI.show_level.ONLY_AOD,
            });



            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 112,
              src: 'cap_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
				
				
				

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 192,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFF5601,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 192,
              w: 130,
              h: 70,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFF5601,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 16,
              src: 'sec_ani_B.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_training_load_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 16,
              src: 'sec_ani_W.png',
              // alpha: 64,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_training_load_icon_img.setAlpha(64);

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
				
				
            idle_widget_text_10 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 73,
              y: 371,
              w: 130,
              h: 50,
              text_size: 15,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFADADAD,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ШАГИ',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_11 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 265,
              y: 371,
              w: 130,
              h: 50,
              text_size: 15,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFADADAD,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ПУТЬ',
              show_level: hmUI.show_level.ONLY_AOD,
            });
				
				

            idle_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 18,
              y: 16,
              src: 'sec_ani_W.png',
              // alpha: 64,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_floor_icon_img.setAlpha(64);

            idle_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 229,
              src: 'line_sd.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 169,
              // start_y: 425,
              // color: 0xFFADADAD,
              // lenght: 130,
              // line_width: 5,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 423,
              src: 'cap_bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 248,
              y: 79,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 79,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 70,
              y: 79,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 61,
              y: 356,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 27,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 386,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 350,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/bor.ttf',
              color: 0xFFADADAD,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 253,
              y: 356,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              font: 'fonts/Conthrax Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 129,
              y: 42,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 311,
              y: 44,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

        bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'tap/bg_edit.png',
         show_level: hmUI.show_level.ONLY_EDIT,
        });   
        
                if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
       groupTap = createTapInterface();
        
        groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); //

        btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 96,
         y: 28,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_run();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Pogoda_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 366, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Activ_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_sleep = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 372, //x кнопки
         y: 186, //y кнопки
         text: '',
         w: 94, //ширина кнопки
         h: 94, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_sleep();
         },
//                    longpress_func: () => {
//                     vibro();
//         			   click_sleep();
//                    },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 183,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_zona_exit();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); 

        normal_Sleep_bg = groupSleep.createWidget(hmUI.widget.FILL_RECT, {
         x: 72,
         y: 99,
         w: 322,
         h: 200,
         color: 0x000000,
         radius: 20,
         alpha: 178,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sleep_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0, // координата X
         y: 108, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 27, // размер текста
         text: '',
         font: 'fonts/Bebas22.ttf',
         color: 0xffffff, // цвет текста
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 103, // координата X
         y: 144, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 27, // размер текста

         text: 'ЗАСНУЛИ',
         font: 'fonts/Bebas22.ttf',
         color: 0x00ff00, // цвет текста
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -105, // координата X
         y: 144, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 27, // размер текста
         text: 'ПРОСНУЛИСЬ',
         font: 'fonts/Bebas22.ttf',
         color: 0xe779ff, // цвет текста
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sleep_start_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 103,
         y: 181,
         w: 466, // ширина 	
         h: 40,
         text_size: 27,
         text: '',
         font: 'fonts/Bebas22.ttf',
         color: 0x00ff00,
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sleep_end_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -105, // координата X
         y: 181,
         w: 466, // ширина 	
         h: 40,
         text_size: 27,
         text: '',
         font: 'fonts/Bebas22.ttf',
         color: 0xe779ff,
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        wake_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 217,
         w: 466,
         h: 40,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         text: '',
         color: 0xff4949,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sleep_score_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 256,
         w: 466,
         h: 40,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         text: '',
         color: 0xffffff,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_exit_sleep = groupSleep.createWidget(hmUI.widget.BUTTON, {
         x: 0, //x кнопки
         y: 0, //y кнопки
         text: '',
         w: 466, //ширина кнопки
         h: 466, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_exit_sleep();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);

        //---------------------------    погода
        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas.setPaint({
         color: 0x00ff00,
         line_width: 4
        })

        normal_temp_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 74,
         y: 47 + 5 + 6 + 2,
         w: 318,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 414,
         y: 212,
         src: 'images/Grafik/ic_graf_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupPogoda.createWidget(hmUI.widget.CIRCLE, {
         center_x: 31,
         center_y: 233,
         radius: 21,
         color: 0xbdbabd,
         // alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        fix_gsm_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 10,
         y: 212 + 2,
         w: 42,
         h: 42,
         text: fix_gsm == 0 ? '+0' : '+1',
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0x000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

    windSpeedText = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 399,
         w: 466,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas22.ttf',
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
        // type: hmUI.data_type.WIND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
  chanceOfRainText = groupPogoda.createWidget(hmUI.widget.TEXT, {
   x: 210,
   y: 357,
   w: 150,
   h: 40,
   // text: '100%',
   text_size: 35,
   char_space: 0,
   line_space: 0,
   color: 0xFFFFFFFF,
   font: 'fonts/Bebas22.ttf',
   align_h: hmUI.align.LEFT,
   align_v: hmUI.align.CENTER_V,
   unit_type: 1,
   text_style: hmUI.text_style.ELLIPSIS,
   // type: hmUI.data_type.HUMIDITY,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  RainImg = groupPogoda.createWidget(hmUI.widget.IMG, {
   x: 169,
   y: 359,
   src: 'images/Grafik/ic_activ/ic_rain_on.png',
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  groupPogoda.createWidget(hmUI.widget.IMG, {
   x: 285,
   y: 360,
   src: ROOTPATH + 'Grafik/ic_activ/ic_davl_txt.png',
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
   x: 12,
   y: 166,
   image_array: ["images/Grafik/ic_activ/uv_0.png", "images/Grafik/ic_activ/uv_1.png", "images/Grafik/ic_activ/uv_2.png", "images/Grafik/ic_activ/uv_3.png", "images/Grafik/ic_activ/uv_4.png"],
   image_length: 5,
   type: hmUI.data_type.UVI,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
   x: 66,
   y: 358,
   image_array: ["images/Grafik/ic_activ/vl_0.png", "images/Grafik/ic_activ/vl_1.png", "images/Grafik/ic_activ/vl_2.png", "images/Grafik/ic_activ/vl_3.png", "images/Grafik/ic_activ/vl_4.png", "images/Grafik/ic_activ/vl_5.png", "images/Grafik/ic_activ/vl_6.png", "images/Grafik/ic_activ/vl_7.png", "images/Grafik/ic_activ/vl_8.png", "images/Grafik/ic_activ/vl_9.png"],
   image_length: 10,
   type: hmUI.data_type.HUMIDITY,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });


  groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
   x: -43,
   y: 265 + 5,
   w: 150,
   h: 30,
   text_size: 27,
   font: 'fonts/Bebas22.ttf',
   char_space: 0,
   line_space: 0,
   color: 0xFFFFFFFF,
   align_h: hmUI.align.CENTER_H,
   align_v: hmUI.align.CENTER_V,
   text_style: hmUI.text_style.ELLIPSIS,
   type: hmUI.data_type.UVI,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 420,
         y: 171,
         src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 359,
         y: 265 + 5,
         w: 150,
         h: 30,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALTITUDE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        text_pressere = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 347,
         y: 357,
         w: 150,
         h: 40,
         color: 0xffffff,
         font: 'fonts/Bebas22.ttf',
         text_size: 35,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "--",
        });


        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 97,
         y: 357,
         w: 150,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas22.ttf',
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (var i = 0; i < dney; i++) {
         week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: week_array[i],
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
         // hmUI.deleteWidget(data_text[i]);
         data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2 + 20, //- 21
          w: 50,
          h: 50,

          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: 31,
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });

         weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
          x: x0 - 23 + i * shag,
          y: 78 + 10, //- 10
          w: 40,
          h: 40,
          // src: weatherArray[i],
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
         if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);

        }


        btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 366, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_tip_grafik();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 183,
         w: 100,
         h: 100,
         text: '',
         normal_src: 'blank.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {

          vibro(); //имя вызываемой функции
          click_fix_gms();

          //          hmApp.startApp({
          //           appid: 1051195,
          //           url: 'page/index',
          //           params: {
          //            from_wf: true,
          //           }
          //          });

         },
        });

        groupActiv = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        });

        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         src: 'images/Grafik/bg_activ.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Activ_color_alpha = groupActiv.createWidget(hmUI.widget.CIRCLE, {
         center_x: 233,
         center_y: 233,
         radius: 233,
         // color: color_bg_Activ[color_ic],
         color: color_bg[1][color_ic],
         alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         src: 'images/Grafik/bg_activ_mask.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 216,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,

         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_HIGH_LOW,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 157,
         y: 359,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.DISTANCE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 260,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.PAI_WEEKLY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_vos_zak_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 276,
         y: 254,
         src: 'images/Grafik/ic_activ/ic_vos.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_vos_zak_text_font = groupActiv.createWidget(hmUI.widget.TEXT, {
         x: 223,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {

         x: 157,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         padding: true,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 51,
         y: 385,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SPO2,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 333,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 407,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STAND,

         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 333,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STAND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 180,
         center_y: 280,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 260,
         y: 385,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         //padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FLOOR,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 99,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116 + 116,
         center_y: 166 + 116,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        SUN_CURRENT_PROGRESS = groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116 + 7,
         center_y: 166 + 116,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         // type: hmUI.data_type.SUN_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 99,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 59,
         center_y: 282,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -17,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,

         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 59,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 51,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.COUNT_DOWN,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -17,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_activ_color_off_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 363,
         y: 346,
         src: 'images/Grafik/ic_activ_color_off.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);

        Button_1 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 18,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'AlarmInfoScreen',
           native: true

          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 79,
         y: 18,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'CountdownAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_3 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 287,
         y: 18,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'PAI_app_Screen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_4 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 8,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'activityWeekShowScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_5 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 124,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'heart_app_Screen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_6 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 241,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'WeatherScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_7 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 357,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'SportListScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_8 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 9,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'readinessAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_9 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 130,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'activityAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_10 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 250,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'TideScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_11 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 357,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'SportRecordListScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_12 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 76,
         y: 342,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'RespirationwidgetScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button	

       btn_Activ_off = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 366,
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         text: "ОК",
         char_space: 0,
         line_space: -55,
         color: 0xFFFFFFFF,
         text_size: 24,
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Activ_off();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ_color = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 300,
         y: 345,
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
             click_Activ_color();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
					
					


        g_ACR_panel = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        //цвет	
        menu_ARC_PROGRES_bg = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 60 - 15,
         end_angle: 120 + 15,
         radius: 219 + 8,
         line_width: 8,
         corner_flag: 0,
         color: 0xFF5b5b5b,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        menu_ARC_PROGRES = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 45 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), // start_angle: 45 + 90 / array * gde,
         end_angle: 135 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), //end_angle: 135 + 90 / array * gde,
         radius: 219,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF0000, //0xFF007eff
         level: 100 / CONF_MAIN[0].len, //level: pointer,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);


        g_ACR_color_PROGRES = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        for (let i = 0; i < ARC_set.length; i++) {
         menu_ARC_color[i] = g_ACR_color_PROGRES.createWidget(hmUI.widget.CIRCLE, {
          center_x: ARC_set[i][0],
          center_y: ARC_set[i][1],
          radius: ARC_set[i][2] / 2,
          color: color_bg[0][i],
          alpha: 255,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        };

        CIRCLE_select = g_ACR_color_PROGRES.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: ARC_set[4][0],
         center_y: ARC_set[4][1],
         radius: ARC_set[4][2] / 2 + 6,
         start_angle: 0,
         end_angle: 360,
         line_width: 6,
         corner_flag: 3,
         color: 0xff0000,
         //alpha: 255,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
					
       
        bg_app_text = hmUI.createWidget(hmUI.widget.FILL_RECT, {
        // x: crown == 1 ? 233 - 163 : 233 + 163,
        x: 68,
         y: 4+text_start,
         w: 331,
         h: Line_arr.length/2 * 21 + 21 / 2,
         color: 0x000000,
         alpha: 178,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
        
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);

        for (let i = 0; i < Line_arr.length; i++) {
         app_ACR_text[i] = hmUI.createWidget(hmUI.widget.TEXT, {
//          x: crown == 1 ? 233 - 166 : 233 + 166,
//          y: 70 + 25 + i * 21 - 22,
                        x: i<Line_arr.length/2 ? 68:233,
                        y: i<Line_arr.length/2 ? text_start + i*21 : text_start + (i-Line_arr.length/2)*21,
          w: 166,
          h: 30,
          text: Line_arr[i][3],
          text_size: 21,
          char_space: 0,
          line_space: 0,
          //font: 'fonts/Bebas22.ttf',
          color: CONF_MAIN[1].id == i ? 0xff0000 : 0xffffff,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
         app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false);
        };
        
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);	
					
					
	//updateButtons();				
					
					
            // end user_script_beforeShortcuts.js

            console.log('user_script_end.js');
            // start user_script_end.js



        g_Set = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        normal_background_Set = g_Set.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         // radius: 12,
         alpha: 153,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        for (let i = 0; i < CONF_MAIN.length; i++) {
         Btn_set_[i] = g_Set.createWidget(hmUI.widget.BUTTON, {
          x: CONF_MAIN.length <= 5 ? 153 : i < Math.ceil(CONF_MAIN.length / 2) ? 70 : 233,
          y: CONF_MAIN.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(CONF_MAIN.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2),
          w: 160,
          h: 60,
          text: CONF_MAIN[i].name,
          char_space: 0,
          line_space: -35,
          color: 0xFFFFFFFF,
          text_size: 24,
          radius: 12,
          press_color: 0xFFFF0000,
          normal_color: i != crown ? 0x000000 : 0x800000,
          click_func: () => {
           vibro();
           click_crown(i);
          },
          text_style: hmUI.text_style.WRAP,
          show_level: hmUI.show_level.ONLY_NORMAL,
         }); // end button
        };

        btn_Set_exit = g_Set.createWidget(hmUI.widget.BUTTON, {
         x: 203, //x кнопки
         y: 70 + Shag_Y * 5, //y кнопки
         w: 60,
         h: 60,
         text: "ОК",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: 0xFF000000,
         click_func: () => {
          vibro();
          click_Set_off();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_Set.setProperty(hmUI.prop.VISIBLE, false);

        btn_crown = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 270, //x кнопки
         y: 28, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          // vibro();
          click_Set_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

/*         btn_tap_left = groupVremya.createWidget(hmUI.widget.BUTTON, {
             x: 0, //x кнопки
             y: 183, //y кнопки
             text: '',
             w: 100, //ширина кнопки
             h: 100, //высота кнопки
             normal_src: '0_Empty.png',
             press_src: '0_Empty.png',
             click_func: () => {
                 vibro();
                 clik_tap_left();
             },
             longpress_func: () => {
                 vibro();
                 clik_longpress_tap_left();
             },
             show_level: hmUI.show_level.ONLY_NORMAL,
         });
*/

        g_btn_crown = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,

        })
        
g_btn_crown.createWidget(hmUI.widget.TEXT, {
  x: 14,
  y: 14,
  w: (466 - 14 * 2),
  h: (466 - 14 * 2),
  text_size: 33,
        color: 0xffffff,
  text: "←",
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  char_space: 1,
  start_angle: 37-90,
  end_angle: 37+90,
  show_level: hmUI.show_level.ONLY_NORMAL,	
})	
        
g_btn_crown.createWidget(hmUI.widget.TEXT, {
  x: 14,
  y: 14,
  w: (466 - 14 * 2),
  h: (466 - 14 * 2),
  text_size: 33,
        color: 0xffffff,
  text: "→",
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  char_space: 1,
  start_angle: 143-90,
  end_angle: 143+90,
  show_level: hmUI.show_level.ONLY_NORMAL,	
})        
				
        normal_background_btn_crown = g_btn_crown.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         alpha: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
	        
        btn_crown_left = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
         x: 305, //x кнопки
         y: 31, //y кнопки
         w: 100,
         h: 100,
         //text: "<<",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 50,
         radius: 12,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         //         press_color: 0xFFFF0000,
         //         normal_color: 0xFF800000,
         click_func: () => {
          vibro();
          click_btn_crown_left();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });	
				
        btn_crown_right = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
         x: 305, //x кнопки
         y: 335, //y кнопки
         w: 100,
         h: 100,
         //text: ">>",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 50,
         radius: 12,
             normal_src: '0_Empty.png',
             press_src: '0_Empty.png',
//         press_color: 0xFFFF0000,
//         normal_color: 0xFF800000,
         click_func: () => {
          vibro();
          click_btn_crown_right();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });		

        btn_crown_exit = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
         x: 203, //x кнопки
         y: 400, //y кнопки
         w: 60,
         h: 60,
         text: "ОК",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: 0xFF800000,
         click_func: () => {
          vibro();
          click_btn_crown_exit();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);					


        groupVremya.setProperty(hmUI.prop.VISIBLE, true);
        groupTap.setProperty(hmUI.prop.VISIBLE, false);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
        groupActiv.setProperty(hmUI.prop.VISIBLE, false);
        groupSleep.setProperty(hmUI.prop.VISIBLE, false);
        
          };  // end screenType
          
                
      const weatherProvider = new WeatherProvider({
       //				night_icons: [0, 1, 2, 3, 14],
       index: 1, // текущий индекс провайдера (сохраняется и считывается из памяти)
       //				show_toast: false,
       //				temp_widget: tempText,
       //				temp_max_widget: tempMaxText,
       //				temp_min_widget: tempMinText,
       // temp_feels_widget: tempFeelsText,


       //			icon_widget_Rain: RainImg,
       //			chance_Of_Rain: chanceOfRainText,
       //			chance_Of_Rain2: normal_voshod_text_font,
       //			chance_Of_Rain3: normal_rain_font,
       //			windSpeed_widget: windSpeedText,


       //				description_widget: descriptionText,
       //				cityName_widget: cityNameText,
       //				icon_widget: weatherImg,
       //				time_sensor: curTime,
       //				weather_sensor: weather,
      });  
      
start_WG()



                
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
				
	let hour_1 = 	String(parseInt(timeSensor.hour / 10));	
	let hour_2 = 	String(parseInt(timeSensor.hour % 10));	
	let minute_1 = 	String(parseInt(timeSensor.minute / 10));	
	let minute_2 = 	String(parseInt(timeSensor.minute % 10));	
	let data_1 = 	String(parseInt(timeSensor.day / 10));	
	let data_2 = 	String(parseInt(timeSensor.day % 10));	
				
              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

/*              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };*/

/*              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };*/

              console.log('second font');
//                let normal_secondStr = second.toString();
//                normal_secondStr = normal_secondStr.padStart(2, '0');
              //  normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
//normal_widget_text_8.setProperty(hmUI.prop.TEXT, normal_secondStr );	

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 169;
                  let start_y_normal_battery = 425;
                  let lenght_ls_normal_battery = 130;
                  let line_width_ls_normal_battery = 5;
                  let color_ls_normal_battery = 0xFFFF5601;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 169;
                  let start_y_idle_battery = 425;
                  let lenght_ls_idle_battery = 130;
                  let line_width_ls_idle_battery = 5;
                  let color_ls_idle_battery = 0xFFADADAD;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            resetSecondsCarousel();
resetMinutesCarousel();
resetHoursCarousel();				
				
let returnTimer = null;	
				
let forceMinuteAnimation = false;
let forceHourAnimation = false;
let forceAnimationStartTime = 0;				
			
				


// Добавьте эту переменную в глобальную область (например, после let normal_animationTimer)
let tempAnimationTimer = null;


const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: (function () {
        console.log('resume_call()');
        scale_call();
        time_update(true, true);
        if (screenType == hmSetting.screen_type.WATCHFACE) {
            if (!normal_timerTimeUpdate) {
                normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                    let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                    let updateMinute = timeSensor.second < 2;
                    time_update(updateHour, updateMinute);
                }));
            }
        }

        if (screenType == hmSetting.screen_type.AOD) {
            if (!idle_timerTimeUpdate) {
                idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                    let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                    let updateMinute = timeSensor.second < 2;
                    time_update(updateHour, updateMinute);
                }));
            }
        }

        resetSecondsCarousel();
        resetMinutesCarousel();
        resetHoursCarousel();

        // Останавливаем предыдущие таймеры
        if (normal_animationTimer) {
            timer.stopTimer(normal_animationTimer);
            normal_animationTimer = undefined;
        }
        if (tempAnimationTimer) {
            timer.stopTimer(tempAnimationTimer);
            tempAnimationTimer = null;
        }

        // --- Стартовая анимация (500 мс, easing как у секунд) ---
        let startY_minute = baseY_minute.slice();
        let startY_hour = baseY_hour.slice();
        let targetY_minute = startY_minute.map(y => y - STEP);
        let targetY_hour = startY_hour.map(y => y - STEP);
        let targetY_training = 16 - STEP;
        let targetY_floor = 16 - STEP;

        let animationStartTime = Date.now();
        let animationDuration = 500;

        tempAnimationTimer = timer.createTimer(0, 20, function() {
            let elapsed = Date.now() - animationStartTime;
            let progress = Math.min(elapsed / animationDuration, 1.0);
            let easedProgress = 1 - Math.pow(1 - progress, 4);

            for (let i = 0; i < NUM_WIDGETS; i++) {
                let yMinute = startY_minute[i] + (targetY_minute[i] - startY_minute[i]) * easedProgress;
                minuteWidgets[i].setProperty(hmUI.prop.Y, Math.round(yMinute));
                let yHour = startY_hour[i] + (targetY_hour[i] - startY_hour[i]) * easedProgress;
                hourWidgets[i].setProperty(hmUI.prop.Y, Math.round(yHour));
            }

            // Иконки (с сохранением оригинального двухфазного движения, но с easedProgress)
            let trainingY, floorY;
            if (progress < 0.5) {
                let p = easedProgress * 2;
                trainingY = 16 - STEP * p;
                floorY = 16 - STEP * p;
            } else {
                let p = (1 - easedProgress) * 2;
                trainingY = 16 - STEP * p;
                floorY = 16 - STEP * p;
            }
            if (normal_training_load_icon_img) normal_training_load_icon_img.setProperty(hmUI.prop.Y, Math.round(trainingY));
            if (normal_floor_icon_img) normal_floor_icon_img.setProperty(hmUI.prop.Y, Math.round(floorY));

            if (progress >= 1.0) {
                timer.stopTimer(tempAnimationTimer);
                tempAnimationTimer = null;

                for (let i = 0; i < NUM_WIDGETS; i++) {
                    baseY_minute[i] = targetY_minute[i];
                    baseY_hour[i] = targetY_hour[i];
                }
                // Иконки остаются на целевых позициях (16 - STEP)

                lastMinuteChangeTime = 0;
                lastHourChangeTime = 0;

                startMainTimer();
            }
        });

function startMainTimer() {
    let isMinuteAnimating = false;
    let isHourAnimating = false;

    normal_animationTimer = timer.createTimer(0, 20, function() {
        let now = new Date();
        let hour = now.getHours();
        let min = now.getMinutes();
        let sec = now.getSeconds();
        let nowMs = Date.now();

        // Секунды (как было)
        if (sec != lastSecond) {
            for (let i = 0; i < NUM_WIDGETS; i++) baseY[i] -= STEP;
            for (let i = 0; i < NUM_WIDGETS; i++) {
                if (baseY[i] < UPPER_BOUND) {
                    baseY[i] += TOTAL_STEP;
                    secValues[i] = (secValues[i] + NUM_WIDGETS) % 60;
                    secWidgets[i].setProperty(hmUI.prop.TEXT, secValues[i].toString().padStart(2, '0'));
                }
            }
            lastSecond = sec;
        }

        // Смещение для секунд
        let msInSecond = nowMs % 1000;
        let offset = 0;
        if (msInSecond > 500) {
            let progress = (msInSecond - 500) / 500;
            progress = Math.min(progress, 1.0);
            offset = (1 - Math.pow(1 - progress, 4)) * (-STEP);
        }
        for (let i = 0; i < NUM_WIDGETS; i++) {
            secWidgets[i].setProperty(hmUI.prop.Y, Math.round(baseY[i] + offset));
        }
        if (normal_pai_icon_img) {
            normal_pai_icon_img.setProperty(hmUI.prop.Y, 16 + offset);
        }

        // --- Минуты ---
        let msUntilNextMinute = 60000 - (nowMs % 60000);
        if (!isMinuteAnimating && msUntilNextMinute <= 500 && msUntilNextMinute > 0) {
            isMinuteAnimating = true;
            startMinuteAnimation(function() {
                isMinuteAnimating = false;
                lastMinute = (min + 1) % 60; // обновляем после анимации
            });
        }

        // --- Часы ---
        let msUntilNextHour = 3600000 - (nowMs % 3600000);
        if (!isHourAnimating && msUntilNextHour <= 500 && msUntilNextHour > 0) {
            isHourAnimating = true;
            startHourAnimation(function() {
                isHourAnimating = false;
                lastHour = (hour + 1) % 24;
            });
        }
    });
}		
		
		
		
        // Анимация минут
        function startMinuteAnimation(onComplete) {
            let startY = baseY_minute.slice();
            let targetY = startY.map(y => y - STEP);
            let animStartTime = Date.now();
            let animDuration = 500;

            let animTimer = timer.createTimer(0, 20, function() {
                let elapsed = Date.now() - animStartTime;
                let progress = Math.min(elapsed / animDuration, 1.0);
                let easedProgress = 1 - Math.pow(1 - progress, 4);

                // Двигаем виджеты
                for (let i = 0; i < NUM_WIDGETS; i++) {
                    let y = startY[i] + (targetY[i] - startY[i]) * easedProgress;
                    minuteWidgets[i].setProperty(hmUI.prop.Y, Math.round(y));
                }
                // Иконка
                let iconY = 16 - STEP * easedProgress;
                if (normal_training_load_icon_img) normal_training_load_icon_img.setProperty(hmUI.prop.Y, Math.round(iconY));

                // Проверка переноса через верхнюю границу
                for (let i = 0; i < NUM_WIDGETS; i++) {
                    let y = minuteWidgets[i].getProperty(hmUI.prop.Y);
                    if (y < UPPER_BOUND) {
                        // Переносим вниз
                        let newY = y + TOTAL_STEP;
                        minuteWidgets[i].setProperty(hmUI.prop.Y, Math.round(newY));
                        // Увеличиваем значение на 5
                        minuteValues[i] = (minuteValues[i] + 5) % 60;
                        minuteWidgets[i].setProperty(hmUI.prop.TEXT, minuteValues[i].toString().padStart(2, '0'));
                    }
                }

                if (progress >= 1.0) {
                    timer.stopTimer(animTimer);
                    // Обновляем базовые координаты
                    for (let i = 0; i < NUM_WIDGETS; i++) {
                        baseY_minute[i] = targetY[i];
                    }
                    if (normal_training_load_icon_img) normal_training_load_icon_img.setProperty(hmUI.prop.Y, 16 - STEP);
                    onComplete();
                }
            });
        }

        // Анимация часов
        function startHourAnimation(onComplete) {
            let startY = baseY_hour.slice();
            let targetY = startY.map(y => y - STEP);
            let animStartTime = Date.now();
            let animDuration = 500;

            let animTimer = timer.createTimer(0, 20, function() {
                let elapsed = Date.now() - animStartTime;
                let progress = Math.min(elapsed / animDuration, 1.0);
                let easedProgress = 1 - Math.pow(1 - progress, 4);

                for (let i = 0; i < NUM_WIDGETS; i++) {
                    let y = startY[i] + (targetY[i] - startY[i]) * easedProgress;
                    hourWidgets[i].setProperty(hmUI.prop.Y, Math.round(y));
                }
                let iconY = 16 - STEP * easedProgress;
                if (normal_floor_icon_img) normal_floor_icon_img.setProperty(hmUI.prop.Y, Math.round(iconY));

                for (let i = 0; i < NUM_WIDGETS; i++) {
                    let y = hourWidgets[i].getProperty(hmUI.prop.Y);
                    if (y < UPPER_BOUND) {
                        let newY = y + TOTAL_STEP;
                        hourWidgets[i].setProperty(hmUI.prop.Y, Math.round(newY));
                        hourValues[i] = (hourValues[i] + 5) % 24;
                        hourWidgets[i].setProperty(hmUI.prop.TEXT, hourValues[i].toString().padStart(2, '0'));
                    }
                }

                if (progress >= 1.0) {
                    timer.stopTimer(animTimer);
                    for (let i = 0; i < NUM_WIDGETS; i++) {
                        baseY_hour[i] = targetY[i];
                    }
                    if (normal_floor_icon_img) normal_floor_icon_img.setProperty(hmUI.prop.Y, 16 - STEP);
                    onComplete();
                }
            });
        }

        console.log('resume_call.js');
        // start resume_call.js
        loadSettings();
        autoToggleWeatherIcons();

        if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
            chanceOfRainText.setProperty(hmUI.prop.TEXT, weatherProvider.chanceOfRain + '%');
            RainImg.setProperty(hmUI.prop.SRC, weatherProvider.chanceOfRain.replace('%', '') >= 50 ? 'images/Grafik/ic_activ/ic_rain_on.png' : 'images/Grafik/ic_activ/ic_rain_off.png');
            let Direction = weatherProvider.windDirection;
            windSpeedText.setProperty(hmUI.prop.TEXT, getWindDescription(Direction, 0) + " " + weatherProvider.windSpeed + ' м/с');
        }

        updateSleep();
        updatePressere();
        click_Pogoda_off();
        setTimeout(() => {
            onDigitalCrown();
        }, 1000);
        setTimeout(() => {
            onKeyEvent();
        }, 1000);

        stopVibro();
        // end resume_call.js
    }),
    pause_call: (function () {
        console.log('pause_call()');
        if (normal_timerTimeUpdate) {
            timer.stopTimer(normal_timerTimeUpdate);
            normal_timerTimeUpdate = undefined;
        }
        if (idle_timerTimeUpdate) {
            timer.stopTimer(idle_timerTimeUpdate);
            idle_timerTimeUpdate = undefined;
        }
        if (normal_animationTimer) {
            timer.stopTimer(normal_animationTimer);
            normal_animationTimer = undefined;
        }
        if (tempAnimationTimer) {
            timer.stopTimer(tempAnimationTimer);
            tempAnimationTimer = null;
        }

        console.log('pause_call.js');
        // start pause_call.js
        vibrate.stop();
        hmApp.unregisterSpinEvent();
        offKeyEvent();
        normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
        groupTap.setProperty(hmUI.prop.VISIBLE, false);
        groupVremya.setProperty(hmUI.prop.VISIBLE, true);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
        groupActiv.setProperty(hmUI.prop.VISIBLE, false);
        groupSleep.setProperty(hmUI.prop.VISIBLE, false);
        // end pause_call.js
    }),
});
				
				
				
				
				
				
				//dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}